"use strict"
var $S = jQuery.noConflict();

function htmlUnescape(str) {
    if (!str) return "";
    var doc = new DOMParser().parseFromString(str, "text/html");
    return doc.documentElement.textContent;
}
function htmlEscape(str) {
    if (!str) return "";
    return str
        .replace(/&/g, "&amp;")
        .replace(/</g, "&lt;")
        .replace(/>/g, "&gt;")
        .replace(/"/g, "&quot;")
        .replace(/'/g, "&#039;");
}

var createItems = {
	
	table: function (data, id, columns, xaxis_column, yaxis_column, columnnames, columncolors, chartlabel, columntosort, sortorder, rowlimit) {
		var dataTemp = data;
		if(columns == undefined || columns == "") {
			$S('#'+id + "Table").html("<tr><td>No data available.</td></tr>");
			return;
		}
		
		var columnsNmaeMap = {};
		var namesColumnMap = {};
		if(columnnames != undefined && columnnames != '') {
			columnnames.split(',').forEach((eachCol) => {
				let keyval = eachCol.split('|');
				columnsNmaeMap[keyval[0]] = keyval[1];
				namesColumnMap[keyval[1]] = keyval[0];
			});
		} else {
			columns.split(',').forEach((eachCol) => {
				columnsNmaeMap[eachCol] = eachCol;
				namesColumnMap[eachCol] = eachCol;
			});
		}

		var tableandcolumns = dataConstruction.tableData(id, columns, columnsNmaeMap);
		var table = tableandcolumns[0];
		var aoColumns = tableandcolumns[1];

		// Adding table to the html
		document.getElementById(id).innerHTML = table;
		
		// Custom column defenition
		var columnsArray = columns.split(',');
		var columnDefs = [];
		var fixInfoColIndex = -1;
		var fixInfoValues = ["reminfo", "fixinfo", "FixInfo", "fix_info"];

		var json = JSON.parse(data);
		var pageInfo = false;

		var jsonData = json[Object.keys(json)[0]];

		if(jsonData && jsonData.length < 4000) {
			for (var i=0; i < columnsArray.length; i++) {
				var columnIndex = i;
				columnDefs.push({
					targets : i,
					data : columnsArray[i],
					title : columnsNmaeMap[columnsArray[i]],       
					render : function (data, type, full, meta){
						if((fixInfoValues.indexOf(columnsArray[columnIndex])) >= 0) {
							fixInfoColIndex = columnIndex;
						}
	
						if (data == undefined || data === "") {
							data = showNoInformationAvailableForTable(dataTemp);
						}
						
						if (fixInfoValues.indexOf(columnsArray[columnIndex]) >= 0) {
							data = htmlUnescape(data); // Only unescape, No escape again
						} else {
							data = htmlEscape(data);
						}
						data = data.replace(/(&lt|&amp|&gt)*(;)*(lt;|br|amp;)*(&lt;|b|&gt)*(&lt;|\/b|&gt;)*(br|&amp|gt;)*(&amp;)*(amp;)*(&gt|gt|amp|lt|&lt|apos)(;)/g, " ");
						return data;
					}
				});
			}
		} else {
			columnDefs = jsonData;
		}
		
		var height = document.getElementById(id).offsetHeight;
		var columntosortindex = columns.split(',').indexOf(columntosort);

		if (columntosortindex < 0)
			columntosortindex = 0;

		if (sortorder == undefined)
			sortorder = 'asc';

		try {
			let order = [];
			if(sortorder != null && (sortorder == "asc" || sortorder == "desc"))
				order = [columntosortindex, sortorder];


			var colDefAry = columnDefs;
			if(jsonData && jsonData.length > 300) { // Adding the pagination to the table if records more than 300
				pageInfo = true;
				//colDefAry = [];
			}

			var tableTitle = $S('#'+id + "Table").parent().closest("li").attr("data-title");

			var dataTable = $S('#'+id + "Table").dataTable({
				"pageLength": 50,
				"paging":   pageInfo,
				"info" : false,
				'order': order,
				"aaData": jsonData,
				"aoColumns": aoColumns,
				"deferRender": true,
				'searching':true,
				"processing": true,
				"bDestroy": true,
				"pagingType": "simple",
				"dom": 'Bfrtip',
				"buttons": [
					{
						extend: "copyHtml5",
						title: tableTitle
					},
					{
						extend: "excelHtml5",
						title: tableTitle
					},
					{
						extend: "csvHtml5",
						title: tableTitle
					},
					{
						extend: "pdfHtml5",
						title: tableTitle
					}
				],
				'rowCallback': function(row, data, dataIndex) {
					$S.each($S('td', row), function (colIndex) {
						var formatData = htmlEscape($S(this).html());
						formatData = formatData.replace(/(&lt|&amp|&gt)*(;)*(lt;|br|amp;)*(&lt;|b|&gt)*(&lt;|\/b|&gt;)*(br|&amp|gt;)*(&amp;)*(amp;)*(&gt|gt|amp|lt|&lt|apos)(;)/g," ");
						var formatDataTitle = formatData.replace(/(&lt;|&gt;|&amp;)/g, " ").replace(/&quot;/g, '"').replace(/&#039;/g, "'").replaceAll(/<br\s*\/?>/g, '\n').replaceAll(/ {3}/g, '\n\n\n').replaceAll(/ {2}/g, '\n\n');
						$S(this).attr('title', formatDataTitle);
						$S(this).html(formatData);
						if(!$S(this).html() || $S(this).html() == undefined || $S(this).html() == 'undefined') $S(this).html("-");
						
						if(fixInfoColIndex != -1 && fixInfoColIndex == colIndex) {
							$S(this).addClass("fixInfoTD");
						}
					});
				},
				"columnDefs": colDefAry
			});

			$S(".dt-buttons").hide();

			if(readymade_report_names.indexOf($S('#reportDisplayName').html().trim()) < 0) {
				var tempHeight = 15;
				if(jsonData && jsonData.length > 300) {
					tempHeight = 25;
				}
				jQuery('#'+id + "Table").wrap('<div class="dataTables_scroll mousescroll style-5" id="'+id+'_TableWrapperDetails"  style="height:'+(height - tempHeight) + 'px'+'" />');
			}

			
			$S("#" + id + "Table_length").hide();
			$S("#" + id + "Table_paginate li").css({"width": "auto","position" : "relative", "top": "-13px","right": "-1px"});
			$S("#" + id + "Table_paginate a").css({"padding": "0 2px", "color": "#3087B9", "border": "1px solid #3087B9"});

			$S('#'+id + "Table_filter").css('display', 'none');
			$S('#'+id + "Table").css('width', '100%');
			$S('#' + id + "Table").on( 'order.dt',  function () { 
				let order = $S('#'+id + "Table").DataTable().order();
				$S("#" + id + "Table_paginate").css({"background": "#edeef1", "height": "12px"})
			$S("#" + id + "Table_paginate li").css({"width": "auto","position" : "relative", "top": "-13px","right": "-1px"});
				$S("#" + id + "Table_paginate a").css({"padding": "0 2px", "color": "#3087B9", "border": "1px solid #3087B9"});

				if(order[0] && order[0].length) {
					$S('#'+id + "Table").closest('li').attr('data-columntosort', namesColumnMap[$S('#' + id + 'Table').find('thead').find('td:nth-of-type(' + (order[0][0] + 1) + ')').html()]);
					$S('#'+id + "Table").closest('li').attr('data-sortorder', order[0][1]);
				}
			});

		} catch(ierr) {
			document.getElementById(id).innerHTML = "<p class='noData'>No data</p>";
		}

		if(readymade_report_names.indexOf($S('#reportDisplayName').html().trim()) >= 0) {
			$S('#'+id + "Table").addClass('readymadeReport');
			$S('#'+id + "Table").addClass('table-striped');
			$S('#'+id + "Table").removeClass('table-bordered');
		}

	},

	summary: function(data, id, columns, xaxis_column, yaxis_column, columnnames, columncolors, chartlabel, columntosort, sortorder) {

		var columnsNmaeMap = {};
		if(columnnames != undefined && columnnames != '') {
			columnnames.split(',').forEach((eachCol) => {
				let keyval = eachCol.split('|');
				columnsNmaeMap[keyval[0]] = keyval[1];
			});
		} else {
			columns.split(',').forEach((eachCol) => {
				columnsNmaeMap[eachCol] = eachCol;
			});
		}

		var height = document.getElementById(id).offsetHeight;

		var res = "";
		
		var columnsArray = columns.split(',');
		var size = 12 / columnsArray.length;
		var className = 'col-md-' + size;
		
		var className = 'col-md-2';
		let widthPercent = 100 / columnsArray.length;

		let json;
		if(data.indexOf('[') >= 0) {
			json = JSON.parse(data);
			json = json[Object.keys(json)[0]][0];
		} else if(data && data.length) {
			json = JSON.parse(data);
		}

		columnsArray.forEach(element => { 
			let div = document.createElement("div");
			div.classList.add(className);
			div.style.margin = 0;
			div.style.top = '50%';
			div.style.transform = 'translateY(-50%)';
			div.style.width =  widthPercent + "%";

			var dataTemp ;
			if(!(json && json[element])) {
				dataTemp = 0;
			} else {
				dataTemp = json[element];
			}

			if (columnsNmaeMap[element] == 'Account Score') {
				dataTemp = Math.floor(dataTemp);
			}

			let summary = $S('#summary-Data-template').text();
			summary = summary.replace('%%Data%%', dataTemp);
			summary = summary.replace('%%Title%%', columnsNmaeMap[element]);
			div.innerHTML = summary;

			res += div.outerHTML;
		});

		document.getElementById(id).innerHTML = res;

	},

	gauge: function(data, id, columns, xaxis_column, yaxis_column, columnnames, columncolors, chartlabel, columntosort, sortorder) {

		var chartHeight = 250;
		var chartRightMargin = 110;
		var chartTopMargin = 50;
		if ($S('#reportDisplayName').text().includes('Risk Assessment Report')) {
			chartHeight = 300;
			chartRightMargin = 0;
			chartTopMargin = 60;
		}

		var columnsNmaeMap = {};
		if(columnnames != undefined && columnnames != '') {
			columnnames.split(',').forEach((eachCol) => {
				let keyval = eachCol.split('|');
				columnsNmaeMap[keyval[0]] = keyval[1];
			});
		} else {
			columns.split(',').forEach((eachCol) => {
				columnsNmaeMap[eachCol] = eachCol;
			});
		}

		let json;
		if(data.indexOf('[') >= 0) {
			json = JSON.parse(data);
		} else if(data && data.length) {
			json = JSON.parse(data);
		}

		var jsonKey = Object.keys(json)[0];
		var dataTemp = _.get(json, `${jsonKey}[0].${columnnames.split('|')[0]}`, 0);

		if (dataTemp != null && dataTemp != undefined) {

			document.getElementById(id).innerHTML = "";

			var chsmeterdata = [
				{
					domain: { x: [0, 1], y: [0, 1] },
					value: Math.floor(dataTemp),
					type: "indicator",
					mode: "gauge+number",
					gauge: {
						axis: { range: [null, 100] },
						bordercolor:"transparent",
						bar: { color: "#00c0ef" },
						steps: [
							{ range: [0, 40], color: "rgba(251, 37, 37, 0.845)" },
							{ range: [40, 80], color: "rgba(230, 230, 44, 0.918)" },
							{ range: [80, 100], color: "rgba(32, 205, 32, 0.9)" },
						],
					},
				}
			];
		
			var layout = { width: 800, height: chartHeight, margin: { l: 0, r: chartRightMargin, t: chartTopMargin, b: 80 }, paper_bgcolor: 'rgba(0,0,0,0)', plot_bgcolor: 'rgba(0,0,0,0)' };
			var config = { displaylogo: false, modeBarButtonsToRemove: ["toImage"] };
			Plotly.newPlot(document.getElementById(id), chsmeterdata, layout, config);

		} else {

			document.getElementById(id).innerHTML = "<p class='noData'>No data</p>";
			
		}

	},

	pie: function (data, id, columns, xaxis_column, yaxis_column, columnnames, columncolors, chartlabel, columntosort, sortorder) {

		var columnsNmaeMap = {};
		var columnsColorMap = {};
		var colors = [];

		function getKeyByValue(object, value) {
			return Object.keys(object).find(key => object[key] === value);
		  }

		//color map for columns
		if(columncolors != undefined && columncolors != '') {
			columncolors.split(',').forEach((eachCol) => {
				let keyval = eachCol.split('|');
				columnsColorMap[keyval[0]] = keyval[1];
			});
		}  
		 
		
		//column name map for columns		
		if(columnnames != undefined && columnnames != '') {
			columnnames.split(',').forEach((eachCol) => {
				let keyval = eachCol.split('|');
				columnsNmaeMap[keyval[0]] = keyval[1];
			});
		} else {
			columns.split(',').forEach((eachCol) => {
				columnsNmaeMap[eachCol] = eachCol;
			});
		}

		let dataArray = dataConstruction.pieData(data, columns, xaxis_column, yaxis_column, columnsNmaeMap);
		
		if(dataArray.length > 0) {
		
		for (var i = 1; i < dataArray.length; i++) {
			var columnName;
				
			if(columnnames != undefined && columnnames != '') {
				columnName = getKeyByValue(columnsNmaeMap,dataArray[i][0]);
			}	
			else{
				columnName = dataArray[i][0];
			}
				var columnColor = columnsColorMap[columnName];
	
				if(columnColor != undefined && columnColor != '')
					colors.push(columnColor);
		}
			
		let drawChart = () => {
			var chartData = google.visualization.arrayToDataTable(dataArray);
	
			var options = {
				//chartArea: {'width': '70%', 'height': '50%'},
				fontFamily: 'Arial',
				fontSize: 11,
				sliceVisibilityThreshold: 0
			};
	
			if(colors != undefined && colors != '')
				options["colors"] = colors;

			var chart = new google.visualization.PieChart(document.getElementById(id));
			chart.draw(chartData, options);
		};

		let intervalId = setInterval(function() {
				if(GoogleChartLibrary.isLoaded) {
						clearInterval(intervalId);
						drawChart();
				}
		}, GoogleChartLibrary.waitTime);

		//google.charts.load('current', {'packages':['corechart']});
		//google.charts.setOnLoadCallback(drawChart);
		}
		else {
			document.getElementById(id).innerHTML = "<p class='noData'>No data</p>";
		}

	},

	pie3d: function (data, id, columns, xaxis_column, yaxis_column, columnnames, columncolors, chartlabel, columntosort, sortorder) {

		var columnsNmaeMap = {};
		if(columnnames != undefined && columnnames != '') {
			columnnames.split(',').forEach((eachCol) => {
				let keyval = eachCol.split('|');
				columnsNmaeMap[keyval[0]] = keyval[1];
			});
		} else {
			columns.split(',').forEach((eachCol) => {
				columnsNmaeMap[eachCol] = eachCol;
			});
		}

		let dataArray = dataConstruction.pieData(data, columns, xaxis_column, yaxis_column, columnsNmaeMap);
		
		if(dataArray.length > 0) {
		let drawChart = () => {
			var chartData = google.visualization.arrayToDataTable(dataArray);
	
			var options = {
				chartArea: {'width': '80%', 'height': '70%'},
				fontFamily: 'Arial',
				fontSize: 11,
				is3D: true
			};
	
			var chart = new google.visualization.PieChart(document.getElementById(id));

			chart.draw(chartData, options);
		};

		let intervalId = setInterval(function() {
				if(GoogleChartLibrary.isLoaded) {
						clearInterval(intervalId);
						drawChart();
				}
		}, GoogleChartLibrary.waitTime);

		//google.charts.load('current', {'packages':['corechart']});
		//google.charts.setOnLoadCallback(drawChart);
		}
		else {
			document.getElementById(id).innerHTML = "<p class='noData'>No data</p>";
		}

	},

	donut: function (data, id, columns, xaxis_column, yaxis_column, columnnames, columncolors, chartlabel, columntosort, sortorder) {

		var columnsNmaeMap = {};
		var columnsColorMap = {};
		var colors = [];
		
		function getKeyByValue(object, value) {
			return Object.keys(object).find(key => object[key] === value);
		}

		//color map for columns
		if(columncolors != undefined && columncolors != '') {
			columncolors.split(',').forEach((eachCol) => {
				let keyval = eachCol.split('|');
				columnsColorMap[keyval[0]] = keyval[1];
			});
		} 

		if(columnnames != undefined && columnnames != '') {
			columnnames.split(',').forEach((eachCol) => {
				let keyval = eachCol.split('|');
				columnsNmaeMap[keyval[0]] = keyval[1];
			});
		} else {
			columns.split(',').forEach((eachCol) => {
				columnsNmaeMap[eachCol] = eachCol;
			});
		}

		let dataArray = dataConstruction.pieData(data, columns, xaxis_column, yaxis_column, columnsNmaeMap);
		
		
		for (var i = 1; i < dataArray.length; i++) {
			var columnName;
			 
			if(columnnames != undefined && columnnames != '') {
				columnName = getKeyByValue(columnsNmaeMap,dataArray[i][0]);
			}	
			else{
				columnName = dataArray[i][0];
			}
		 	var columnColor = columnsColorMap[columnName];
  
		 	if(columnColor != undefined && columnColor != '')
		 		colors.push(columnColor);
		}

		if(dataArray.length > 0) {
			 
		let drawChart = () => {
			var chartData = google.visualization.arrayToDataTable(dataArray);
	
			var options = {
				chartArea: {'width': '80%', 'height': '70%'},
				fontFamily: 'Arial',
				fontSize: 11,
				pieHole: 0.4
			};
	
			if(colors != undefined && colors != '')
				options["colors"] = colors;
	
			var chart = new google.visualization.PieChart(document.getElementById(id));

			chart.draw(chartData, options);
		};

		let intervalId = setInterval(function() {
				if(GoogleChartLibrary.isLoaded) {
						clearInterval(intervalId);
						drawChart();
				}
		}, GoogleChartLibrary.waitTime);

		//google.charts.load('current', {'packages':['corechart']});
		//google.charts.setOnLoadCallback(drawChart);
		}
		else {
			document.getElementById(id).innerHTML = "<p class='noData'>No data</p>";
		}
	},

	bar: function (data, id, columns, xaxis_column, yaxis_column, columnnames, columncolors, chartlabel, columntosort, sortorder) {

		var columnsNmaeMap = {};
		if(columnnames != undefined && columnnames != '') {
			columnnames.split(',').forEach((eachCol) => {
				let keyval = eachCol.split('|');
				columnsNmaeMap[keyval[0]] = keyval[1];
			});
		} else {
			columns.split(',').forEach((eachCol) => {
				columnsNmaeMap[eachCol] = eachCol;
			});
		}

		let dataArray = dataConstruction.barData(data, columns, xaxis_column, yaxis_column, columnsNmaeMap);
		
		if(dataArray.length > 0) {
		
		let drawChart = () => {
			var chartData = google.visualization.arrayToDataTable(dataArray);
	
			var vAxis = yaxis_column.toString();
			var hAxis = xaxis_column[0];
			if(chartlabel != undefined && chartlabel != "") {
				var chartlabelArr = chartlabel.split('|');
				vAxis = chartlabelArr[1];
				hAxis = chartlabelArr[0];
			}

			var options = {
				chartArea: {'width': '70%', 'height': '70%'},
				fontFamily: 'Arial',
				fontSize: 11,
				pieHole: 0.4,
				vAxis: {title: vAxis, minValue: 0},
    			hAxis: {title: hAxis, format: '0'},
    			legend: {position: 'none'}
			};

			if(dataArray.length > 10) {
				options.chartArea.height = "100%";
				var height = dataArray.length * 20;
				document.getElementById(id).style.height = height+"px";
			}
	
			var chart = new google.visualization.BarChart(document.getElementById(id));

			chart.draw(chartData, options);
		};

		let intervalId = setInterval(function() {
				if(GoogleChartLibrary.isLoaded) {
						clearInterval(intervalId);
						drawChart();
				}
		}, GoogleChartLibrary.waitTime);

		//google.charts.load('current', {'packages':['corechart']});
		//google.charts.setOnLoadCallback(drawChart);
		}
		else {
			document.getElementById(id).innerHTML = "<p class='noData'>No data</p>";
		}

	},

	column: function (data, id, columns, xaxis_column, yaxis_column, columnnames, columncolors, chartlabel, columntosort, sortorder, charttooltip) {

		var columnsNmaeMap = {};
		var columnsColorMap = {};

		function getKeyByValue(object, value) {
			return Object.keys(object).find(key => object[key] === value);
		}

		//color map for columns
		if(columncolors != undefined && columncolors != '') {
			columncolors.split(',').forEach((eachCol) => {
				let keyval = eachCol.split('|');
				columnsColorMap[keyval[0]] = keyval[1];
			});
		}

		if(columnnames != undefined && columnnames != '') {
			columnnames.split(',').forEach((eachCol) => {
				let keyval = eachCol.split('|');
				columnsNmaeMap[keyval[0]] = keyval[1];
			});
		} else {
			columns.split(',').forEach((eachCol) => {
				columnsNmaeMap[eachCol] = eachCol;
			});
		}

		let dataArray = dataConstruction.barData(data, columns, xaxis_column, yaxis_column, columnsNmaeMap, charttooltip);

		if(dataArray.length > 0) {
		 
		let drawChart = () => {
			if(columncolors != undefined && columncolors != "undefined" && columncolors != "")
			{
				for(i=0;i<dataArray.length;i++)
				{
					if(i==0) dataArray[i].push({ role: 'style' });
					else
					{
						var columnColor;	
						columnColor = columnsColorMap.hasOwnProperty(dataArray[i][0])? columnsColorMap[dataArray[i][0]]: columnsColorMap[getKeyByValue(dataArray[i][0])];
						if(columnColor != undefined && columnColor !='') 
							dataArray[i].push(columnColor);
					}
	
				}
			}
			
			var chartData = google.visualization.arrayToDataTable(dataArray);
			if (charttooltip) chartData.setColumnProperty(2, 'role', 'tooltip');
			var vAxis = yaxis_column.toString();
			var hAxis = xaxis_column[0];
			if(chartlabel != undefined && chartlabel != "") {
				var chartlabelArr = chartlabel.split('|');
				vAxis = chartlabelArr[1];
				hAxis = chartlabelArr[0];
			}

			var hAxisdata = {title: hAxis}
               if (dataArray.length>15) {
				hAxisdata={...hAxisdata, slantedText: true};
			   }
			var options = {
				chartArea: {'width': '90%', 'height': '70%', 'bottom': '20%'},
				fontFamily: 'Arial',
				fontSize: 11,
				pieHole: 0.4,
				vAxis: {title: vAxis, minValue: 0},
    			hAxis: hAxisdata,
    			legend: {position: 'none'}
			
			};
	
			var chart = new google.visualization.ColumnChart(document.getElementById(id));

			chart.draw(chartData, options);
		};

		let intervalId = setInterval(function() {
				if(GoogleChartLibrary.isLoaded) {
						clearInterval(intervalId);
						drawChart();
				}
		}, GoogleChartLibrary.waitTime);

		//google.charts.load('current', {'packages':['corechart']});
		//google.charts.setOnLoadCallback(drawChart);
		}
		else {
			document.getElementById(id).innerHTML = "<p class='noData'>No data</p>";
		}

	},

	area: function (data, id, columns, xaxis_column, yaxis_column, columnnames, columncolors, chartlabel, columntosort, sortorder) {

		var columnsNmaeMap = {};
		if(columnnames != undefined && columnnames != '') {
			columnnames.split(',').forEach((eachCol) => {
				let keyval = eachCol.split('|');
				columnsNmaeMap[keyval[0]] = keyval[1];
			});
		} else {
			columns.split(',').forEach((eachCol) => {
				columnsNmaeMap[eachCol] = eachCol;
			});
		}

		let dataArray = dataConstruction.barData(data, columns, xaxis_column, yaxis_column, columnsNmaeMap);
		
		if(dataArray.length > 0) {
		let drawChart = () => {
			var chartData = google.visualization.arrayToDataTable(dataArray);
	
			var vAxis = yaxis_column.toString();
			var hAxis = xaxis_column[0];
			if(chartlabel != undefined && chartlabel != "") {
				var chartlabelArr = chartlabel.split('|');
				vAxis = chartlabelArr[1];
				hAxis = chartlabelArr[0];
			}

			var options = {
				chartArea: {'width': '90%', 'height': '70%', 'bottom': '20%'},
				fontFamily: 'Arial',
				fontSize: 11,
				pieHole: 0.4,
				pointSize: 2,
				vAxis: {title: vAxis, minValue: 0},
    			hAxis: {title: hAxis},
    			legend: {position: 'none'},
				series: {
					1: {color: '#20cd20'}
				}
			};
			
			if(dataArray.length > 5) {
				options.hAxis.slantedText = true;
				options.hAxis.slantedTextAngle = 45;
			}
	
			var chart = new google.visualization.AreaChart(document.getElementById(id));

			chart.draw(chartData, options);
		};

		let intervalId = setInterval(function() {
				if(GoogleChartLibrary.isLoaded) {
						clearInterval(intervalId);
						drawChart();
				}
		}, GoogleChartLibrary.waitTime);

		//google.charts.load('current', {'packages':['corechart']});
		//google.charts.setOnLoadCallback(drawChart);
		}
		else {
			document.getElementById(id).innerHTML = "<p class='noData'>No data</p>";
		}

	},

	line: function (data, id, columns, xaxis_column, yaxis_column, columnnames, columncolors, chartlabel, columntosort, sortorder) {
		var columnsNmaeMap = {};
		var columnsColorMap = {};
		var colors = [];
		
		function getKeyByValue(object, value) {
			return Object.keys(object).find(key => object[key] === value);
		}
	
		//color map for columns
		if(columncolors != undefined && columncolors != '') {
			columncolors.split(',').forEach((eachCol) => {
				let keyval = eachCol.split('|');
				columnsColorMap[keyval[0]] = keyval[1];
			});
		}   
	
		//column name map for columns
		if(columnnames != undefined && columnnames != '') {
			columnnames.split(',').forEach((eachCol) => {
				let keyval = eachCol.split('|');
				columnsNmaeMap[keyval[0]] = keyval[1];
			});
		} else {
			columns.split(',').forEach((eachCol) => {
				columnsNmaeMap[eachCol] = eachCol;
			});
		}
	
		let dataArray = dataConstruction.barData(data, columns, xaxis_column, yaxis_column, columnsNmaeMap);
		
		if(dataArray.length > 0) {
			for(var i=0; i<dataArray[0].length; i++) {
				var columnColor;    
				columnColor = columnsColorMap.hasOwnProperty(dataArray[0][i])? columnsColorMap[dataArray[0][i]]: columnsColorMap[getKeyByValue(dataArray[0][i])];
				if(columnColor != undefined && columnColor !='') 
					colors.push(columnColor); 
			}
			
			let drawChart = () => {
				var data = new google.visualization.DataTable();
				var xAxisMappedName = columnsNmaeMap[xaxis_column[0]] || xaxis_column[0];
				var yAxisMappedName = columnsNmaeMap[yaxis_column] || yaxis_column;
	
				// Add columns
				data.addColumn('number', xAxisMappedName);
				data.addColumn('number', yAxisMappedName);
				data.addColumn({type: 'string', role: 'tooltip'});
	
				// Add rows with custom tooltips
				dataArray.slice(1).forEach(row => {
					data.addRow([
						parseFloat(row[0]),
						parseFloat(row[1]),
						xAxisMappedName + ': ' + row[0] + '\n' + 
						yAxisMappedName + ': ' + row[1]
					]);
				});
	
				var options = {
					chartArea: {'width': '90%', 'height': '70%'},
					fontFamily: 'Arial',
					fontSize: 11,
					pointSize: 2,
					vAxis: {
						title: yAxisMappedName,
						minValue: 0
					},
					hAxis: {
						title: xAxisMappedName
					},
					legend: {position: 'none'},
					tooltip: {
						trigger: 'focus'
					}
				};
	
				if(colors != undefined && colors != '')
					options["colors"] = colors;
				
				var chart = new google.visualization.LineChart(document.getElementById(id));
				chart.draw(data, options);
			};
	
			let intervalId = setInterval(function() {
				if(GoogleChartLibrary.isLoaded) {
					clearInterval(intervalId);
					drawChart();
				}
			}, GoogleChartLibrary.waitTime);
		}
		else {
			document.getElementById(id).innerHTML = "<p class='noData'>No data</p>";
		}
	},

	stack: function (data, id, columns, xaxis_column, yaxis_column, columnnames, columncolors, chartlabel, columntosort, sortorder) {
		var columnsNmaeMap = {};
		if(columnnames != undefined && columnnames != '') {
			columnnames.split(',').forEach((eachCol) => {
				let keyval = eachCol.split('|');
				columnsNmaeMap[keyval[0]] = keyval[1];
			});
		} else {
			columns.split(',').forEach((eachCol) => {
				columnsNmaeMap[eachCol] = eachCol;
			});
		}

		let dataArray = dataConstruction.barData(data, columns, xaxis_column, yaxis_column, columnsNmaeMap);

		let colorJson = {}
		if (columncolors) {
		columncolors.split(",").forEach(item => {
			let eachColor = item.split("|");
			colorJson[eachColor[0]] = eachColor[1];
		});
		}

		let seriesColor = {};
		dataArray[0].slice(1,).forEach((item, index) => {
			seriesColor[index] = {color: colorJson[item]}
		});

		if(dataArray.length > 0) {
		let drawChart = () => {
			var chartData = google.visualization.arrayToDataTable(dataArray);
	
			var vAxis = yaxis_column.toString();
			var hAxis = xaxis_column[0];
			if(chartlabel != undefined && chartlabel != "") {
				var chartlabelArr = chartlabel.split('|');
				vAxis = chartlabelArr[1];
				hAxis = chartlabelArr[0];
			}

			var options = {
				chartArea: {'width': '90%', 'height': '70%', 'bottom': '20%'},
				fontFamily: 'Arial',
				fontSize: 11,
				pieHole: 0.4,
				vAxis: {title: vAxis, minValue: 0},
				hAxis: {title: hAxis},
				legend: {position: 'none'},
				isStacked: true,
				series: seriesColor
			};
	
			var chart = new google.visualization.ColumnChart(document.getElementById(id));

			chart.draw(chartData, options);
		};

		let intervalId = setInterval(function() {
				if(GoogleChartLibrary.isLoaded) {
						clearInterval(intervalId);
						drawChart();
				}
		}, GoogleChartLibrary.waitTime);

		//google.charts.load('current', {'packages':['corechart']});
		//google.charts.setOnLoadCallback(drawChart);
		}
		else {
			document.getElementById(id).innerHTML = "<p class='noData'>No data</p>";
		}

	},

};


var showNoInformationAvailableForTable = (dataTemp) => {
	var data = JSON.parse(dataTemp)
	var metadata = _.get(data, "metadata", "");
	if(metadata && Object.keys(metadata).length) {
		var paID = _.get(metadata, "id", "");
		if(paID && paID.length) {
			return "No Information Available";
		}
	} else {
		return "-";
	}
}
