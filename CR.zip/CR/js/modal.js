"use strict"
var $S = jQuery.noConflict();

var modal = {
	createNew: function (id, size, title, body, footer) {
		// Creating Modal
        var modal_template = $S('#modal-template').text();
        modal_template = modal_template.replace('%%modal-id%%', id);
        modal_template = modal_template.replace('%%modal-size%%', size);
        modal_template = modal_template.replace('%%modal-title%%', title);
        modal_template = modal_template.replace('%%modal-body%%', body);
        modal_template = modal_template.replace('%%modal-footer%%', footer);

        return modal_template;
	}
};
