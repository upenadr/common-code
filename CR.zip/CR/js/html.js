"use strict"
var $S = jQuery.noConflict();

var html = {

    createFontAwesomeIcon: function (name) {
        let i = document.createElement('i');
        i.classList.add('fa');
        i.classList.add(name); //fa-window-restore
        i.setAttribute('aria-hidden', 'true');
        return i;
    },

    createAnchorTag: function (classNames, onclick, id, href) {
        let a = document.createElement('a');
    
        if(id != undefined && id != '') {
            a.id = id;
        }
    
        if(classNames != undefined && classNames != '') {
            classNames.split(',').forEach(function (item) {
                a.classList.add(item);
            });
        }

        if(readymade_report_names.indexOf($S('#reportDisplayName').html().trim()) >= 0) {
            a.classList.add('readymadeReport');
        }
    
        if(href != undefined && href != '') {
            a.href = href;
        }
    
        if(onclick != undefined && onclick != '') {
            a.onclick = 'onclick';
        }
    
        return a;
    }

};
