"use strict"
var $S = jQuery.noConflict();
var _spin = '<div class="overlay vertical-center" style="left: 0;min-height: 50%;__custom-margin-top__"><i class="fa fa-refresh fa-spin" style="font-size: xx-large;"></i></div>';
var canned_reports = ['Executive Report', 'Vulnerability Report', 'Asset Report', 'Patch Report', 'Compliance Report', 'Posture Anomaly Report', 'Endpoint Management Report', 'Risk Prioritization Report', 'Organization Risk Prioritization Report'];
var readymade_report_names = ['Risk Assessment Report', 'Patch Impact Report', 'Organization Risk Assessment Report', 'Organization Patch Impact Report', 'Posture Anomaly Report', 'Risk Prioritization Report', 'Organization Risk Prioritization Report', 'Executive Report', 'Vulnerability Report', 'Asset Report', 'Patch Report', 'Compliance Report', 'Endpoint Management Report','Remediation SLA Report'];

var gridOptions = {
	currentSize: 12,
	direction: "vertical",
	location: {},
	width: 0,
	height: 0,
	containerHeight: 0,
	count: 0,
	resize: function (size) {
		if (size) {
			this.currentSize = size;
		}
		$S('#grid').gridList('resize', this.currentSize);
	},

	flashItems: function (items) {
		//Hack to flash changed items visually
		for (var i = 0; i < items.length; i++) {
			(function ($element) {
				$element.addClass('changed')
				setTimeout(function () {
					$element.removeClass('changed');
				}, 0);
			})(items[i].$element);
		}
	}
};

var gridListElements = {
	elementHTML: "",
	headerHTML: "",
	bodyHTML: "",
	gridBeforeHTML: '<li id="__ID__" data-w="__WIDTH__" data-h="__HEIGHT__" data-x="__XAXIS__" data-y="__YAXIS__" __FUNCTION_ATTRIBUTES__><div class="inner __READYMADE_CLASS__">',
	gridAfterHTML: "</div></li>",

	createTable: function (title, functionName, width, height) {
		this.elementHTML = window["VM" + functionName]();
	},

	addElementToHTML: function () {
		$S('#grid').append(this.elementHTML);
	},

	refreshGridList: function () {
		
		$S('#grid').gridList({
			direction: gridOptions.direction,
			lanes: gridOptions.currentSize,
			widthHeightRatio: 264 / 294,
			heightToFontSizeRatio: 0.25,
			onChange: function (changedItems) {
				gridOptions.flashItems(changedItems);
			}
		});

	},

	setWidthAndHeight: function (width, height) {
		// random string
		let rand = [...Array(10)].map(i=>(~~(Math.random()*36)).toString(36)).join('');
		this.gridBeforeHTML = this.gridBeforeHTML.replace("__WIDTH__", width).replace("__HEIGHT__", height).replace("__ID__", 'li'+rand);
	},

	getLocation: function(w) {
		var x;var y;

		if(jQuery.isEmptyObject(gridOptions.location)) {

			let values = {};
			let value = {};
			value['x'] = 0;
			value['y'] = 0;
			value['l'] = parseInt(w);
			value['w'] = parseInt(w);
			values[0] = value;

			x = value['x'];
			y = value['y'];

			gridOptions.location['0'] = values;

		} else {

			var loc_found = false;
			var next_key = "";
			var div_height = 2;

			for (var key in gridOptions.location) {

				next_key = key;

				var eachvalues = gridOptions.location[key];

				var topLength = 0;
				var topLengthKey;
				for (var eachvaluesKey in eachvalues) {
					if(topLength < eachvalues[eachvaluesKey]['l']) {
						topLength = eachvalues[eachvaluesKey]['l'];
						topLengthKey = eachvaluesKey;
					}
					
				}

				if(topLength < gridOptions.currentSize && (topLength + parseInt(w)) <= 12) {

					let value = {};
					value['x'] = parseInt(key);
					var yData = _.get(eachvalues[0],"y");
					var wData = _.get(eachvalues[0],"w");
 					value['y'] = yData + wData;
 					value['l'] = yData + wData + parseInt(wData);
 					value['w'] = parseInt(wData);
					// value['y'] = eachvalues[topLengthKey]['y'] + eachvalues[topLengthKey]['w'];
					// value['l'] = eachvalues[topLengthKey]['y'] + eachvalues[topLengthKey]['w'] + parseInt(w);
					// value['w'] = parseInt(w);
					
					gridOptions.location[key][++topLengthKey] = value;
					loc_found = true;
					x = value['x'];
					y = value['y'];

				}
				
			}

			if(readymade_report_names.indexOf($S('#reportDisplayName').html().trim()) >= 0) {
				div_height = 4;
			}

			if(!loc_found) {
				let next = parseInt(next_key) + div_height;

				let values = {};
				let value = {};
				value['x'] = next;
				value['y'] = 0;
				value['l'] = parseInt(w);
				value['w'] = parseInt(w);
				values[0] = value;
				
				gridOptions.location[next + ''] = values;
				x = value['x'];
				y = value['y'];

			}

		}

		return [x, y];
	},

	setXAndYAxis: function (x, y, w, h) {

		var location = this.getLocation(w);
		x = location[0];
		y = location[1];

		this.gridBeforeHTML = this.gridBeforeHTML.replace("__XAXIS__", y).replace("__YAXIS__", x);
	},

	setFunctionAttributes: function (fname, columns, columnstodisplay, type, chartxaxis, chartyaxis, title, description, filters,accountsfilter, devicefilter, assetfilterflag,createdbyfilterflag, assetfilter,createdbyfilter, patchfilter, assetexcludefilter,createdbyexcludefilter, familyfilter, columnnames, columncolors ,chartlabel, module, ogtitle, columntosort, sortorder, rowlimit, datatype, mergetype, mergekey, sortkeys, ascendingorder, limit, data_operations, sortcolumnformat,charttooltip, startdatefilter, enddatefilter, tagfilter, installedstartdatefilter, installedenddatefilter, releasedstartdatefilter, releasedenddatefilter) {
		var reportTitle = title;
		var reportDesc = description;

		if(reportTitle && reportTitle.length) {
			reportTitle = reportTitle.replace(/"/g, '\'');
		}

		if(reportDesc && reportDesc.length) {
			reportDesc = reportDesc.replace(/"/g, '\'');
		}
		if(accountsfilter == undefined || accountsfilter == "undefined"){
			accountsfilter = "";
		}

		if(tagfilter && tagfilter.length) {
			tagfilter = tagfilter.replace(/"/g, '\'');
		}

var data = 'data-module="'+module+'" data-chartlabel="'+chartlabel+'" data-columnnames="'+columnnames+'" data-columncolors="'+columncolors+'"  data-columntosort="'+columntosort+'" data-sortorder="'+sortorder+'" data-familyfilter="'+familyfilter+'" data-accountsfilter="'+accountsfilter+'" data-devicefilter="'+devicefilter+'" data-tagfilter="'+tagfilter+'" data-installedstartdatefilter="'+installedstartdatefilter+'" data-installedenddatefilter="'+installedenddatefilter+'" data-releasedstartdatefilter="'+releasedstartdatefilter+'" data-releasedenddatefilter="'+releasedenddatefilter+'" data-startdatefilter="'+startdatefilter+'" data-enddatefilter="'+enddatefilter+'" data-rowlimit="'+rowlimit+'" data-assetfilterflag="'+assetfilterflag+'" data-createdbyfilterflag="'+createdbyfilterflag+'" data-assetfilter="'+assetfilter+'" data-createdbyfilter="'+createdbyfilter+'" data-patchfilter="'+patchfilter+'" data-assetexcludefilter="'+assetexcludefilter+'" data-createdbyexcludefilter="'+createdbyexcludefilter+'" data-filters="'+filters+'" data-title="'+reportTitle+'" data-ogtitle="'+ogtitle+'" data-description="'+reportDesc+'" data-chartxaxis="'+chartxaxis+'" data-chartyaxis="'+chartyaxis+'" data-type="'+type+'" data-fname="'+fname+'" data-columns="'+columns+'" data-columnstodisplay="'+columnstodisplay+'" data-datatype="'+datatype+'" data-mergetype="'+mergetype+'" data-mergekey="'+mergekey+'" data-sortkeys="'+sortkeys+'" data-ascendingorder="'+ascendingorder+'" data-limit="'+limit+'" data-operations="' + data_operations + '"  data-sortcolumnformat="'+sortcolumnformat+'"';
		this.gridBeforeHTML = this.gridBeforeHTML.replace("__FUNCTION_ATTRIBUTES__", data);
	},
	
	constructHeader: function (heading, id ,filters, description, columnstodisplay, type, accountsfilter, devicefilter, assetfilterflag,createdbyfilterflag, assetfilter,createdbyfilter, patchfilter, assetexcludefilter,createdbyexcludefilter, familyfilter, rowlimit, tagfilter) {
		var div = document.createElement('div');
		div.classList.add('col-md-12');
		div.classList.add('grid-header');

		if(readymade_report_names.indexOf($S('#reportDisplayName').html().trim()) >= 0) {
			div.classList.add('readymadeReport');

			// Title
			if(heading && heading.length) {
				let h4 = document.createElement('h4');
				let h4span = document.createElement('span');
				if (description=="Sample heading, This needs change") {
					h4span.style.fontSize="20px"
					h4span.style.color = "var(--secpod-dark-blue-color)"
				}
				h4span.title = heading;
	
				h4span.appendChild(document.createTextNode(heading));
				h4.appendChild(h4span);
	
				div.appendChild(h4);
			}

			// Description
			let descDiv = document.createElement('div');
			let descH4 = document.createElement('h5');

			if(description != undefined) {
				descH4.appendChild(document.createTextNode(description.replaceAll('\\n', ' \n ')));
			} else {
				descH4.appendChild(document.createTextNode(description));
			}
			
			descDiv.appendChild(descH4);
			descDiv.style.display = 'inline-block';
			descDiv.style.width = '100%';

			div.appendChild(descDiv);

		}	else {
			
			let h4 = document.createElement('h4');
			let h4span = document.createElement('span');
			h4span.title = heading;

			if(screen.availWidth <= 1366 & screen.availHeight <= 768){
				if(heading.length > 30) heading = heading.slice(0, 30) + "...";
			}

			h4span.appendChild(document.createTextNode(heading));
			h4.appendChild(h4span);

			let edita = document.createElement('a');
			edita.classList.add('reportMenuItemsNameEditModal');
			edita.setAttribute('data-parent', id);

			let editspan = document.createElement('span');
			editspan.title = 'Edit';
			editspan.classList.add('fa-solid'); 
			editspan.classList.add('fa-pen-to-square');
			editspan.style.fontSize = '12px';
			editspan.style.color = '#3087B9';

			edita.appendChild(editspan);
			h4.appendChild(edita);
			
			div.appendChild(h4);

			// Hiding icons for Charts
			if(columnstodisplay === "onlychart" || type === "summary") {

			}

			// For Close
			{
				let a = html.createAnchorTag('reportHeaderIcons,reportMenuItemsClose');
				let i = html.createFontAwesomeIcon('fa-times');
				a.appendChild(i);
				a.title = 'Close';
				div.appendChild(a);
			}

			// For Drag and drop
			{
				let a = html.createAnchorTag('reportHeaderIcons,reportMenuItemsDragHandle');
				let i = html.createFontAwesomeIcon('fa-arrows'); //fa-window-restore
				a.appendChild(i);
				a.title = 'Move';
				div.appendChild(a);
			}
			
			// For Resize
			{
				let a = html.createAnchorTag('reportHeaderIcons,reportMenuItemsResize');
				a.setAttribute('data-parent', id);
				let i = html.createFontAwesomeIcon('fa-window-restore'); //fa-window-restore
				a.appendChild(i);
				a.title = 'Resize';
				div.appendChild(a);
			}
			
			// For Column Filter
			{
				let a = html.createAnchorTag('reportHeaderIcons,reportMenuItemsColumnsFilter');
				a.setAttribute('data-parent', id);
				let i = html.createFontAwesomeIcon('fa-table');
				a.appendChild(i);
				if(columnstodisplay === "onlychart" || type === "summary") a.classList.add("visually-hidden");
				a.title = 'Add or Remove table columns';
				div.appendChild(a);
			}

			// For PIE Chart
			/*
			{
				let a = html.createAnchorTag('reportHeaderIcons,reportMenuItemsChart');
				a.setAttribute('data-parent', id);
				let i = html.createFontAwesomeIcon('fa-pie-chart');
				a.appendChild(i);
				if(columnstodisplay === "onlychart" || type === "summary") a.classList.add("visually-hidden");
				a.title = 'Chart configurations';
				div.appendChild(a);
			}
			*/

			// For Device Filter
			{
				let a = html.createAnchorTag('reportHeaderIcons,reportMenuItemsDeviceFilter');
				a.setAttribute('data-parent', id);
				let i = html.createFontAwesomeIcon('fa-filter');
				a.appendChild(i);
				if(filters == "") a.classList.add("visually-hidden");
				
				if(familyfilter === 'windows,unix,macos') familyfilter = '';
				if((accountsfilter != "" && accountsfilter != undefined)  || devicefilter != "" || (tagfilter != "" && tagfilter != undefined) || familyfilter != "" || (assetfilter != "" && assetfilter != undefined && assetfilter != "undefined")||(createdbyfilter !="" && createdbyfilter !=undefined) || (patchfilter != "" && patchfilter != undefined && patchfilter != "undefined")) {
					a.style.color = 'rgb(240, 46, 46)';
				} else {
					a.style.color = 'var(--secpod-default-color-blue)';
				}

				a.title = 'Device and family filter';

				div.appendChild(a);
			}

			// For CSV Download
			{
				let a = html.createAnchorTag('reportHeaderIcons,reportMenuItemsCSVDownload');
				a.setAttribute('data-parent', id);
				let i = html.createFontAwesomeIcon('fa-file-text');
				a.appendChild(i);
				if(columnstodisplay === "onlychart" || type === "summary") a.classList.add("visually-hidden");

				a.title = 'CSV download';

				div.appendChild(a);
			}

			//For Limiting the no. of rows
			{
				let a = html.createAnchorTag('reportHeaderIcons,reportMenuItemsLimit');
				a.setAttribute('data-parent', id);
													//    padding-left: 0;
													a.style.paddingLeft = "0";
				//let i = html.createFontAwesomeIcon('fa-search');
				//a.appendChild(i);
				a.innerHTML = $S('#rowlimit-template').text().replace(/%%id%%/g, id+'rowlimit');
				
													if(type !== "table")
															a.classList.add("visually-hidden");
				a.title = 'LimitSelection';
				div.appendChild(a);
			}

			// For search
			{
				let a = html.createAnchorTag('reportHeaderIcons,reportMenuItemsSearch');
				a.setAttribute('data-parent', id);
				//let i = html.createFontAwesomeIcon('fa-search');
				//a.appendChild(i);

				a.innerHTML = $S('#search-template').text().replace(/%%id%%/g, id+'Search').replace('%%table%%', id+'Table');
				if(columnstodisplay === "onlychart" || type === "summary") a.classList.add("visually-hidden");

				a.title = 'Search';
				
				div.appendChild(a);
			}
		}
		
		
		this.headerHTML = div.outerHTML;

		if (rowlimit != undefined)
				$S('.limitSelect option[value="' + rowlimit + '"]')
		//$S('.limitSelect').tokenize2({
		//    dataSource:'select',
		//    searchFromStart:false,
		//    searchMinLength: 0,
		//    tokensAllowCustom:true
		//});

	},

	constructBody: function (id, className, height) {

		var div = document.createElement("div");
		div.classList.add('col-md-12');
		div.classList.add('grid-body');
		div.classList.add('style-5');
		div.setAttribute('id', id);
		div.style.paddingBottom = '10px';
		
		if (className != "") {
			div.classList.add(className);
		}

		//div.innerHTML = _spin.replace("__custom-margin-top__", "margin-top: " + ((height * 100) - 50) + "px");
		div.innerHTML = _spin.replace("__custom-margin-top__", "margin-top: 50px");

		this.bodyHTML = div.outerHTML;

	},

	addHTMLToPage: function () {

		// Adding Header and footer
		this.elementHTML += this.gridBeforeHTML + this.headerHTML;
		this.elementHTML += this.bodyHTML;
		this.elementHTML += this.gridAfterHTML;

		this.addElementToHTML();

		if(readymade_report_names.indexOf($S('#reportDisplayName').html().trim()) < 0) {
			gridOptions.location = {};

			//var grid=getListIdsInOrder();
			//for (var i = 0; i < grid.length; i++) {
			var grid = $S("#grid li");
			for (var i = 0; i < grid.length; i++) {
			//for (var i = grid.length-1; i >= 0; i--) {
			
				var eachId = grid[i].getAttribute("id");
				//var eachId = grid[i];
				if(eachId.indexOf("next")>=0){}
				else if(eachId.indexOf("previous")>=0){}
				else{
					var location = gridListElements.getLocation($S('#'+eachId).data('w'));
				var x = location[0];
				var y = location[1];

				$S('#'+eachId).attr('data-x', y);
				$S('#'+eachId).attr('data-y', x);
				}
				

			}
			
			this.refreshGridList();
		}

	},

	create: function (
		installedstartdatefilter, installedenddatefilter, releasedstartdatefilter, releasedenddatefilter, tagfilter, startdatefilter, enddatefilter, charttooltip, heading, type, fname, width, height, 
		xaxis, yaxis, id, className, columns, 
		columnstodisplay, chartxaxis, chartyaxis,
		description, filters,accountsfilter, devicefilter, assetfilterflag,createdbyfilterflag,assetfilter,createdbyfilter,patchfilter,assetexcludefilter,createdbyexcludefilter, 
		familyfilter, columnnames, columncolors, chartlabel,module,emqueries,ogtitle,
	        columntosort, sortorder, rowlimit, datatype, mergetype, mergekey, sortkeys, ascendingorder, limit, data_operations, sortcolumnformat, PA_ID) {
		$S('.newReporthelpMessage').parent('div').parent('div').remove();

		// Servise provison check

		if(module !=  "Device") {
			if(module != undefined && ($S('#spUI').html().trim()).indexOf("-%" + module + "%-") < 0 ) 
				return;
		}

		// random string
		let rand = [...Array(10)].map(i=>(~~(Math.random()*36)).toString(36)).join('');

		
		let readymadeClass = "";

		if(readymade_report_names.indexOf($S('#reportDisplayName').html().trim()) >= 0) {
			readymadeClass = "readymadeReport";
			width = 12;
			height = 4;
		}
		this.gridBeforeHTML = this.gridBeforeHTML.replace("__READYMADE_CLASS__", readymadeClass)
		
		
		// Setting values
		this.setWidthAndHeight(width, height);
		this.setXAndYAxis(xaxis, yaxis, width, height);
		this.setFunctionAttributes(fname, columns, columnstodisplay, type, chartxaxis, chartyaxis, heading, description, 
					filters,accountsfilter, devicefilter, assetfilterflag,createdbyfilterflag, assetfilter,createdbyfilter, patchfilter, assetexcludefilter,createdbyexcludefilter, familyfilter, columnnames, columncolors, 
					chartlabel, module, ogtitle, columntosort, sortorder, rowlimit, datatype, mergetype, mergekey, sortkeys, ascendingorder, limit, data_operations, sortcolumnformat, charttooltip, startdatefilter, enddatefilter, tagfilter, installedstartdatefilter, installedenddatefilter, releasedstartdatefilter, releasedenddatefilter);
		
		this.constructHeader(heading, 'id'+rand, filters, description, columnstodisplay, type, accountsfilter, devicefilter, assetfilterflag,createdbyfilterflag, assetfilter,createdbyfilter, patchfilter, assetexcludefilter,createdbyexcludefilter, familyfilter, rowlimit, tagfilter);
		this.constructBody('id'+rand, className, height);
		this.addHTMLToPage();

		var idName = 'id'+rand;
		if(accountsfilter == undefined || accountsfilter == "undefined"){
			accountsfilter = "";
		}

		if(tagfilter == undefined || tagfilter == "undefined") {
			tagfilter = "";
		}

		if(rowlimit == undefined && type == "table") {
			rowlimit = -1;
		}

		$S("#"+idName).parent().find(".reportMenuItemsLimit .limitSelect").val(rowlimit);


		var args = {};
		args['deviceList'] = devicefilter;
		args['tagList'] = tagfilter;
		args['accountNamesList'] = accountsfilter;

		args['installedstartdatefilter'] = installedstartdatefilter;
		args['installedenddatefilter'] = installedenddatefilter;
		args['releasedstartdatefilter'] = releasedstartdatefilter;
		args['releasedenddatefilter'] = releasedenddatefilter;

		args['assetFilterFlag'] = assetfilterflag;
		args['createdbyfilterflag'] = createdbyfilterflag;
		args['assetList'] = assetfilter;
		args['createdbyList'] = createdbyfilter;
		args['patchList'] = patchfilter;
		args['assetExcludeList'] = assetexcludefilter;
		args['createdbyExcludeList'] = createdbyexcludefilter;
		args['familyList'] = familyfilter;
		args['rowLimit'] = rowlimit;
		args['columnToSort'] = columntosort;
		args['sortcolumnformat'] = sortcolumnformat;
		args['sortOrder'] = sortorder;
		args['data_operations'] = data_operations;
		if(datatype) args['datatype'] = datatype;
		if(mergetype) args['mergetype'] = mergetype;
		if(mergekey) args['mergekey'] = mergekey;

		if(sortkeys) args['sortkeys'] = sortkeys;
		if(ascendingorder) args['ascendingorder'] = ascendingorder;
		if(limit) args['limit'] = limit;

		if(emqueries === "true" || emqueries == true) {
			args['queryName'] = ogtitle;
		}

		var moduleType = module;

		if(module == "Device") {
			moduleType = "DM";
		}

		args["moduleType"] = moduleType;

		var reportName = $S('#reportDisplayName').html().trim();

		if(fname == undefined) {
			return;
		}

		//var url = "CRcontrol.jsp?command=" + fname
		var url = "CRcontrol.jsp?command=getApiDataInJson&fname=" + fname;

		if(chartxaxis == undefined) chartxaxis = "";
		if(chartyaxis == undefined) chartyaxis = "";
		// Get data from server
		server.getData(function (data) {
			if(reportName === "Posture Anomaly Report") {
				var dataObj = data.length ? data : "{}";
				var parseData = JSON.parse(dataObj);
				var responseLength = _.get(parseData, "paresponse", []).length;
				if(!responseLength && PA_ID != "ALL") {
					data = "";
                    $S("#"+idName).parent().parent().hide();
					return;
				}
				
				var summary = _.get(parseData, "metadata.summary", "");
				if(readymadeClass == "readymadeReport" && summary.length) {
					parseData = _.omit(parseData, "metadata.summary");
					data = JSON.stringify(parseData);
					$S("#"+idName).parent().find(".grid-header").append(`<div style="margin-top: 10px; font-size: 15px;"><b>Summary:</b> ${summary.replaceAll("[", "<b>").replaceAll("]", "</b>")}</div>`);
				}
			}
	
			try {
				if (data != null && data != undefined && data.toString().length===0) {
					$S(`#id${rand}`).html('<div style="display: flex; justify-content: center; align-items: center; height: 100%; text-align: center;">No info available</div>');
				}else
				createItems[type](data, 'id'+rand, columnstodisplay, chartxaxis.split(','), chartyaxis.split(','), columnnames, columncolors ,chartlabel, columntosort, sortorder, charttooltip);
			} catch(err) {
				
			}
			

			if(type == 'summary') {
				// start all the timers
				$S('#id'+rand).find('.timer').each(count);
			}

			data = "";

		}, url, args);

		// For Counter.js
		$S('.count-number').data('countToOptions', {
			formatter: function (value, options) {
			  return value.toFixed(options.decimals).replace(/\B(?=(?:\d{3})+(?!\d))/g, ',');
			}
		});

		function count(options) {
			var $this = $S(this);
			options = $S.extend({}, options || {}, $this.data('countToOptions') || {});
			$this.countTo(options);
		}

	}
};

