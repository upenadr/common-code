"use strict"
var $S = jQuery.noConflict();

var server = {
	getData: function (callback, url, args) {
		var request = $S.ajax({
			url: url,
			cache: false,
			type: "POST",
			data: args,
			dataType: "text",
			timeout: 0
		});
		request.done(function (msg) {
			msg = msg.trim();

			if (msg == "User logged out.") {
				window.location="/Platform/CVEM/control.jsp?command=logout";
			} else if (msg.indexOf("Login to Viser") >= 0 && msg.indexOf(">This is Login Page<") >= 0) {
			   window.location="/Platform/CVEM/control.jsp?command=logout";
			} else {
			callback(msg);
		   	}

		});

		request.fail(function () {
			callback("fail");
		});
	}
};
