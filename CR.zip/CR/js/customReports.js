"use strict"
var $S = jQuery.noConflict();
var _spin = '<div class="overlay vertical-center spin" style="left: 0;min-height: 50%;__custom-margin-top__"><i class="fa fa-refresh fa-spin" style="font-size: xx-large;"></i></div>';

var supported_charts = ['PieChart', '3D Pie Chart', 'Donut Chart', 'Bar Chart', 'Column Chart', 'Area Chart', 'Line Chart', 'Stacked Chart'];
var supported_chartsVal = ['pie', 'pie3d', 'donut', 'bar', 'column', 'area', 'line', 'stack'];

// var canned_reports = ['Executive Report', 'Vulnerability Report', 'Asset Report', 'Patch Report', 'Compliance Report', 'Endpoint Management Report'];

var canned_reports = [];
var selectedTargetAccountsForTheReport = [];
var selectedTargetAccountNamesForTheReport = [];
var accountNameToIdMapping = {};

var assetlistforselection = "";
var createdbylistforselection = "";
var patcheslistforselection = "";
var pmVendorlistforselection = "";
var cmVendorlistforselection = "";
var selectedDeviceForAction = "";
var selectedAccountForAction = "";
var selectedAssetForAction = "";
var selectedGroups = [];
var selectedPublisher = [];
var selectedDevices = [];
var grpDevArray = [];
var waitTimeout = 10;
var callNumberOfAPIsCount = 10;
var timeOutMethod;
var reportType = getUrlParameter("command");
var organizationName = getUrlParameter("organization");

// Track when a report has been updated after applying filters
var isReportRecentlyUpdated = false;

$S(document).ready(function() {
    //search for table
    $S(document).on( 'keyup','.reportMenuItemsSearch input', function () {
        
        var tableId = $S(this).parents(".reportMenuItemsSearch").data("parent");

        var table = $S('#'+tableId+'Table').DataTable();
        table.search( this.value ).draw();
    } );
    
    $S(".reportMenuDiv-search-input").val("");
    $S(".savedReport-search-input").val("");
    $S('.prompt').val("");

    // Setting height
    $S('.reportMenuListItems').css('height', ($S(window).height() - 180) + 'px');

    if($S('.OrgReportList').length <= 0) {
        $S('.OrgReportListHeader').hide();
    } else {
        $S('.OrgReportListHeader').show();
    }

    hidingTheEmptyDataToolHeaderInSearchMenuAPIs();
    
    $S(document).on('change', '.limitSelect', function() {
        applyRowLimit($S(this));
    });

    $S(document).on('click', '.reportAPIMenu', function() {

        if ($S(this).hasClass('apiMenuDisplay')) {

            $S(this).find('i').css('color', '#c6c6c6');
            $S(this).removeClass('apiMenuDisplay');

            $S('.reportMenuDiv').hide();

        } else {

            $S(this).find('i').css('color', 'rgb(48, 135, 185)');
            $S(this).addClass('apiMenuDisplay');

            $S('.reportMenuDiv').show();

        }

    });

    $S(document).on('mouseenter', '.reportMenuItemsSearch', function() {
        $S(this).find('.tableSearchDiv').css('width', '180px');
        $S(this).find('input').focus();
    });

    $S(document).on('mouseleave', '.reportMenuItemsSearch', function() {

        if ($S(this).find('.tableSearchDiv').find('input').val() == "") {
            $S(this).find('.tableSearchDiv').css('width', '0');
        }

    });

    // Loading default report
    {
        let defaultReportname = $S('.fa-solid').closest('.reportNameWrapper').data('name');
        if (defaultReportname != undefined && defaultReportname != "") {
            loadSavedCustomReport(defaultReportname);
        } else {
            $S('#grid').html(newLayoutHelpText());
        }

    }


    $S(document).click(function(e) {
        e.stopPropagation();
        var container = $S(".dropdown-menu");

        if ($S(event.target).hasClass('dropdown') || $S(event.target).hasClass('dropdown-toggle') || $S(event.target).hasClass('caret')) {
            return;
        }

        //check if the clicked area is dropDown or not
        if (container.has(e.target).length === 0 && !container.parent().hasClass("tokenize-dropdown")) {
            container.slideUp("400");
            container.closest('li').removeClass('open');
        }

        // API Menu
        var container2 = $S(".reportMenuDiv");

        if ($S(event.target).hasClass('reportAPIMenu') || $S(event.target).parent('span').hasClass('reportAPIMenu')) {
            return;
        }

        //check if the clicked area is dropDown or not
        if (container2.has(e.target).length === 0) {
            if ($S('.reportAPIMenu').hasClass('apiMenuDisplay')) {

                $S('.reportAPIMenu').find('i').css('color', '#c6c6c6');
                $S('.reportAPIMenu').removeClass('apiMenuDisplay');

                $S('.reportMenuDiv').hide();

            }
        }

    });

    $S(document).on('click', '#suggetionBtn', function() {
        $S('.sugestion-box').toggle();
        $S(this).toggleClass("yellow");
    });

    $S(document).on('change', '#other-org-for-move', function() {
        var id = this.value;

        loadOrgAccounts(id);

    });

    $S(document).on('click', '.defaultReportCtrl', function() {
        var reportName = $S(this).data("name");
        if ($S(this).find('i').hasClass('fa-solid')) {
            removedefaultReportCtrl(reportName, this);
        } else {
            defaultReportCtrl(reportName, this);
        }
    });

    $S(document).on('click', '.deleteSavedCustomReport', function() {
        var reportName = $S(this).data("name");
        deleteSavedCustomReport(reportName, this);
    });

    $S(document).on('click', '.revertChangesToDefault', function() {
        var reportName = $S('#reportDisplayName').html();
        revertChangesToDefault(reportName, this);
    });

    $S(document).on('click', '.clearReportLists', function() {
        $S(".reportOverallActions.overallFilterModal.nav-item a").removeAttr('style');
        clearReportLists(this);
    });

    $S(document).on('click', '.reloadReportSections', function() {
        reloadReportSections(this);
    });

    $S(document).on('click', '.newLayout', function() {
        // Reset the flag when creating a new layout
        isReportRecentlyUpdated = false;
        
        $S('#grid').html(newLayoutHelpText());
        jsData = "";
        gridOptions.containerHeight = 0;
        gridOptions.location = {};

        // Hiding action btn's
        $S('.updateCustomReportModal').hide();
        $S('.saveCustomReportModal').hide();
        $S('.currentReportsEmail').hide();
        $S('.currentReportsPDFDownload').removeAttr('data-reportName');
        $S('.currentReportsPDFDownload').removeAttr('data-reportType');
        $S('.currentReportsPDFDownload').hide();
        $S('.clearReportLists').hide();
        $S('.overallFilterModal').hide();
        $S('.reloadReportSections').hide();

        // Default report name
        $S('#reportDisplayName').html('Custom Report');
        $S('.revertChangesToDefault').hide();

        // clearing oveall filter
        $S('.overallFilterModal').attr('data-devicefilter', '');
        $S('.overallFilterModal').attr('data-tagfilter', '');
        $S('.overallFilterModal').attr('data-accountsfilter', '');
        $S('.overallFilterModal').attr('data-startdatefilter', '');
        $S('.overallFilterModal').attr('data-enddatefilter', '');
        $S('.overallFilterModal').attr('data-assetfilter', '');
        $S('.overallFilterModal').attr('data-patchfilter', '');
        $S('.overallFilterModal').attr('data-assetexcludefilter', '');
        $S(".overallFilterModal").attr('data-assetfilterflag', '');
        $S('.overallFilterModal').attr('data-createdbyfilter', '');
        $S('.overallFilterModal').attr('data-createdbyfilterflag', '');
        $S('.overallFilterModal').attr('data-createdbyexcludefilter', '');
        $S('.overallFilterModal').attr('data-familyfilter', '');
        $S('.overallFilterModal').attr('data-installedstartdatefilter', '');
        $S('.overallFilterModal').attr('data-installedenddatefilter', '');
        $S('.overallFilterModal').attr('data-releasedstartdatefilter', '');
        $S('.overallFilterModal').attr('data-releasedenddatefilter', '');


        editableReport();
        stopTimeOutMethod();

    });

    $S(document).on('click', '.saveCustomReportModal', function() {
        saveCustomReportModal();
    });

    $S(document).on('click', '.exportCurrentReportModal', function() {
        exportCurrentReportModal();
    });

    $S(document).on('click', '.updateCustomReportModal', function() {
        var reportName = $S(this).attr('data-name');
        updateCustomReportModal(reportName);
    });
    
    $S(document).on("click", ".error-title", function() {
    	$S(".collapse-error").toggle();
    	$S(this).find(".fa").toggleClass("rotate-180");
    });
    
    $S(document).on("click", ".success-title", function() {
    	$S(".collapse-success").toggle();
    	$S(this).find(".fa").toggleClass("rotate-180");
    });

    $S(document).on('click', '#report-backup-control', function() {
        if ($S(this).hasClass('active')) {
            $S('.backup-report').removeClass('backup-report-disabled');
        } else {
            $S('.backup-report').addClass('backup-report-disabled');
        }

    });

    $S(document).on('click', '.btn-toggle-backup .btn', function() {
        // Remove 'active' and 'btn-primary' classes from all buttons
        $S('.btn-toggle-backup .btn').removeClass('active btn-primary');
    
        // Add 'active' and 'btn-primary' classes to the clicked button
        $S(this).addClass('active btn-primary');
    
        // Show or hide the '.dayOfWeek-div' based on the clicked button's text
        if($S(this).text() === "Monthly") {
            $S('.dayOfWeek-div').show();
            $S('.monthOfYear-div').show();
            $S('.weekOfMonth-div').show();
        }
        else if ($S(this).data('val') === "weekly") {
            $S('.dayOfWeek-div').show();
            $S('.monthOfYear-div').hide();
            $S('.weekOfMonth-div').hide();
        } else {
            $S('.dayOfWeek-div').hide();
            $S('.monthOfYear-div').hide();
            $S('.weekOfMonth-div').hide();
        }
    });

    $S(document).on('click', '.dropdown-menu', function(e) {
        e.stopPropagation();
    });

    $S(document).on('click', '.cr-event-report-menu', function() {

        if ($S('.cr-event-saved-report').hasClass('open')) {
            $S('.cr-event-saved-report').find('.cr-item').slideUp("400");
            $S('.cr-event-saved-report').removeClass('open');
        }

        if ($S(this).hasClass('open')) {
            $S(this).find('.cr-item').slideUp("400");
            $S(this).removeClass('open');

            // Clearing by selection
            $S(this).find('.cr-item').find('.reportMenuItemsSelected').removeClass('reportMenuItemsSelected');

        } else {
            $S(this).find('.cr-item').slideDown("400");
            $S(this).addClass('open');
        }
    });

    $S(document).on('click', '.cr-event-saved-report', function() {

        if ($S('.cr-event-report-menu').hasClass('open')) {
            $S('.cr-event-report-menu').find('.cr-item').slideUp("400");
            $S('.cr-event-report-menu').removeClass('open');
        }

        if ($S(this).hasClass('open')) {
            $S(this).find('.cr-item').slideUp("400");
            $S(this).removeClass('open');
        } else {
            $S(this).find('.cr-item').slideDown("400");
            $S(this).addClass('open');
        }
    });

    $S(document).on('click', '.reportMenuItemsNameEditModal', function() {
        var parent = $S(this).data("parent");
        reportMenuItemsNameEditModal(parent);
    });

    $S(document).on('click', '.reportMenuItemsResize', function() {

        var id = $S(this).closest('li').attr('id');

        if ($S(this).closest('li').attr('data-w') == '12') {
            $S(this).closest('li').attr('data-w', '6');
        } else {
            $S(this).closest('li').attr('data-w', '12');
        }

        gridOptions.location = {};

        var idList = getListIdsInOrder();
        idList.forEach(eachId => {

            var location = gridListElements.getLocation($S('#' + eachId).attr('data-w'));
            var x = location[0];
            var y = location[1];

            $S('#' + eachId).attr('data-x', y);
            $S('#' + eachId).attr('data-y', x);

        });

        gridListElements.refreshGridList();

        var reloadData = (id) => {
            var fname = $S('#' + id).attr('data-fname');
            var type = $S('#' + id).attr('data-type');

            var args = {};
            var url = "CRcontrol.jsp?command=getApiDataInJson&fname=" + fname;
            if (fname === 'getQueryTable') {
                args['queryName'] = $S('#' + id).attr('data-ogtitle');
            }

            var deviceFilter = $S("#" + id).attr('data-devicefilter');
            if (deviceFilter != "") {
                args['deviceList'] = deviceFilter;
            }

            var tagFilter = $S("#" + id).attr('data-tagfilter');
            if (tagFilter != "") {
                args['tagList'] = tagFilter;
            }


            var accountFilter = $S("#" + id).attr('data-accountsfilter');
            if (accountFilter != undefined && accountFilter != "undefined") {
                args['accountNamesList'] = accountFilter;
            }

            
            var installedstartdatefilter = $S("#" + id).attr('data-installedstartdatefilter');
            if (installedstartdatefilter != "") {
                args['installedstartdatefilter'] = installedstartdatefilter;
            }

            var installedenddatefilter = $S("#" + id).attr('data-installedenddatefilter');
            if (installedenddatefilter != "") {
                args['installedenddatefilter'] = installedenddatefilter;
            }

            var releasedstartdatefilter = $S("#" + id).attr('data-releasedstartdatefilter');
            if (releasedstartdatefilter != "") {
                args['releasedstartdatefilter'] = releasedstartdatefilter;
            }

            var releasedenddatefilter = $S("#" + id).attr('data-releasedenddatefilter');
            if (releasedenddatefilter != "") {
                args['releasedenddatefilter'] = releasedenddatefilter;
            }


            var startdatefilter = $S("#" + id).attr('data-startdatefilter');
            if (startdatefilter != "" && startdatefilter != undefined) {
                args['startdatefilter'] = startdatefilter;
            }

            var enddatefilter = $S("#" + id).attr('data-enddatefilter');
            if (enddatefilter != "" && enddatefilter != undefined) {
                args['enddatefilter'] = enddatefilter;
            }

            var assetFilterFlag = $S("#" + id).attr('data-assetfilterflag');
            if (assetFilterFlag != "") {
                args['assetFilterFlag'] = assetFilterFlag;
            }

            var assetFilter = $S("#" + id).attr('data-assetfilter');
            if (assetFilter != "") {
                args['assetList'] = assetFilter;
            }

            var createdbyFilterFlag = $S("#" + id).attr('data-createdbyfilterflag');
            if (createdbyFilterFlag != "") {
                args['createdbyFilterFlag'] = createdbyFilterFlag;
            }

            var createdbyFilter = $S("#" + id).attr('data-createdbyfilter');
            if (createdbyFilter != "") {
                args['createdbyList'] = createdbyFilter;
            }

            var patchFilter = $S("#" + id).attr('data-patchfilter');
            if (patchFilter != "") {
                args['patchList'] = patchFilter;
            }

            var familyFilter = $S("#" + id).attr('data-familyfilter');
            if (familyFilter != "") {
                args['familyList'] = familyFilter;
            }

            var columnstodisplay = $S("#" + id).attr('data-columnstodisplay');
            var columntosort = $S("#" + id).attr('data-columntosort');
            var sortorder = $S("#" + id).attr('data-sortorder');
            var rowlimit = $S("#" + id).attr('data-rowlimit');
            var columnnames = $S("#" + id).attr('data-columnnames');
            var columncolors = $S("#" + id).attr('data-columncolors');
            var chartxaxis = $S("#" + id).attr('data-chartxaxis');
            var chartyaxis = $S("#" + id).attr('data-chartyaxis');
            var chartlabel = $S("#" + id).attr('data-chartlabel');
            var data_operations = $S("#" + id).attr('data-operations');

            var datatype = $S("#" + id).attr('data-datatype');
            var mergetype = $S("#" + id).attr('data-mergetype');
            var mergekey = $S("#" + id).attr('data-mergekey');
            var sortkeys = $S("#" + id).attr('data-sortkeys');
            var ascendingorder = $S("#" + id).attr('data-ascendingorder');
            var limit = $S("#" + id).attr('data-limit');
            var moduleType = $S("#" + id).attr('data-module');


            if (datatype != undefined && datatype != null && datatype.length)
                args['datatype'] = datatype;

            if (mergetype != undefined && mergetype != null && mergetype.length)
                args['mergetype'] = mergetype;

            if (mergekey != undefined && mergekey != null && mergekey.length)
                args['mergekey'] = mergekey;
                
            if (sortkeys != undefined && sortkeys != null && sortkeys.length)
                args['sortkeys'] = sortkeys;
            
            if (ascendingorder != undefined && ascendingorder != null && ascendingorder.length)
                args['ascendingorder'] = ascendingorder;
                
            if (limit != undefined && limit != null && limit.length)
                args['limit'] = limit;

            

            if (rowlimit != undefined)
                args['rowLimit'] = rowlimit;

            if (columntosort != undefined)
                args['columnToSort'] = columntosort;

            if (sortorder != undefined)
                args['sortOrder'] = sortorder;

            if (data_operations != undefined)
                args['data_operations'] = data_operations;


            if (moduleType != undefined) {
                if(moduleType == "Device") {
                    moduleType = "DM";
                }
                args['moduleType'] = moduleType;
            }

            var bodyId = $S('#' + id).find('.grid-body').attr('id');
            $S('#' + bodyId).html(_spin);

            // Get data from server
            server.getData(function(data) {
                createItems[type](data, bodyId, columnstodisplay, chartxaxis.split(','), chartyaxis.split(','), columnnames, columncolors, chartlabel, columntosort, sortorder);

                if (type == 'summary') {
                    // start all the timers
                    $S('#' + id).find('.timer').each(count);
                }

            }, url, args);

            // For Counter.js
            $S('.count-number').data('countToOptions', {
                formatter: function(value, options) {
                    return value.toFixed(options.decimals).replace(/\B(?=(?:\d{3})+(?!\d))/g, ',');
                }
            });

            function count(options) {
                var $this = $S(this);
                options = $S.extend({}, options || {}, $this.data('countToOptions') || {});
                $this.countTo(options);
            }

        }

        var body = $S('#' + id).find('.grid-body').attr('id');
        $S('#' + body).html(_spin);

        setTimeout(function() {
            reloadData(id);
        }, 1000);

    });

    $S(document).on('click', '.savedReportsSettingsModal', function() {
        var reportName = $S(this).attr("data-name");
        savedReportsSettingsModal(reportName);
    });

    $S(document).on('click', '.savedReportsEmailModal', function() {
        var reportName = $S(this).data("name");
        savedReportsEmailModal(reportName);
    });

    $S(document).on('click', '.currentReportsEmail', function() {
        var reportName = $S('#reportDisplayName').html().trim();

        savedReportsEmailModal(reportName);

    });

    $S(document).on('click', '.savedReportsPDFDownload', function() {
        var reportName = $S(this).attr("data-name");
        savedReportsPDFDownload(reportName);
    });

    $S(document).on('click', '.currentReportsPDFDownload', function() {
        if($S('.currentReportsPDFDownload').attr('data-reportType') === 'savedCustomReport') {
            var reportName = $S('#reportDisplayName').html().trim();
            var reporttype = $S('.currentReportsPDFDownload').attr('data-reporttype');
            
            // Check if any filters are applied
            var $modal = $S(".overallFilterModal");
            var hasAppliedFilters = 
                $modal.attr('data-devicefilter') || 
                $modal.attr('data-accountsfilter') || 
                $modal.attr('data-tagfilter') ||
                $modal.attr('data-installedstartdatefilter') ||
                $modal.attr('data-installedenddatefilter') ||
                $modal.attr('data-releasedstartdatefilter') ||
                $modal.attr('data-releasedenddatefilter') ||
                $modal.attr('data-startdatefilter') ||
                $modal.attr('data-enddatefilter') ||
                $modal.attr('data-assetfilter') ||
                $modal.attr('data-createdbyfilter') ||
                $modal.attr('data-patchfilter') ||
                $modal.attr('data-familyfilter');

            if (hasAppliedFilters && !isReportRecentlyUpdated) {
                var proceed = confirm("Filters are applied but not saved. Do you want to download the PDF without the filters?");
                if (!proceed) {
                    return;
                }
            }
            
            savedReportsPDFDownload($S('.currentReportsPDFDownload').attr('data-reportName'));
        } else {
            exportCurrentReportInPDF();
        }
    });

    $S(document).on('click', '.reportMenuItemsClose', function() {
        $S(this).closest('li').remove();

        gridOptions.location = {};

        var idList = getListIdsInOrder();
        idList.forEach(eachId => {

            var location = gridListElements.getLocation($S('#' + eachId).attr('data-w'));
            var x = location[0];
            var y = location[1];

            $S('#' + eachId).attr('data-x', y);
            $S('#' + eachId).attr('data-y', x);

        });

        gridListElements.refreshGridList();
    });

    $S(document).on('click', '.loadSavedCustomReport', function() {
        stopTimeOutMethod();

        if ($S('.reportAPIMenu').hasClass('apiMenuDisplay')) {
            $S('.reportAPIMenu').find('i').css('color', '#c6c6c6');
            $S('.reportAPIMenu').removeClass('apiMenuDisplay');

            $S('.reportMenuDiv').hide();
        }

        // Clear filter modal values when loading a saved report
        $S(".reportOverallActions.overallFilterModal.nav-item a").removeAttr('style');
        clearOverallFilterValues();

        var reportName = $S(this).attr('data-name');

        loadSavedCustomReport(reportName);

        // Showing selection
        $S('.card').removeClass("card-selected");
        $S(this).closest('.card').addClass("card-selected");
    });

    $S(document).on('click', '.exportCurrentReportInPDF', function() {
        //var reportName = $S(this).data("name");
        exportCurrentReportInPDF();
    });

    $S(document).on('click', '.reportMenuItemsCSVDownload', function() {
        //var reportName = $S(this).data("name");

        var liElement = $S(this).closest('li');

        if(liElement.find(".pagination") && liElement.find(".pagination").length) {
            liElement.find(".buttons-csv").click();
        } else {
            reportMenuItemsCSVDownload(liElement);
        }

    });

    $S(document).on('click', '.reportMenuItemsColumnsFilter', function() {
        /*
         * For Table Columns Add or Remove
         */

        var modal_body = "";
        var modal_footer = "";

        var data = reportMenuItemsColumnsFilter($S(this).closest('li'));
        modal_body = data[0];
        modal_footer = data[1];

        var reportName = $S(this).closest('li').attr('data-title');

        var modal_template = modal.createNew(
            "columnChangeModal", "modal-md", "Add or Remove Columns (" + reportName + ")", modal_body, modal_footer
        );

        $S('#columnChangeModal').remove();
        $S('body').append(modal_template);
        // $S("#columnChangeModal").modal();
        var myModal = new bootstrap.Modal("#columnChangeModal");
        myModal.show();
    });

    $S(document).on('click', '.reportMenuItemsChart', function() {
        /*
         * For chart creation
         */

        var modal_body = "";
        var modal_footer = "";

        var data = reportMenuItemsChart($S(this).closest('li'));
        modal_body = data[0];
        modal_footer = data[1];

        var reportName = $S(this).closest('li').attr('data-title');

        var modal_template = modal.createNew(
            "pieChartModal", "modal-md", "Chart Configurations (" + reportName + ")", modal_body, modal_footer
        );

        $S('#pieChartModal').remove();
        $S('body').append(modal_template);
        var myModal = new bootstrap.Modal("#pieChartModal");
        myModal.show();
        //$S("#pieChartModal").modal();
    });

    var familySelectObj = {
        'windowsauto':'windows',
        'linuxauto':'unix',
        'macauto':'macos',
        'othersauto':'others'
    }
    
    var listOfFamily = ['windows','unix','macos','others'];
    $S(document).on('click', '[name = "missingpatchfamily"]', function() {
        var id = $S(this).attr("id");
        if ($S('#'+id).is(':checked')) {
            if(!listOfFamily.includes(familySelectObj[id]))
                listOfFamily.push(familySelectObj[id]);
        } else {
            listOfFamily.splice($S.inArray(familySelectObj[id], listOfFamily), 1);
        }
        if(listOfFamily.length > 0) {
            resettingTheTagFilterModal();
            loadGroupDeviceFilterTree($S(".familyFilterDiv").attr("data-content"),$S(this).closest('li').attr('data-devicefilter'),listOfFamily.toString());
            populateAssetsForSelection($S(this).closest('li').attr('data-devicefilter'),listOfFamily.toString());
            populateCreatedByForSelection();   
        } else {
            $S(".noDevicesDiv").show()
            $S('#groupDeviceFilterInside').hide();
        }
    });
    

    $S(document).on('click', '.overallFilterModal', function() {
        /*
         * For Device Filter
         */

        var modal_body = "";
        var modal_footer = "";

        var data = overAllFilterModal($S(this).closest('li'));
        modal_body = data[0];
        modal_footer = data[1];

        var modal_template = modal.createNew(
            "filterModal", "modal-md", "Filter", modal_body, modal_footer
        );

        $S('#filterModal').remove();
        $S('body').append(modal_template);

        var myModal = new bootstrap.Modal("#filterModal");

        if(reportType === "organizationReports") {
            populateOrgLevelAccountFilter($S(this).closest('li').attr('data-accountsfilter'));
            var filters = $S(this).closest('li').attr('data-filters');
            var selectedAsset = $S(this).closest('li').attr('data-assetfilter');
            var selectedPatch = $S(this).closest('li').attr('data-patchfilter');
            var assetfilterflag = $S(this).closest('li').attr('data-assetfilterflag');
            var selectedCreatedBy = $S(this).closest('li').attr('data-createdbyfilter');
            var createdbyfilterflag = $S(this).closest('li').attr('data-createdbyfilterflag');

            //TODO
            if (filters != undefined && filters.indexOf('asset') >= 0) {
                loadPublisherAssetFilterTree(selectedAsset, assetfilterflag);
            } else {
                $S('#assetfilter_div').hide();
            } 

            //patch filter
            if (filters != undefined && filters.indexOf('patch') >= 0) {
                loadPatchFilterTree(selectedPatch);
            } else {
                $S('#patchfilter_div').hide();
            }

            //hiding filters
            if (filters != undefined && filters.indexOf('vendor') >= 0) {
                loadVendorFilterTree($S(this).closest('li').attr('data-module'), $S(this).closest('li').attr('data-vendorfilter'));
            } else {
                $S('#vendorfilter_div').hide();
            }
        } else {

            $S(".orgLevelAccountFilter").hide();
            populatePatchesForSelection($S(this).attr('data-devicefilter'),$S(this).attr('data-familyfilter'),$S(this).attr('data-assetfilter'));

            var selectedAsset = $S(this).attr('data-assetfilter');
            var assetfilterflag = $S(this).attr('data-assetfilterflag');
            var selectedCreatedBy = $S(this).closest('li').attr('data-createdbyfilter');
            var createdbyfilterflag = $S(this).closest('li').attr('data-createdbyfilterflag');
            loadPublisherAssetFilterTree(selectedAsset, assetfilterflag);
            loadPublisherCreatedByFilterTree(selectedCreatedBy, createdbyfilterflag);
            var selectedPatch = $S(this).attr('data-patchfilter');
            loadPatchFilterTree(selectedPatch);

            $S(".othersauto").show();
            var selectedFamily = $S(this).attr('data-familyfilter');
            if (selectedFamily != undefined && selectedFamily !== "") {
                if (selectedFamily.indexOf("windows") >= 0) $S('#windowsauto').prop("checked", true);
                else $S('#windowsauto').prop("checked", false);
                if (selectedFamily.indexOf("unix") >= 0) $S('#linuxauto').prop("checked", true);
                else $S('#linuxauto').prop("checked", false);
                if (selectedFamily.indexOf("macos") >= 0) $S('#macauto').prop("checked", true);
                else $S('#macauto').prop("checked", false);
                if (selectedFamily.indexOf("others") >= 0) $S('#othersauto').prop("checked", true);
                else $S('#othersauto').prop("checked", false);
            }

            myModal.show();
            $S('[name = "missingpatchfamily"]').each(function(){
                var id =  $S(this).attr('id');
                if ($S('#'+id).is(':checked')) {
                    if(!listOfFamily.includes(familySelectObj[id]))
                        listOfFamily.push(familySelectObj[id]);
                } else {
                    listOfFamily.splice($S.inArray(familySelectObj[id], listOfFamily), 1);
                }
            });
        
            var familyFilterlist;
            if (selectedFamily != undefined && selectedFamily !== "") {
                familyFilterlist = selectedFamily;
                listOfFamily = [];
                listOfFamily = familyFilterlist.split(",");
            }
            else {
                familyFilterlist = listOfFamily.toString();
            } 

            loadGroupDeviceFilterTree("", $S(this).closest('li').attr('data-devicefilter'),familyFilterlist.toString());
            populateAssetsForSelection($S(this).closest('li').attr('data-devicefilter'),familyFilterlist.toString());
            populateCreatedByForSelection();
            $S('#vendorfilter_div').hide();

            var reportDisplayName =  $S("#reportDisplayName").text();
            if(!canned_reports.includes(reportDisplayName)) {
                $S(".tagsFilter").show();
                var reportsTagObj = $S(this).closest('li').attr('data-tagfilter');
                if(reportsTagObj && reportsTagObj.length) {
                    reportsTagObj = reportsTagObj.replace(/'/g, "\"");
                }
                resettingTheTagFilterModal(reportsTagObj, "ALL");
            }
        }
        myModal.show();
    });

    $S(document).on('click', '.reportMenuItemsDeviceFilter', function() {
        /*
         * For Device Filter
         */

        var modal_body = "";
        var modal_footer = "";

        var data = reportMenuItemsDeviceFilter($S(this).closest('li'));
        var parent = $S(this).attr("data-parent");
        var parentTableId = parent + "Table";
        modal_body = data[0];
        modal_footer = data[1];

        var reportName = $S(this).closest('li').attr('data-title');

        var modal_template = modal.createNew(
            "filterModal", "modal-md", "Filter (" + reportName + ")", modal_body, modal_footer
        );

        $S('#filterModal').remove();
        $S('body').append(modal_template);

        var myModal = new bootstrap.Modal("#filterModal");
        
        if(reportType === "organizationReports") {
            populateOrgLevelAccountFilter($S(this).closest('li').attr('data-accountsfilter'));
            var filters = $S(this).closest('li').attr('data-filters');
            var selectedAsset = $S(this).closest('li').attr('data-assetfilter');
            var selectedPatch = $S(this).closest('li').attr('data-patchfilter');
            var assetfilterflag = $S(this).closest('li').attr('data-assetfilterflag');
            var selectedCreatedBy = $S(this).closest('li').attr('data-createdbyfilter');
            var createdbyfilterflag = $S(this).closest('li').attr('data-createdbyfilterflag');           
            //TODO
            if (filters != undefined && filters.indexOf('asset') >= 0) {
                loadPublisherAssetFilterTree(selectedAsset, assetfilterflag);
            } else {
                $S('#assetfilter_div').hide();
            }  

            var loginType = $S("#controlPanelBtn").attr("data-login-type");

            if(filters != undefined && filters.indexOf('createdBy') >= 0 && loginType != undefined) {
                $S('#createdbyfilter_div').show();
                loadPublisherCreatedByFilterTree(selectedCreatedBy, createdbyfilterflag);
            } else {
                $S('#createdbyfilter_div').hide();
            }

            //patch filter
            if (filters != undefined && filters.indexOf('patch') >= 0) {
                populatePatchesForSelection($S(this).closest('li').attr('data-devicefilter'),$S(this).closest('li').attr('data-familyfilter'),selectedAsset);
                loadPatchFilterTree(selectedPatch);
            } else {
                $S('#patchfilter_div').hide();
            }

            if (filters != undefined && filters.indexOf('assetFilterCol') >= 0) {
                var colForAssetSelection = filters.substring(filters.indexOf('||') + 2);
                addTableAssetsForSelection(parentTableId, colForAssetSelection);
            }

            //hiding filters
            if (filters != undefined && filters.indexOf('vendor') >= 0) {
                loadVendorFilterTree($S(this).closest('li').attr('data-module'), $S(this).closest('li').attr('data-vendorfilter'));
            } else {
                $S('#vendorfilter_div').hide();
            }
        }else{
            $S(".orgLevelAccountFilter").hide();

            var dataModules = ['PM','EM'];
            let dataModule = $S(this).closest('li').attr('data-module');

            // // Hiding Device filter
            var filters = $S(this).closest('li').attr('data-filters');

            var reportDisplayName =  $S("#reportDisplayName").text();

            var reportsTagObj = $S(this).closest('li').attr('data-tagfilter');
            if(!canned_reports.includes(reportDisplayName) && (filters != undefined && filters.indexOf('device') >= 0 || filters != undefined && filters.indexOf("tag") >= 0)) {
                $S(".tagsFilter").show();
                if(reportsTagObj && reportsTagObj.length) {
                    reportsTagObj = reportsTagObj.replace(/'/g, "\"");
                }
                resettingTheTagFilterModal(reportsTagObj, dataModule);
            } else {
                $S(".tagsFilter").hide();
            }
            
            // Hiding Asset filter
            var selectedAsset = $S(this).closest('li').attr('data-assetfilter');
            var assetfilterflag = $S(this).closest('li').attr('data-assetfilterflag');
            var selectedCreatedBy = $S(this).closest('li').attr('data-createdbyfilter');
            var createdbyfilterflag = $S(this).closest('li').attr('data-createdbyfilterflag');

            //TODO
            if (filters != undefined && filters.indexOf('asset') >= 0) {
                loadPublisherAssetFilterTree(selectedAsset, assetfilterflag);
            } else {
                $S('#assetfilter_div').hide();
            }

            var loginType = $S("#controlPanelBtn").attr("data-login-type");

            if(filters != undefined && filters.indexOf('createdBy') >= 0 && loginType != undefined) {
                $S('#createdbyfilter_div').show();
                loadPublisherCreatedByFilterTree(selectedCreatedBy, createdbyfilterflag);
            } else {
                $S('#createdbyfilter_div').hide();
            }

            //patch filter
            var selectedPatch = $S(this).closest('li').attr('data-patchfilter');
            if (filters != undefined && filters.indexOf('patch') >= 0) {
                populatePatchesForSelection($S(this).closest('li').attr('data-devicefilter'),$S(this).closest('li').attr('data-familyfilter'),selectedAsset);
                loadPatchFilterTree(selectedPatch);
            } else {
                $S('#patchfilter_div').hide();
            }
            
            if (filters != undefined && filters.indexOf('assetFilterCol') >= 0) {
                var colForAssetSelection = filters.substring(filters.indexOf('||') + 2);
                addTableAssetsForSelection(parentTableId, colForAssetSelection);
            }

            // Hiding Vendor filter
            if (filters != undefined && filters.indexOf('vendor') >= 0) {
                loadVendorFilterTree($S(this).closest('li').attr('data-module'), $S(this).closest('li').attr('data-vendorfilter'));
            } else {
                $S('#vendorfilter_div').hide();
            }
    
            // Hiding Family filter
            if (filters != undefined && filters.indexOf('family') == -1) {
                $S('.familyFilterDiv').hide();
            }
  
            if(dataModules.indexOf(dataModule) >= 0) {
                $S(".othersauto").hide();
            }
            
            
            
    
            var selectedFamily = $S(this).closest('li').attr('data-familyfilter');
            if (selectedFamily != undefined && selectedFamily !== "") {
                if (selectedFamily.indexOf("windows") >= 0) $S('#windowsauto').prop("checked", true);
                else $S('#windowsauto').prop("checked", false);
                if (selectedFamily.indexOf("unix") >= 0) $S('#linuxauto').prop("checked", true);
                else $S('#linuxauto').prop("checked", false);
                if (selectedFamily.indexOf("macos") >= 0) $S('#macauto').prop("checked", true);
                else $S('#macauto').prop("checked", false);
                if (selectedFamily.indexOf("others") >= 0) $S('#othersauto').prop("checked", true);
                else $S('#othersauto').prop("checked", false);
            }
    
             // Hiding Device filter
             $S('[name = "missingpatchfamily"]').each(function() {
                var id =  $S(this).attr('id');
                if ($S('#'+id).is(':checked')) {
                    if(!listOfFamily.includes(familySelectObj[id]))
                        listOfFamily.push(familySelectObj[id]);
                }
            });
    
    
            var familyFilterlist;
            if (selectedFamily != undefined && selectedFamily !== "") {
                familyFilterlist = selectedFamily;
                listOfFamily = [];
                listOfFamily = familyFilterlist.split(",");
            }
            else {
                familyFilterlist = listOfFamily.toString();
            }
            var filters = $S(this).closest('li').attr('data-filters');
            if (filters != undefined && filters.indexOf('device') >= 0) {
                if(reportsTagObj && reportsTagObj.length) {
                    setTimeout(() => {
                        getTheDevicesBasedOnTheTags($S(this).closest('li').attr('data-devicefilter'), familyFilterlist.toString());
                    }, 200);
                } else {
                    loadGroupDeviceFilterTree($S(this).closest('li').attr('data-module'), $S(this).closest('li').attr('data-devicefilter'),familyFilterlist.toString());
                }
            }else{
                $S(".groupDeviceFilter").hide();
            }


            if(filters != undefined && filters.indexOf('installedstartdate') >= 0) {
                var installedstartdatefilter = $S(this).closest('li').attr('data-installedstartdatefilter');
                var parentModalId = "#" + $S('#installedStartDateFilter').closest('.modal').attr('id');
                var startdate = new Date();
                var installedstartdatetemp = installedstartdatefilter;
                if(installedstartdatefilter != "" && installedstartdatefilter != "undefined" && installedstartdatefilter != undefined) {
                    startdate = new Date(installedstartdatefilter);
                }
    
                $S(".installedStartDateFilterWrapper").show();
                $S("#installedStartDateFilter").daterangepicker({"singleDatePicker": true, "showDropdowns": true, format: 'YYYY-MM-DD', minDate: 0, startDate: startdate, 'parentEl': parentModalId});
    
                if(installedstartdatetemp == "" || installedstartdatetemp == undefined || installedstartdatetemp == "undefined") {
                    $S("#installedStartDateFilter").val("");
                }
            } else {
                $S(".installedStartDateFilterWrapper").hide();
            }
    
            if(filters != undefined && filters.indexOf('installedenddate') >= 0) {
                var installedenddatefilter = $S(this).closest('li').attr('data-installedenddatefilter');
                var parentModalId = "#" + $S('#installedEndDateFilter').closest('.modal').attr('id');
                var startdate = new Date();
                var installedenddatetemp = installedenddatefilter;
                if(installedenddatefilter != "" && installedenddatefilter != "undefined" && installedenddatefilter != undefined) {
                    startdate = new Date(installedenddatefilter);
                }
    
                $S(".installedEndDateFilterWrapper").show();
                $S("#installedEndDateFilter").daterangepicker({"singleDatePicker": true, "showDropdowns": true, format: 'YYYY-MM-DD', minDate: 0, startDate: startdate, 'parentEl': parentModalId});
    
                if(installedenddatetemp == "" || installedenddatetemp == undefined || installedenddatetemp == "undefined") {
                    $S("#installedEndDateFilter").val("");
                }
            } else {
                $S(".installedEndDateFilterWrapper").hide();
            }
    
    
            if(filters != undefined && filters.indexOf('releasedstartdate') >= 0) {
                var releasedstartdatefilter = $S(this).closest('li').attr('data-releasedstartdatefilter');
                var parentModalId = "#" + $S('#releasedStartDateFilter').closest('.modal').attr('id');
                var startdate = new Date();
                var releasedstartdatetemp = releasedstartdatefilter;
                if(releasedstartdatefilter != "" && releasedstartdatefilter != "undefined" && releasedstartdatefilter != undefined) {
                    startdate = new Date(releasedstartdatefilter);
                }
    
                $S(".releasedStartDateFilterWrapper").show();
                $S("#releasedStartDateFilter").daterangepicker({"singleDatePicker": true, "showDropdowns": true, format: 'YYYY-MM-DD', minDate: 0, startDate: startdate, 'parentEl': parentModalId});
    
                if(releasedstartdatetemp == "" || releasedstartdatetemp == undefined || releasedstartdatetemp == "undefined") {
                    $S("#releasedStartDateFilter").val("");
                }
            } else {
                $S(".releasedStartDateFilterWrapper").hide();
            }
    
            if(filters != undefined && filters.indexOf('releasedenddate') >= 0) {
                var releasedenddatefilter = $S(this).closest('li').attr('data-releasedenddatefilter');
                var parentModalId = "#" + $S('#releasedEndDateFilter').closest('.modal').attr('id');
                var startdate = new Date();
                var releasedenddatetemp = releasedenddatefilter;
                if(releasedenddatefilter != "" && releasedenddatefilter != "undefined" && releasedenddatefilter != undefined) {
                    startdate = new Date(releasedenddatefilter);
                }
    
                $S(".releasedEndDateFilterWrapper").show();
                $S("#releasedEndDateFilter").daterangepicker({"singleDatePicker": true, "showDropdowns": true, format: 'YYYY-MM-DD', minDate: 0, startDate: startdate, 'parentEl': parentModalId});
    
                if(releasedenddatetemp == "" || releasedenddatetemp == undefined || releasedenddatetemp == "undefined") {
                    $S("#releasedEndDateFilter").val("");
                }
            } else {
                $S(".releasedEndDateFilterWrapper").hide();
            }
    
    
            if (filters != undefined) {
                var filterAry = filters.split(",");
                if(filterAry.includes("startdate")) {
                    var startdatefilter = $S(this).closest('li').attr('data-startdatefilter');
                    var parentModalId = "#" + $S('#startDateFilter').closest('.modal').attr('id');
                    var startdatefilterTemp = startdatefilter;
                    var startdate =  new Date();
                    if(startdatefilter != "" && startdatefilter != "undefined") {
                        startdate = new Date(startdatefilter);
                    }
                    $S(".startDateFilterWrapper").show();
                    $S('#startDateFilter').daterangepicker({"singleDatePicker": true, "showDropdowns": true, format: 'YYYY-MM-DD', minDate: 0, startDate: startdate, 'parentEl': parentModalId});
    
                    if(startdatefilterTemp == "" || startdatefilterTemp == undefined || startdatefilterTemp == "undefined") {
                        $S("#startDateFilter").val("");
                    }
                } else {
                    $S(".startDateFilterWrapper").hide();
                }
            }
    
            if (filters != undefined) {
                var filterAry = filters.split(",");
                if(filterAry.includes("enddate")) {
                    var enddatefilter = $S(this).closest('li').attr('data-enddatefilter');
                    var parentModalId = "#" + $S('#endDateFilter').closest('.modal').attr('id');
                    var enddatefilterTemp = enddatefilter;
                    var enddate =  new Date();
                    if(enddatefilter != "" && enddatefilter != "undefined") {
                        enddate = new Date(enddatefilter);
                    }
                    $S(".endDateFilterWrapper").show();
                    $S('#endDateFilter').daterangepicker({"singleDatePicker": true, "showDropdowns": true, format: 'YYYY-MM-DD', minDate: 0, startDate: enddate, 'parentEl': parentModalId});
                    if(enddatefilterTemp == "" || enddatefilterTemp == undefined || enddatefilterTemp == "undefined") {
                        $S("#endDateFilter").val("");
                    }
                } else {
                    $S(".endDateFilterWrapper").hide();
                }
            }

            $S(".familyFilterDiv").attr("data-content",$S(this).closest('li').attr('data-module'));
        }

        var filters = $S(this).closest('li').attr('data-filters');

        if(filters != undefined && filters.indexOf('installedstartdate') >= 0) {
            var installedstartdatefilter = $S(this).closest('li').attr('data-installedstartdatefilter');
            var parentModalId = "#" + $S('#installedStartDateFilter').closest('.modal').attr('id');
            var startdate = new Date();
            var installedstartdatetemp = installedstartdatefilter;
            if(installedstartdatefilter != "" && installedstartdatefilter != "undefined" && installedstartdatefilter != undefined) {
                startdate = new Date(installedstartdatefilter);
            }

            $S(".installedStartDateFilterWrapper").show();
            $S("#installedStartDateFilter").daterangepicker({"singleDatePicker": true, "showDropdowns": true, format: 'YYYY-MM-DD', minDate: 0, startDate: startdate, 'parentEl': parentModalId});

            if(installedstartdatetemp == "" || installedstartdatetemp == undefined || installedstartdatetemp == "undefined") {
                $S("#installedStartDateFilter").val("");
            }
        } else {
            $S(".installedStartDateFilterWrapper").hide();
        }

        if(filters != undefined && filters.indexOf('installedenddate') >= 0) {
            var installedenddatefilter = $S(this).closest('li').attr('data-installedenddatefilter');
            var parentModalId = "#" + $S('#installedEndDateFilter').closest('.modal').attr('id');
            var startdate = new Date();
            var installedenddatetemp = installedenddatefilter;
            if(installedenddatefilter != "" && installedenddatefilter != "undefined" && installedenddatefilter != undefined) {
                startdate = new Date(installedenddatefilter);
            }

            $S(".installedEndDateFilterWrapper").show();
            $S("#installedEndDateFilter").daterangepicker({"singleDatePicker": true, "showDropdowns": true, format: 'YYYY-MM-DD', minDate: 0, startDate: startdate, 'parentEl': parentModalId});

            if(installedenddatetemp == "" || installedenddatetemp == undefined || installedenddatetemp == "undefined") {
                $S("#installedEndDateFilter").val("");
            }
        } else {
            $S(".installedEndDateFilterWrapper").hide();
        }


        if(filters != undefined && filters.indexOf('releasedstartdate') >= 0) {
            var releasedstartdatefilter = $S(this).closest('li').attr('data-releasedstartdatefilter');
            var parentModalId = "#" + $S('#releasedStartDateFilter').closest('.modal').attr('id');
            var startdate = new Date();
            var releasedstartdatetemp = releasedstartdatefilter;
            if(releasedstartdatefilter != "" && releasedstartdatefilter != "undefined" && releasedstartdatefilter != undefined) {
                startdate = new Date(releasedstartdatefilter);
            }

            $S(".releasedStartDateFilterWrapper").show();
            $S("#releasedStartDateFilter").daterangepicker({"singleDatePicker": true, "showDropdowns": true, format: 'YYYY-MM-DD', minDate: 0, startDate: startdate, 'parentEl': parentModalId});

            if(releasedstartdatetemp == "" || releasedstartdatetemp == undefined || releasedstartdatetemp == "undefined") {
                $S("#releasedStartDateFilter").val("");
            }
        } else {
            $S(".releasedStartDateFilterWrapper").hide();
        }

        if(filters != undefined && filters.indexOf('releasedenddate') >= 0) {
            var releasedenddatefilter = $S(this).closest('li').attr('data-releasedenddatefilter');
            var parentModalId = "#" + $S('#releasedEndDateFilter').closest('.modal').attr('id');
            var startdate = new Date();
            var releasedenddatetemp = releasedenddatefilter;
            if(releasedenddatefilter != "" && releasedenddatefilter != "undefined" && releasedenddatefilter != undefined) {
                startdate = new Date(releasedenddatefilter);
            }

            $S(".releasedEndDateFilterWrapper").show();
            $S("#releasedEndDateFilter").daterangepicker({"singleDatePicker": true, "showDropdowns": true, format: 'YYYY-MM-DD', minDate: 0, startDate: startdate, 'parentEl': parentModalId});

            if(releasedenddatetemp == "" || releasedenddatetemp == undefined || releasedenddatetemp == "undefined") {
                $S("#releasedEndDateFilter").val("");
            }
        } else {
            $S(".releasedEndDateFilterWrapper").hide();
        }

        if (filters != undefined) {
            var filterAry = filters.split(",");
            if(filterAry.includes("startdate")) {
                var startdatefilter = $S(this).closest('li').attr('data-startdatefilter');
                var parentModalId = "#" + $S('#startDateFilter').closest('.modal').attr('id');
                var startdate =  new Date();
                var startdatefilterTemp = startdatefilter;
                if(startdatefilter != "" && startdatefilter != "undefined") {
                    startdate = new Date(startdatefilter);
                }
                $S(".startDateFilterWrapper").show();
                $S('#startDateFilter').daterangepicker({"singleDatePicker": true, "showDropdowns": true, format: 'YYYY-MM-DD', minDate: 0, startDate: startdate, 'parentEl': parentModalId});
                
                if(startdatefilterTemp == "" || startdatefilterTemp == undefined || startdatefilterTemp == "undefined") {
                    $S("#startDateFilter").val("");
                }
            } else {
                $S(".startDateFilterWrapper").hide();
            }
        } 

        if (filters != undefined) {
            var filterAry = filters.split(",");
            if(filterAry.includes("enddate")) {
                var enddatefilter = $S(this).closest('li').attr('data-enddatefilter');
                var parentModalId = "#" + $S('#endDateFilter').closest('.modal').attr('id');
                var enddatefilterTemp = enddatefilter;
                var enddate =  new Date();
                if(enddatefilter != "" && enddatefilter != "undefined") {
                    enddate = new Date(enddatefilter);
                }
                $S(".endDateFilterWrapper").show();
                $S('#endDateFilter').daterangepicker({"singleDatePicker": true, "showDropdowns": true, format: 'YYYY-MM-DD', minDate: 0, startDate: enddate, 'parentEl': parentModalId});
                if(enddatefilterTemp == "" || enddatefilterTemp == undefined || enddatefilterTemp == "undefined") {
                    $S("#endDateFilter").val("");
                }
            } else {
                $S(".endDateFilterWrapper").hide();
            }
        }

        // $S("#filterModal").modal();
     myModal.show();
    });

    // Click event for search results
    $S(document).on('click', '.result', function() {
        var title = $S(this).find('.title').html().trim();
        var description = $S(this).find('.description').html().trim();
        var searchId = $S(this).find('.title').attr('data-searchId');

        var selector = $S("a[data-searchid='" + searchId + "']");

        createNewGridItem(selector);
        $S('.prompt').val('');
    });


    $S(document)
        .on('click', '.cr-item', function(e) {
            // $S(this).find('.reportMenuItemsSelected').removeClass('reportMenuItemsSelected');
        })
        .on('click', '.reportMenuItems', function(e) {
            //$S(this).toggleClass('reportMenuItemsSelected');
            e.stopPropagation();
            e.preventDefault();

            var item = $S(this);
            createNewGridItem(item);

            $S('html, body').animate({ scrollTop: $S(document).height() }, 'fast');

        })
        .on('click', '.reportMenuItemsParent', function(e) {
            //$S(this).toggleClass('reportMenuItemsSelected');
            e.stopPropagation();
            e.preventDefault();

            var item = $S(this).find('.reportMenuItems');
            createNewGridItem(item);

            $S('html, body').animate({ scrollTop: $S(document).height() }, 'fast');

        });

    // Draggable Event
    $S(".reportMenuItemsParent").draggable({
        cursor: "move",
        appendTo: 'body',

        helper: function() {
            var selected = $S(this).find('.reportMenuItems');

            var container = $S('<div class="ui-widget-header" style="z-index: 1001;"/>').attr('id', 'draggingContainer');

            //if($S( ".reportMenuItemsSelected" ).length > 0) {
            //	$S( ".reportMenuItemsSelected" ).each(function( index ) {
            //		container.append($S(this).clone());
            //		container.append("<br>");
            //	});
            //} else {
            container.append(selected.clone());
            //}

            container.find('td').wrap('<tr/>');
            return container;
        }
    });

    // Draggable Event
    $S(".reportMenuItems").draggable({
        cursor: "move",
        appendTo: 'body',

        helper: function() {
            var selected = $S(this);

            var container = $S('<div class="ui-widget-header" style="z-index: 1001;"/>').attr('id', 'draggingContainer');

            //if($S( ".reportMenuItemsSelected" ).length > 0) {
            //	$S( ".reportMenuItemsSelected" ).each(function( index ) {
            //		container.append($S(this).clone());
            //		container.append("<br>");
            //	});
            //} else {
            container.append(selected.clone());
            //}

            container.find('td').wrap('<tr/>');
            return container;
        }
    });

    // Droppable Event
    $S(".grid-container").droppable({
        //hoverClass: "ui-state-hover-mine",
        tolerance: 'pointer',
        drop: function(event, ui) {

            var reportMenuItems = false;

            for (var i = 0; i < ui.helper.children().length; i++) {

                var item = $S(ui.helper.children()[i]);

                if (item.hasClass("reportMenuItems")) {
                    reportMenuItems = true;

                    // Multiple drag and drop removed commented
                    createNewGridItem(item);

                }
                // For multiple drag and drop
                else if (item.hasClass("result")) {

                    var title = item.find('.title').html().trim();
                    var functionName = item.find('.description').html().trim();
                    var searchId = item.find('.title').attr('data-searchId');

                    var selector = $S("a[data-searchid='" + searchId + "']");

                    createNewGridItem(selector);

                }

            }

            if (reportMenuItems) {
                $S(ui.helper).remove();
            }

            $S(".reportMenuItemsSelected").each(function(index) {
                $S(this).removeClass('reportMenuItemsSelected');
            });

            $S('html, body').animate({ scrollTop: $S(document).height() }, 'fast');

        }
    });

    $S(document).on('click', '.btn-toggle-log', function() {
        $S(this).find('.btn').toggleClass('active');
        $S(this).find('.btn').toggleClass('btn-primary');
    });

    $S(document).on('click', '.btn-toggle-log-createby', function() {
        $S(this).find('.btn').toggleClass('active');
        $S(this).find('.btn').toggleClass('btn-primary');
    });

    populateAssetsForSelection("","");
    populateCreatedByForSelection();
    populateVendorsForSelection("getAllPMVendorNamesJson");
    populateVendorsForSelection("getAllCMVendorNamesJson");

    $S(document).on('click', '.toolHeaderClickToExpand', function() {
        var module = $S(this).attr('data-module');
        var arrowIcon = $S(this).find('i');
        var searchStr = $S('.reportMenuDiv-search-input').val();
        $S('.reportMenuItemsParent').each(function () {
            var itemModule = $S(this).find('a.reportMenuItems').attr('data-module');
            if (itemModule === module) {
                if ($S(this).text().toLowerCase().search(searchStr.toLowerCase()) > -1) {
                    $S(this).toggle();
                }
            }
        });
        arrowIcon.toggleClass('fa-chevron-down fa-chevron-up');
    });

});

var previousSearchStr = "";
var addSearchStrAsSuggestion = (searchStr, el) => {
    var selectElement = $S(el).parents("#assetfilter_div").length > 0 ? $S('.assetincludefilter') : $S('.patchincludefilter');
    selectElement.find('option[value="' + previousSearchStr + '"]').remove();

    if (searchStr != "" && !selectElement.find('option[value="' + searchStr + '"]').length) {
        selectElement.prepend('<option value="' + searchStr + '">' + searchStr + '</option>');
    }

    previousSearchStr = searchStr;
}

$S(document).on('input', '.tokenize input', function() {
    if(!$S(this).parents("#tagsFilterTemplate").length){
        var searchStr = $S(this).val();
        addSearchStrAsSuggestion(searchStr, $S(this));
    }
    
});

var addTableAssetsForSelection = (tableId, colName) => {

    var columnIndex = -1;
    var assetlistforselection = [];
    $S('#'+tableId+' thead td').each(function(index) {
        if ($S(this).text().trim() === colName) {
          columnIndex = index;
          return false;
        }
    });
      
    if (columnIndex !== -1) {
        $S('#'+tableId+' tbody tr').each(function() {
            var cellHtml = $S(this).find('td:eq(' + columnIndex + ')').html();
            if (!assetlistforselection.includes(cellHtml)) {
                assetlistforselection.push(cellHtml);
            }
        });
    }

    var selectElement = $S('.assetincludefilter');
    for (var i = 0; i < assetlistforselection.length; i++) {
        var eachasset = assetlistforselection[i];
        
        if (eachasset != "" && !selectElement.find('option[value="' + eachasset + '"]').length) {
            selectElement.append('<option value="' + eachasset + '">' + eachasset + '</option>');
        }
    }
}

var populateAssetsForSelection = (selectedDevice, familyType) => {
    var url = "CRcontrol.jsp?command=getApplications";
    var args = {};
    if(selectedDevice == undefined)
        selectedDevice = "";
    if(familyType == undefined)
        familyType = "";
    args['devices'] = selectedDevice;
    args['familyType'] = familyType;


    // Get data from server
    server.getData(function(data) {
        assetlistforselection = data;
        $S('.assetincludefilter').html(assetlistforselection);
    }, url, args);
}

var populateCreatedByForSelection = () => {

    var loginType = $S("#controlPanelBtn").attr("data-login-type");
    if(loginType == undefined) { 
        $S("#createdbyfilter_div").hide();
        return;
    }

    var url = "CRcontrol.jsp?command=getUsers";
    var args = {};
    args.reportType = reportType;
    // Get data from server
    server.getData(function(data) {
        if (data == "") {
            createdbylistforselection = '<option value="">No users found</option>';
        } else {
            createdbylistforselection = data;
        }
    }, url, args);
}

var populatePatchesForSelection = (selectedDevice, familyType, selectedAsset) => {
    var url = "CRcontrol.jsp?command=getPatchesForFilter";
    var args = {};
    if(selectedDevice == undefined)
        selectedDevice = "";
    if(familyType == undefined)
        familyType = "";
    if(selectedAsset == undefined)
        selectedAsset = "";
    args['devices'] = selectedDevice;
    args['familyType'] = familyType;
    args['assets'] = selectedAsset;

    // Get data from server
    server.getData(function(data) {
        patcheslistforselection = data;
        $S('.patchincludefilter').html(patcheslistforselection);
    }, url, args);
}

var populateOrgLevelAccountFilter = (selectedAcc) => {
    $S(".familyFilterDiv").hide();
    $S(".groupDeviceFilter").hide();
    $S(":ui-fancytree").fancytree("destroy");
    $S("#orgLevelAccountFilterTree").fancytree({
        extensions: ["filter"],
        quicksearch: true,
        checkbox: true,
        selectMode: 3,

        select: function(event, data) {
            var node = data.node;

            if (node.isSelected()) {
                if (node.isUndefined()) {
                    // Load and select all child nodes
                    node.load().done(function() {
                        node.visit(function(childNode) {
                            childNode.setSelected(true);
                        });
                    });
                } else {
                    // Select all child nodes
                    node.visit(function(childNode) {
                        childNode.setSelected(true);
                    });
                }
            }
            var selKeys = $S.map(data.tree.getSelectedNodes(), function(node) {
                return node.key;
            });

            grpDevArray = $S.map(selKeys, function(item) {
                var tempnode = data.tree.getNodeByKey(item);
                var tempstructure = [];
                if (tempnode.data.subsid != null)
                    tempstructure.push(tempnode.title + ',' + tempnode.data.subsid);
                else
                    tempstructure.push(tempnode.title);
                while (tempnode.getParent().getParent()) {
                    tempstructure.push(tempnode.getParent().title);
                    tempnode = tempnode.getParent();
                }
                tempstructure.reverse();
                return tempstructure.join('/');
            });

            var selRootNodes = data.tree.getSelectedNodes(true);
            var selRootKeys = $S.map(selRootNodes, function(node) {
                return node.title;
            });
            // test selectedDeviceForAction
            if (node.isSelected()) {
                if (node.isUndefined()) {
                    // Load and select all child nodes
                    node.load().done(function() {
                        node.visit(function(childNode) {
                            childNode.setSelected(true);
                        });
                    });
                } else {
                    // 	Select all child nodes
                    node.visit(function(childNode) {
                        childNode.setSelected(true);
                    });
                }
            }

            // Get a list of all selected nodes, and convert to a key array:
            var selKeysDev = $S.map(data.tree.getSelectedNodes(), function(node) {
                if (node.getParent().title != "root") {
                    if (node.title != "No devices found") {
                        return node.title;
                    }
                }
            });

            //selected AccountNames
            selectedAccountForAction = selRootKeys.join(",");
            
        },
        filter: {
            autoApply: true, // Re-apply last filter if lazy data is loaded
            counter: true, // Show a badge with number of matching child nodes near parent icons
            fuzzy: false, // Match single characters in order, e.g. 'fb' will match 'FooBar'
            hideExpandedCounter: true, // Hide counter badge, when parent is expanded
            highlight: true, // Highlight matches by wrapping inside <mark> tags
            mode: "hide" // Grayout unmatched nodes (pass "hide" to remove unmatched node instead or "dimm" to disable)
        }
    });
    //var selectedDevice = $S(this).closest('li').attr('data-devicefilter');
    if (selectedAcc != undefined && selectedAcc !== "") {
        selectNodes(selectedAcc, "orgLevelAccountFilterTree");
    }

}

var populateVendorsForSelection = (resToolType) => {
    var url = "CRcontrol.jsp?command=getVendors";
    var args = {};
    args['apiName'] = resToolType;

    // Get data from server
    server.getData(function(data) {
        if (data == "") {

        } else {
            if (resToolType == "getAllPMVendorNamesJson") {
                pmVendorlistforselection = data;
            } else {
                cmVendorlistforselection = data;
            }
        }
    }, url, args);
}

var time24To12Convert = (time) => {
    // Check correct time format and split into components
    time = time.toString().match(/^([01]\d|2[0-3])(:)([0-5]\d)(:[0-5]\d)?$/) || [time];

    if (time.length > 1) { // If time format correct
        time = time.slice(1); // Remove full string match value
        time[5] = +time[0] < 12 ? 'AM' : 'PM'; // Set AM/PM
        time[0] = +time[0] % 12 || 12; // Adjust hours
    }
    return time.join(''); // return adjusted time or original string
}

var hidingTheEmptyDataToolHeaderInSearchMenuAPIs = () => {
    if(reportType === "organizationReports") {
        $S(".tool-header-name").each(function(index,element) {
            if(!$S(element).closest('li').next('li').hasClass("reportMenuItemsParent")) {
                $S(element).hide();
            } 
        });

        $S(".sidebar-menu ._manage, ._alerts, ._auditlog").hide();
        $S(".sidebar-menu ._visibility a").attr("href", "/Platform/CVEM/control.jsp?command=endpoint&organization=" + organizationName);
        $S(".sidebar-menu ._reports a").attr("href", "/Platform/CVEM/control.jsp?command=organizationReports&organization="+organizationName);
        $S(".siconDropdown").hide();

    }
}

var checkboxGeneration = (parent, checkbox_name, select_columns, select_charts) => {
    var body = "";

    var columns = parent.attr('data-columns');
    var columnnames = parent.attr('data-columnnames');

    var columnsNmaeMap = {};
    if (columnnames != undefined && columnnames != '') {
        columnnames.split(',').forEach((eachCol) => {
            let keyval = eachCol.split('|');
            columnsNmaeMap[keyval[0]] = keyval[1];
        });
    } else {
        columns.split(',').forEach((eachCol) => {
            columnsNmaeMap[eachCol] = eachCol;
        });
    }

    if (columns != undefined) {
        let columnsArr = columns.split(',');
        columnsArr.forEach(element => {

            // random string
            let rand = [...Array(10)].map(i => (~~(Math.random() * 36)).toString(36)).join('');

            // Generating checkbox
            var checkbox = $S('#checkbox-primary-template').text();
            checkbox = checkbox.replace('%%checkbox-name%%', checkbox_name);
            checkbox = checkbox.replace(/%%checkbox-id%%/g, rand);
            checkbox = checkbox.replace('%%checkbox-label%%', columnsNmaeMap[element]);
            checkbox = checkbox.replace('%%checkbox-value%%', element);

            // Checkbox selecting and de-selecting For Column Filter
            if (select_columns != undefined && select_columns) {

                // Getting columns from the source li
                var selected = parent.attr('data-columnstodisplay').split(',');

                if (selected != undefined && selected.includes(element)) {
                    checkbox = checkbox.replace('%%checkbox-checked%%', 'checked=""');
                } else {
                    checkbox = checkbox.replace('%%checkbox-checked%%', '');
                }

            }

            // Checkbox selecting and de-selecting For Charts
            if (select_charts != undefined && select_charts) {

                // Getting columns from the source li
                var selected = [];
                if (checkbox_name === 'xaxis_column') {

                    if (parent.attr('data-chartxaxis') != undefined) {
                        selected = parent.attr('data-chartxaxis').split(',');
                    }

                } else if (checkbox_name === 'yaxis_column') {

                    if (parent.attr('data-chartyaxis') != undefined) {
                        selected = parent.attr('data-chartyaxis').split(',');
                    }

                }

                if (selected != undefined && selected.includes(element)) {
                    checkbox = checkbox.replace('%%checkbox-checked%%', 'checked=""');
                } else {
                    checkbox = checkbox.replace('%%checkbox-checked%%', '');
                }

            }


            body += $S('#list-group-item-template').text().replace('%%data%%', checkbox);

        });

    }

    return body;
};

var reportMenuItemsColumnsFilter = (parent) => {
    /*
     * Constructing Body and Footer for Table Columns Add or Remove
     */

    var body = "";
    var footer = "";

    body += checkboxGeneration(parent, 'table_columns', true);

    var button = $S('#success-button-template').text();
    button = button.replace('%%onclickSelector%%', 'updateTableColumnsBtn');
    button = button.replace('%%parentId%%', parent.find('.grid-body').attr('id'));
    button = button.replace('%%fName%%', parent.data('fname'));
    button = button.replace('%%innerHTML%%', 'Update');
    footer = button;

    return [body, footer];
};

$S(document).on('click', '.updateTableColumnsBtn', function() {
    var id = $S(this).attr("data-parentid");
    var fname = $S(this).attr("data-fname");
    /*
     * For Column filter
     */
    
    var filtered_columns = [];
    $S('input[name=table_columns]:checked').each(function() {
        filtered_columns.push(this.value);
    });
    
    $S("#" + id).closest('li').attr('data-columnstodisplay', filtered_columns.join(","));
    
    var args = {};
    var url = "CRcontrol.jsp?command=getApiDataInJson&fname=" + fname
    
    if (fname === 'getQueryTable') {
        args['queryName'] = $S("#" + id).closest('li').data('ogtitle');
    }
    
    $S('#' + id + 'Table tbody').empty();
    $S("#" + id).closest('li').attr('data-type', 'table');
    
    var chartxaxis = $S("#" + id).closest('li').data('chartxaxis');
    var chartyaxis = $S("#" + id).closest('li').data('chartyaxis');
    var columnnames = $S("#" + id).closest('li').data('columnnames');
    var columncolors = $S("#" + id).closest('li').data('columncolors');
    var columntosort = $S("#" + id).closest('li').attr('data-columntosort');
    var sortorder = $S("#" + id).closest('li').attr('data-sortorder');
    var rowlimit = $S("#" + id).closest('li').attr('data-rowlimit');
    var devicefilter = $S("#" + id).closest('li').attr('data-devicefilter');
    var tagfilter = $S("#" + id).closest('li').attr('data-tagfilter');

    var accountfilter = $S("#" + id).closest('li').attr('data-accountsfilter');
    var installedstartdatefilter = $S("#" + id).closest('li').attr('data-installedstartdatefilter');
    var installedenddatefilter = $S("#" + id).closest('li').attr('data-installedenddatefilter');
    var releasedstartdatefilter = $S("#" + id).closest('li').attr('data-releasedstartdatefilter');
    var releasedenddatefilter = $S("#" + id).closest('li').attr('data-releasedenddatefilter');
    var startdatefilter = $S("#" + id).closest('li').attr('data-startdatefilter');
    var enddatefilter = $S("#" + id).closest('li').attr('data-enddatefilter');
    var assetfilter = $S("#" + id).closest('li').attr('data-assetfilter');
    var createdbyfilter = $S("#" + id).closest('li').attr('data-createdbyfilter');
    var patchfilter = $S("#" + id).closest('li').attr('data-patchfilter');
    var assetfilterflag = $S("#" + id).closest('li').attr('data-assetfilterflag');
    var createdbyfilterflag = $S("#" + id).closest('li').attr('data-createdbyfilterflag');
    var familyfilter = $S("#" + id).closest('li').attr('data-familyfilter');
    var chartlabel = $S("#" + id).closest('li').attr('data-chartlabel');
    var data_operations = $S("#" + id).closest('li').attr('data-operations');
    
    var datatype = $S("#" + id).closest('li').attr('data-datatype');
    var mergetype = $S("#" + id).closest('li').attr('data-mergetype');
    var mergekey = $S("#" + id).closest('li').attr('data-mergekey');
    var sortkeys = $S("#" + id).closest('li').attr('data-sortkeys');
    var ascendingorder = $S("#" + id).closest('li').attr('data-ascendingorder');
    var limit = $S("#" + id).closest('li').attr('data-limit');
    var moduleType = $S("#" + id).closest('li').attr('data-module');
    
    if (datatype != undefined && datatype != null && datatype.length)
    args['datatype'] = datatype;
    
    if (mergetype != undefined && mergetype != null && mergetype.length)
        args['mergetype'] = mergetype;
    
    if (mergekey != undefined && mergekey != null && mergekey.length)
        args['mergekey'] = mergekey;
        
    if (sortkeys != undefined && sortkeys != null && sortkeys.length)
        args['sortkeys'] = sortkeys;
    
    if (ascendingorder != undefined && ascendingorder != null && ascendingorder.length)
        args['ascendingorder'] = ascendingorder;
        
    if (limit != undefined && limit != null && limit.length)
        args['limit'] = limit;
    
    if (startdatefilter != undefined && startdatefilter != null && startdatefilter.length)
        args['startdatefilter'] = startdatefilter;
    
    if (enddatefilter != undefined && enddatefilter != null && enddatefilter.length)
        args['enddatefilter'] = enddatefilter;

    if (installedstartdatefilter != undefined && installedstartdatefilter != null && installedstartdatefilter.length)
        args['installedstartdatefilter'] = installedstartdatefilter;
    
    if (installedenddatefilter != undefined && installedenddatefilter != null && installedenddatefilter.length)
        args['installedenddatefilter'] = installedenddatefilter;

    if (releasedstartdatefilter != undefined && releasedstartdatefilter != null && releasedstartdatefilter.length)
        args['releasedstartdatefilter'] = releasedstartdatefilter;
    
    if (releasedenddatefilter != undefined && releasedenddatefilter != null && releasedenddatefilter.length)
        args['releasedenddatefilter'] = releasedenddatefilter;
    
    
    if (moduleType != undefined) {
        if(moduleType == "Device") {
            moduleType = "DM";
        }
        args['moduleType'] = moduleType;
    }
    
    if(accountfilter == undefined || accountfilter == "undefined"){
        accountfilter = "";
    }
    args['deviceList'] = devicefilter;
    args['tagList'] = tagfilter;
    args['accountNamesList'] = accountfilter;
    args['createdbyFilterFlag'] = createdbyfilterflag;
    args['createdbyList'] = createdbyfilter;
    args['assetFilterFlag'] = assetfilterflag;
    args['assetList'] = assetfilter;
    args['patchList'] = patchfilter;
    args['familyList'] = familyfilter;
    args['data_operations'] = data_operations;
    
    if (rowlimit != undefined)
        args['rowLimit'] = rowlimit;
    
    if (columntosort != undefined)
        args['columnToSort'] = columntosort;
    
    if (sortorder != undefined)
        args['sortOrder'] = sortorder;
    
    // Get data from server
    server.getData(function(data) {
        createItems['table'](data, id, filtered_columns.join(","), chartxaxis.split(','), chartyaxis.split(','), columnnames, columncolors, chartlabel, columntosort, sortorder);
    }, url, args);
    
    $S('#columnChangeModal').modal('hide');

});

var reportMenuItemsDeviceFilter = (parent) => {
    /*
     * Constructing Body and Footer for Filter
     */

    var body = "";
    var footer = "";

    body = $S('#Filter-template').text();

    var button = $S('#success-button-template').text();
    button = button.replace('%%onclickSelector%%', 'applyFilterBtn');
    button = button.replace('%%parentId%%', parent.find('.grid-body').attr('id'));
    button = button.replace('%%fName%%', parent.data('fname'));
    button = button.replace('%%innerHTML%%', 'Apply');
    footer = button;

    return [body, footer];
};

var overAllFilterModal = (parent) => {
    /*
     * Constructing Body and Footer for Filter
     */

    var body = "";
    var footer = "";

    body = $S('#Filter-template').text();

    var button = $S('#success-button-template').text();
    button = button.replace('%%onclickSelector%%', 'applyOverallFilterBtn');
    button = button.replace('%%innerHTML%%', 'Apply');
    footer = button;

    return [body, footer];
};

var reportMenuItemsChart = (parent) => {
    /*
     * Constructing Body and Footer for Chart
     */

    var body = "";
    var footer = "";
    var xaxis = "";
    var yaxis = "";

    body = $S('#chart-configuration-template').text();

    xaxis += checkboxGeneration(parent, 'xaxis_column', false, true);
    yaxis += checkboxGeneration(parent, 'yaxis_column', false, true);

    body = body.replace('%%x-axis%%', xaxis);
    body = body.replace('%%y-axis%%', yaxis);

    var type = parent.attr('data-type');

    var selectOptions = "";

    for (var i = 0; i < supported_charts.length; i++) {
        let option = document.createElement("option");
        option.value = supported_chartsVal[i];
        option.text = supported_charts[i];

        if (type == supported_chartsVal[i]) {
            option.setAttribute('selected', 'selected');
        }

        selectOptions += option.outerHTML;
    }

    body = body.replace('%%chart-type%%', selectOptions);

    var button = $S('#success-button-template').text();
    button = button.replace('%%onclickSelector%%', 'createChartWithSelectedColumnsBtn');
    button = button.replace('%%parentId%%', parent.find('.grid-body').attr('id'));
    button = button.replace('%%fName%%', parent.data('fname'));
    button = button.replace('%%innerHTML%%', 'Update');
    footer = button;

    return [body, footer];
};

var applyRowLimit = (obj) => {
    var limit = obj.val();
    var tid = obj.parent().attr("data-parent");
    var fname = $S("#" + tid).closest('li').attr('data-fname');
    applyFilter(tid, fname, limit);
}

$S(document).on('click', '.applyFilterBtn', function() {
    var id = $S(this).attr("data-parentid");
    var fname = $S(this).attr("data-fname");
    applyFilter(id, fname);
});

var applyFilter = (id, fname, limit) => {
    // Reset the flag when filters are applied
    isReportRecentlyUpdated = false;
    
    var deviceList = selectedDeviceForAction;
    var accountNamesList = selectedAccountForAction;
    var tagList = prepareAndGetTagsFilterJsonObj();
    if((tagList && tagList.length) && !deviceList.length) {
        deviceList = $S.map($S('#groupDeviceFilterTree').fancytree('getRootNode').getChildren(), function (node) {
            return $S.map(node.children, function(childNode) {
                return childNode.title;
            });
        });
        deviceList = deviceList.toString();
    }


    var familyList = [];
    var assetList = [];
    var createdbyList = [];
    var patchList = [];
    var vendorList = $S(".vendorincludefilter").val();
    var assetfilterflag = $S('#assetfilter_include_exclude_div').find('.active').attr("data-val");
    var createdbyfilterflag = $S('#createdbyfilter_include_exclude_div').find('.active').attr("data-val");
    var windows = $S('#windowsauto').is(":checked");
    var linux = $S('#linuxauto').is(":checked");
    var macos = $S('#macauto').is(":checked");
    var others = $S('#othersauto').is(":checked");
    if (windows) familyList.push("windows");
    if (linux) familyList.push("unix");
    if (macos) familyList.push("macos");
    if (others) familyList.push("others");
    var startdatefilter = $S("#startDateFilter").val();
    var enddatefilter = $S("#endDateFilter").val();
    var installedstartdatefilter = $S("#installedStartDateFilter").val();
    var installedenddatefilter = $S("#installedEndDateFilter").val();
    var releasedstartdatefilter = $S("#releasedStartDateFilter").val();
    var releasedenddatefilter = $S("#releasedEndDateFilter").val();

    $S("#assetfilter_selection_div .tokens-container .token").each(function(index,item){
        assetList.push($S(item).data("value"))
    });

    $S("#createdbyfilter_selection_div .tokens-container .token").each(function(index,item){
        createdbyList.push($S(item).data("value"))
    });

    $S("#patchfilter_selection_div .tokens-container .token").each(function(index,item){
        patchList.push($S(item).data("value"))
    });

    if (familyList.length == 4) familyList = [];

    if (assetList == null || assetList == undefined)
        assetList = [];

    if (createdbyList == null || createdbyList == undefined)
        createdbyList = [];

    if (patchList == null || patchList == undefined)
        patchList = [];

    if (vendorList == null || vendorList == undefined)
        vendorList = [];

    var url = "CRcontrol.jsp?command=getApiDataInJson&fname=" + fname;
    var args = {};
    args['deviceList'] = deviceList;
    args['accountNamesList'] = accountNamesList;
    args['assetList'] = assetList.join(",");
    args['createdbyList'] = createdbyList.join(",");
    args['patchList'] = patchList.join(",");
    args['vendorList'] = vendorList.join(",");
    args['assetFilterFlag'] = assetfilterflag;
    args['createdbyFilterFlag'] = createdbyfilterflag;
    args['tagList'] = tagList;
    if(startdatefilter != undefined) {
        args["startdatefilter"] = startdatefilter
    }

    if(enddatefilter != undefined) {
        args["enddatefilter"] = enddatefilter
    }

    
    if(installedstartdatefilter != undefined) {
        args["installedstartdatefilter"] = installedstartdatefilter
    }

    if(installedenddatefilter != undefined) {
        args["installedenddatefilter"] = installedenddatefilter
    }

    
    if(releasedstartdatefilter != undefined) {
        args["releasedstartdatefilter"] = releasedstartdatefilter
    }

    if(releasedenddatefilter != undefined) {
        args["releasedenddatefilter"] = releasedenddatefilter
    }

    if (limit != undefined) {
        $S("#" + id).closest('li').attr('data-rowlimit', limit);
    } else
        limit = $S("#" + id).closest('li').attr('data-rowlimit');

    if (limit != undefined)
        args['rowLimit'] = limit;

    args['familyList'] = familyList.join(",");

    if (fname === 'getQueryTable') {
        args['queryName'] = $S("#" + id).closest('li').data('ogtitle');
    }

    $S("#" + id).closest('li').attr('data-devicefilter', deviceList);
    $S("#" + id).closest('li').attr('data-accountsfilter', accountNamesList);
    $S("#" + id).closest('li').attr('data-tagfilter', tagList);

    $S("#" + id).closest('li').attr('data-installedstartdatefilter', installedstartdatefilter);
    $S("#" + id).closest('li').attr('data-installedenddatefilter', installedenddatefilter);
    $S("#" + id).closest('li').attr('data-releasedstartdatefilter', releasedstartdatefilter);
    $S("#" + id).closest('li').attr('data-releasedenddatefilter', releasedenddatefilter);

    $S("#" + id).closest('li').attr('data-startdatefilter', startdatefilter);
    $S("#" + id).closest('li').attr('data-enddatefilter', enddatefilter);
    $S("#" + id).closest('li').attr('data-assetfilter', assetList.join(","));
    $S("#" + id).closest('li').attr('data-createdbyfilter', createdbyList.join(","));   
    $S("#" + id).closest('li').attr('data-patchfilter', patchList.join(","));
    $S("#" + id).closest('li').attr('data-assetfilterflag', assetfilterflag);
    $S("#" + id).closest('li').attr('data-createdbyfilterflag', createdbyfilterflag);
    $S("#" + id).closest('li').attr('data-vendorfilter', vendorList.join(","));
    $S("#" + id).closest('li').attr('data-familyfilter', familyList.join(","));
    if ((accountNamesList != "" && accountNamesList != undefined) || (deviceList != "" && deviceList != undefined) || (familyList.join(",") != "" && familyList != undefined) || (assetList.join(",") != "" && assetList != undefined) || (patchList.join(",") != "" && patchList != undefined) || (vendorList.join(",") != "" && vendorList != undefined) || ( startdatefilter !="" && startdatefilter != undefined) || ( enddatefilter !="" && enddatefilter != undefined) || (tagList != "" && tagList != undefined) || (installedstartdatefilter != "" && installedstartdatefilter != undefined) || (installedenddatefilter != "" && installedenddatefilter != undefined) || (releasedstartdatefilter != "" && releasedstartdatefilter != undefined) || (releasedenddatefilter != "" && releasedenddatefilter != undefined) ||  (createdbyList.join(",") != "" && createdbyList != undefined) ) {
        $S("#" + id).closest('li').find('.reportMenuItemsDeviceFilter').css('color', 'rgb(240, 46, 46)');
    } else {
        $S("#" + id).closest('li').find('.reportMenuItemsDeviceFilter').css('color', '#3087B9');
    }

    var type = $S("#" + id).closest('li').attr('data-type');
    var columnstodisplay = $S("#" + id).closest('li').attr('data-columnstodisplay');
    var columntosort = $S("#" + id).closest('li').attr('data-columntosort');
    var sortorder = $S("#" + id).closest('li').attr('data-sortorder');
    var chartxaxis = $S("#" + id).closest('li').attr('data-chartxaxis');
    var chartyaxis = $S("#" + id).closest('li').attr('data-chartyaxis');
    var columnnames = $S("#" + id).closest('li').attr('data-columnnames');
    var columncolors = $S("#" + id).closest('li').attr('data-columncolors');
    var chartlabel = $S("#" + id).closest('li').attr('data-chartlabel');
    var data_operations = $S("#" + id).closest('li').attr('data-operations');

    var datatype = $S("#" + id).closest('li').attr('data-datatype');
    var mergetype = $S("#" + id).closest('li').attr('data-mergetype');
    var mergekey = $S("#" + id).closest('li').attr('data-mergekey');
    var sortkeys = $S("#" + id).closest('li').attr('data-sortkeys');
    var ascendingorder = $S("#" + id).closest('li').attr('data-ascendingorder');
    var limit = $S("#" + id).closest('li').attr('data-limit');

    var moduleType = $S("#" + id).closest('li').attr('data-module');

    if (datatype != undefined && datatype != null && datatype.length)
        args['datatype'] = datatype;

    if (mergetype != undefined && mergetype != null && mergetype.length)
        args['mergetype'] = mergetype;

    if (mergekey != undefined && mergekey != null && mergekey.length)
        args['mergekey'] = mergekey;
        
    if (sortkeys != undefined && sortkeys != null && sortkeys.length)
        args['sortkeys'] = sortkeys;
    
    if (ascendingorder != undefined && ascendingorder != null && ascendingorder.length)
        args['ascendingorder'] = ascendingorder;
        
    if (limit != undefined && limit != null && limit.length)
        args['limit'] = limit;

    if (columntosort != undefined)
        args['columnToSort'] = columntosort;

    if (sortorder != undefined)
        args['sortOrder'] = sortorder;

    if (data_operations != undefined)
        args['data_operations'] = data_operations;

    if (moduleType != undefined) {
        if(moduleType == "Device") {
            moduleType = "DM";
        }
        args['moduleType'] = moduleType;
    }



    $S('#' + id).html(_spin);

    // Get data from server
    server.getData(function(data) {
        createItems[type](data, id, columnstodisplay, chartxaxis.split(','), chartyaxis.split(','), columnnames, columncolors, chartlabel, columntosort, sortorder);

        if (type == 'summary') {
            // start all the timers
            $S('#' + id).find('.timer').each(count);
        }

    }, url, args);

    // For Counter.js
    $S('.count-number').data('countToOptions', {
        formatter: function(value, options) {
            return value.toFixed(options.decimals).replace(/\B(?=(?:\d{3})+(?!\d))/g, ',');
        }
    });

    function count(options) {
        var $this = $S(this);
        options = $S.extend({}, options || {}, $this.data('countToOptions') || {});
        $this.countTo(options);
    }

    $S('#filterModal').modal('hide');

}

$S(document).on('click', '.createChartWithSelectedColumnsBtn', function() {
    var id = $S(this).attr("data-parentid");
    var fname = $S(this).attr("data-fname");
    var chart_type = $S('#chartType').val();
    
    var xaxis_column = [];
    $S('input[name=xaxis_column]:checked').each(function() {
        xaxis_column.push(this.value);
    });
    
    var yaxis_column = [];
    $S('input[name=yaxis_column]:checked').each(function() {
        yaxis_column.push(this.value);
    });
    
    if (xaxis_column.length == 0 && yaxis_column.length == 0) {
        showMsg("", SanerMsg.reports.bothAxesColumnNotSelected, "info");
        return false;
    }
    
    if (((xaxis_column.length == 0 && yaxis_column.length >= 1) || (xaxis_column.length >= 1 && yaxis_column.length == 0)) &&
        (chart_type == 'bar' || chart_type == 'column' || chart_type == 'area' || chart_type == 'line' || chart_type == 'stack')) {
        showMsg("", $S('#chartType option:selected').html() + " - Cannot be created with one axis.", "info");
        return false;
    }
    
    if (((xaxis_column.length > 1 && yaxis_column.length > 1)) &&
        (chart_type == 'bar' || chart_type == 'column' || chart_type == 'area' || chart_type == 'line' || chart_type == 'stack')) {
        showMsg("", $S('#chartType option:selected').html() + " - Atleast one axis should have one column to plot xaxis.", "info");
        return false;
    }
    
    $S("#" + id).closest('li').attr('data-chartxaxis', xaxis_column.join(","));
    $S("#" + id).closest('li').attr('data-chartyaxis', yaxis_column.join(","));
    
    var args = {};
    var url = "CRcontrol.jsp?command=getApiDataInJson&fname=" + fname;
    if (fname === 'getQueryTable') {
        args['queryName'] = $S("#" + id).closest('li').data('ogtitle');
    }
    
    var deviceFilter = $S("#" + id).closest('li').attr('data-devicefilter');
    if (deviceFilter != "") {
        args['deviceList'] = deviceFilter;
    }

    var tagFilter = $S("#" + id).closest('li').attr('data-tagfilter');
    if (tagFilter != "") {
        args['tagList'] = tagFilter;
    }


    var accountfilter = $S("#" + id).closest('li').attr('data-accountsfilter');
    if (accountfilter != undefined && accountfilter != "undefined") {
        args['accountNamesList'] = accountfilter;
    }

    var installedstartdatefilter = $S("#" + id).closest('li').attr('data-installedstartdatefilter');
    if (installedstartdatefilter != "") {
        args['installedstartdatefilter'] = installedstartdatefilter;
    }

    var installedenddatefilter = $S("#" + id).closest('li').attr('data-installedenddatefilter');
    if (installedenddatefilter != "") {
        args['installedenddatefilter'] = installedenddatefilter;
    }

    var releasedstartdatefilter = $S("#" + id).closest('li').attr('data-releasedstartdatefilter');
    if (releasedstartdatefilter != "") {
        args['releasedstartdatefilter'] = releasedstartdatefilter;
    }

    var releasedenddatefilter = $S("#" + id).closest('li').attr('data-releasedenddatefilter');
    if (releasedenddatefilter != "") {
        args['releasedenddatefilter'] = releasedenddatefilter;
    }
    
    var startdatefilter = $S("#" + id).closest('li').attr('data-startdatefilter');
    if (startdatefilter != "") {
        args['startdatefilter'] = startdatefilter;
    }
    
    var enddatefilter = $S("#" + id).closest('li').attr('data-enddatefilter');
    if (enddatefilter != "") {
        args['enddatefilter'] = enddatefilter;
    }
    
    var assetFilterFlag = $S("#" + id).closest('li').attr('data-assetfilterflag');
    if (assetFilterFlag != "") {
        args['assetFilterFlag'] = assetFilterFlag;
    }
    
    var createdbyfilterflag = $S("#" + id).closest('li').attr('data-createdbyfilterflag');
    if (createdbyfilterflag != "") {
        args['createdbyFilterFlag'] = createdbyfilterflag;
    }
    var createdbyfilter = $S("#" + id).closest('li').attr('data-createdbyfilter');
    if (createdbyfilter != "") {
        args['createdbyList'] = createdbyfilter;
    }

    var assetFilter = $S("#" + id).closest('li').attr('data-assetfilter');
    if (assetFilter != "") {
        args['assetList'] = assetFilter;
    }
    var patchFilter = $S("#" + id).closest('li').attr('data-patchfilter');
    if (patchFilter != "") {
        args['patchList'] = patchFilter;
    }
    var familyFilter = $S("#" + id).closest('li').attr('data-familyfilter');
    if (familyFilter != "") {
        args['familyList'] = familyFilter;
    }
    
    var columnnames = $S("#" + id).closest('li').attr('data-columnnames');
    var columncolors = $S("#" + id).closest('li').attr('data-columncolors');
    var chartlabel = $S("#" + id).closest('li').attr('data-chartlabel');
    var columntosort = $S("#" + id).closest('li').attr('data-columntosort');
    var sortorder = $S("#" + id).closest('li').attr('data-sortorder');
    var rowlimit = $S("#" + id).closest('li').attr('data-rowlimit');
    var data_operations = $S("#" + id).closest('li').attr('data-operations');
    
    var datatype = $S("#" + id).closest('li').attr('data-datatype');
    var mergetype = $S("#" + id).closest('li').attr('data-mergetype');
    var mergekey = $S("#" + id).closest('li').attr('data-mergekey');
    var sortkeys = $S("#" + id).closest('li').attr('data-sortkeys');
    var ascendingorder = $S("#" + id).closest('li').attr('data-ascendingorder');
    var limit = $S("#" + id).closest('li').attr('data-limit');
    
    if (datatype != undefined && datatype != null && datatype.length)
        args['datatype'] = datatype;
    
    if (mergetype != undefined && mergetype != null && mergetype.length)
        args['mergetype'] = mergetype;
    
    if (mergekey != undefined && mergekey != null && mergekey.length)
        args['mergekey'] = mergekey;
        
    if (sortkeys != undefined && sortkeys != null && sortkeys.length)
        args['sortkeys'] = sortkeys;
    
    if (ascendingorder != undefined && ascendingorder != null && ascendingorder.length)
        args['ascendingorder'] = ascendingorder;
        
    if (limit != undefined && limit != null && limit.length)
        args['limit'] = limit;
    
    if (rowlimit != undefined)
        args['rowLimit'] = rowlimit;
    
    if (columntosort != undefined)
        args['columnToSort'] = columntosort;
    
    if (sortorder != undefined)
        args['sortOrder'] = sortorder;
    
    if (data_operations != undefined)
        args['data_operations'] = data_operations;
    
    $S('#' + id).html(_spin);
    
    $S("#" + id).closest('li').attr('data-type', chart_type);
    
    // Get data from server
    server.getData(function(data) {
        createItems[chart_type](data, id, "", xaxis_column, yaxis_column, columnnames, columncolors, chartlabel, columntosort, sortorder);
    }, url, args);
    
    $S('#pieChartModal').modal('hide');

});

var getListIdsInOrder = () => {

    var grid = $S("#grid li");
    var gridOrder = [];
    var newDiv = null;
    var top;
    var left;

    for (var i = 0; i < grid.length; i++) {

        var left = grid[i].style.left.replace("px", "")
        var top = grid[i].style.top.replace("px", "")
        if (top == "") {
            newDiv = {
                id: grid[i].getAttribute("id"),
                top: top,
                left: left
            }
            continue;
        }
        if(grid[i].getAttribute("id").indexOf("next")>=0){}
        else if(grid[i].getAttribute("id").indexOf("previous")>=0){}
        else{
            gridOrder.push({ id: grid[i].getAttribute("id"), left: left, top: top })
        }
    }

    //sort the list based on top first
    gridOrder.sort(function(a, b) {
        return a.top - b.top;
    });

    //sort based on left position
    gridOrder.sort(function(a, b) {
        if (a.top == b.top) {
            return a.left - b.left;
        } else {
            return 0;
        }
    });

    if (newDiv) {

        gridOrder.unshift(newDiv);
    }



    var gridIDs = [];
    for (var i = 0; i < gridOrder.length; i++) {
        gridIDs.push(gridOrder[i].id)
    }

    return gridIDs;

}

var convertCustomReportsToJson = (idList) => {

    if (idList.length == 0) {
        return "{}"
    } else {
        var json = "{\"layout\":[";

        for (var i = 0; i < idList.length; i++) {
            //get the attribute values and populate it in a json
            var listitem = document.getElementById(idList[i]).attributes;

            json = json + "{";

            for (var j = 0; j < listitem.length; j++) {

                var attribute = listitem[j].name;
                if (attribute != "id" && attribute != "data-x" && attribute != "class" && attribute != "style" && attribute != "data-y") {

                    var value = listitem[j].value
                    attribute = attribute.replace("data-", "");
                    if(attribute == "tagfilter") {
                        json = json + "\"" + attribute + "\":";
                        json = json + "\"" + value.replace(/"/g, '\'') + "\","
                    } else {
                        json = json + "\"" + attribute + "\":";
                        json = json + "\"" + value + "\","
                    }
                }
            }

            json = json.substr(0, json.length - 1);
            json = json + "},";
        }

        json = json.substr(0, json.length - 1);
        json = json + "]}";

    }

    return json;
}

function saveReportCallback(url, args, actionBtn) {
    // Get data from server
    server.getData(function(data) {
        let fixedMessage = "";
        if ((data.indexOf("Success!") > -1 || data.indexOf("Successfully") > -1)) {
            var isFound = false;
            var successMsgArr = data.substring(4).split("<br>");
            
            if (successMsgArr.length > 3) {
                //display success message along with count and show all items based on click
                fixedMessage = createToggleContainer(successMsgArr, "success");
                showFixedMsgNotification("", fixedMessage, "success", false);
            } else {
                //show only 3 or less items with success messages
                showMsg("", data, "success");
            }
            
            actionBtn.removeAttr("disabled");
            
            $S('.saveCustomReportModal').hide();
            $S('.updateCustomReportModal').show();
            $S('.updateCustomReportModal').attr('data-name', args.reportName);
    
            // After saving actions
            $S('#reportDisplayName').html(htmlEscape(args.reportName));
            var template = $S('#saved-report-card-template').html();
            template = template.replace(/%%reportname%%/g, htmlEscape(args.reportName));
            $S('.cr-event-saved-report').find('.savedReportsCont li.savedReportContList').each(function() {
                var span = $S(this).find('span.reportNameWrapper');
                if (span.length > 0) {
                    var dataName = span.attr('data-name').trim();
                    if (args.reportName === dataName) {
                        isFound = true;
                        return false;
                    }
                }
            });
            if (!isFound) $S('.cr-event-saved-report').find('.savedReportsCont').append(template);
    
            $S('#reportSettingsModal').modal('hide');

        } else {
            var errMsgArr = data.substring(4).split("<br>");
            if (errMsgArr.length > 3) {
                fixedMessage = createToggleContainer(errMsgArr, "error");
                showFixedMsgNotification("", fixedMessage, "error", false);
            } else {
                showMsg("", data, "error");
            }
            actionBtn.removeAttr("disabled");
        }
    }, url, args);
}

function updateReportCallback(url, args, actionBtn) {
    // Get data from server
    server.getData(function(data) {
        let fixedMessage = "";
        if ((data.indexOf("Success!") > -1 || data.indexOf("Successfully") > -1)) {
            var successMsgArr = data.substring(4).split("<br>");
            if (successMsgArr.length > 3) {
                fixedMessage = createToggleContainer(successMsgArr, "success");
                showFixedMsgNotification("", fixedMessage, "success", false);
            } else {
                showMsg("", data, "success");
            }
            actionBtn.removeAttr("disabled");
    
            // Set flag to indicate report was recently updated
            isReportRecentlyUpdated = true;
    
            // After saving actions
            $S('.updateCustomReportModal').attr('data-name', args.reportName);
            $S('#reportSettingsModal').find('.modal-footer').find('.btn-success').addClass('updateCustomReportBtn');
            $S('#reportSettingsModal').find('.modal-footer').find('.btn-success').attr('data-reportname', htmlEscape(args.reportName));
            if(readymade_report_names.indexOf(args.reportName) >= 0) {
                $S('a[data-name="' + args.oldReportName + '"]').attr('data-name', args.reportName);
                $S('span[data-name="' + args.oldReportName + '"]').attr('data-name', args.reportName);
                $S('a[data-name="' + args.reportName + '"]').html(htmlEscape(args.reportName));
            } else {
                $S('a[data-name="' + args.oldReportName + '"]').closest('.savedReportContList').remove();
                if ($S('a[data-name="' + args.reportName + '"]').length > 0) $S('a[data-name="' + args.reportName + '"]').closest('.savedReportContList').remove();
            
                var template = $S('#saved-report-card-template').html();
                template = template.replace(/%%reportname%%/g, htmlEscape(args.reportName));
                $S('.cr-event-saved-report').find('.savedReportsCont').append(template);
            }
            
            $S('#reportSettingsModal').modal('hide');
            if ($S('#reportDisplayName').html() !== "Custom Report") {
                $S('#reportDisplayName').html(htmlEscape(args.reportName));
            }
        }
        else {    		
            var errMsgArr = data.substring(4).split("<br>");
            if (errMsgArr.length > 3) {
                fixedMessage = createToggleContainer(errMsgArr, "error");
                showFixedMsgNotification("", fixedMessage, "error", false);
            } else {
                showMsg("", data, "error");
            }
            actionBtn.removeAttr("disabled");
        }
    }, url, args);
}

function checkIfReportAlreadyExistsForTargets(targets, reportType, reportName, parentUrl, parentArgs, callback, actionBtn) {
    var oldReportName = parentArgs.oldReportName;
    var action = $S(actionBtn).hasClass('updateCustomReportBtn') ? "update" : "create";

    if (readymade_report_names.indexOf(reportName) >= 0 || (action == "update" && targets.length === 0 && oldReportName === reportName)) {
        callback(parentUrl, parentArgs, actionBtn);
        return;
    }

    var url = "CRcontrol.jsp?command=getTargetsWithDuplicateName";
    var bodyTextLabel = "organization(s)";
    var args = {};
    args['reportname'] = reportName;
    args['oldReportName'] = oldReportName;
    args['reporttype'] = reportType;
    args['targets'] = targets.toString();
    args['action'] = action;
    if (reportType == "reports") {
        args['srcAccount'] = $S('.acc-sub-acc-sel-selected > div').html().trim();
        bodyTextLabel = "account(s)";
    } else {
        args['srcOrganization'] = $S('#searchAccInp').attr('data-parentorg').trim();
    }

    // Get data from server
    server.getData(function(data) {
        if (data != null && data != "") {
            var bodyText = 'The Report with the same name already exists for the ' + bodyTextLabel + ' ' + data + '. Do you want to replace it?';
            var confirmaction = confirm(bodyText);
            if (confirmaction) {
                parentArgs['replaceReport'] = true;
                callback(parentUrl, parentArgs, actionBtn);
            } else {
                actionBtn.removeAttr("disabled");
            } 
        } else {
            callback(parentUrl, parentArgs, actionBtn);
        }
    }, url, args);
}

$S(document).on('click', '.updateCustomReportBtn', function() {
    var oldReportName = $S(this).attr("data-reportname");
    var updatebtn = $S('#reportSettingsModal').find('.modal-footer').find('.btn-success');
    updatebtn.attr("disabled", true);
   
    var control = $S('.modal-body');
    
    var reportName = control.find('#reportName').val().trim();
    
    if (reportName.length == 0) {
        showMsg("", SanerMsg.reports.reportNameNotEmpty, "info");
        updatebtn.removeAttr("disabled");
        return false;
    }
    if (reportName.length > 50) {
        showMsg("", SanerMsg.reports.reportNameLessThan50Characters, "info");
        updatebtn.removeAttr("disabled");
        return false;
    }
    if (!validateAlphanumericField(reportName)) {
        showMsg("", SanerMsg.validation.onlyAlphanumericCharacters);
        updatebtn.removeAttr("disabled");
        return false;
    }
    
    var filter = "";
    if (control.find('#considerFilter').is(':checked')) {
        filter = "true";
    } else {
        filter = "false";
    }
    
    var backupEnabled = control.find('#report-backup-control').hasClass('active');
    var backupCtrl = '';
    var noOfRecordsToSave = '';
    var backupMail = '';
    var timeToSave = '';
    var dayOfWeek = '';
    var monthOfYear = '';
    var weekOfMonth = '';
    // Backup Settings
    if (backupEnabled) {
    
        backupCtrl = control.find('.btn-toggle-backup').find('.active').data('val');
        noOfRecordsToSave = control.find('#noOfRecordsToSave').val();
        backupMail = control.find('#backupMail').val();
    
        if(control.find('#timehours').val() === "HH" || control.find('#timeminutes').val() === "MM"){
            showMsg("", SanerMsg.schedule.selectBackupTime, "info");
            updatebtn.removeAttr("disabled");
            return false;
        }else{
            timeToSave = control.find('#timehours').val() + ":" + control.find('#timeminutes').val() + " " + control.find('#timeampm').val();
        }
    
        if (backupCtrl === "monthly") {
            var monthsOfYearObj = control.find("#monthOfYear").val();
            var weekOfMonth = control.find("#weekOfMonth").val();
            
            if (
              monthsOfYearObj == undefined ||
              monthsOfYearObj == null ||
              monthsOfYearObj.length == 0
            ) {
              showMsg("", SanerMsg.reports.monthsOfYearSelected, "info");
              updatebtn.removeAttr("disabled");
              return false;
            }

            if(
                weekOfMonth == undefined || weekOfMonth == null || weekOfMonth.length == 0
            )
            {
                showMsg("", SanerMsg.reports.weeksOfMonthSelected, "info");
                updatebtn.removeAttr("disabled");
              return false;
            }

            monthOfYear = $S("#monthOfYear").val().toString();
            weekOfMonth = $S("#weekOfMonth").val().toString();

            if (monthOfYear == undefined || monthOfYear.length == 0) {
              showMsg("", SanerMsg.reports.monthsOfYearSelected, "info");
              updatebtn.removeAttr("disabled");
              return false;
            }

            if(weekOfMonth == undefined || weekOfMonth.length == 0){
                showMsg("", SanerMsg.reports.weeksOfMonthSelected, "info");
                updatebtn.removeAttr("disabled");
                return false;
              }
            
              var dayOfWeekObj = control.find("#dayOfWeek").val();
            if (
              dayOfWeekObj == undefined ||
              dayOfWeekObj == null ||
              dayOfWeekObj == "null"
            ) {
              showMsg("", SanerMsg.reports.daysOfTheWeekSelected, "info");
              updatebtn.removeAttr("disabled");
              return false;
            }
              dayOfWeek = dayOfWeekObj.toString();
            
            if (dayOfWeek == undefined || dayOfWeek.length == 0) {
              showMsg("", SanerMsg.reports.daysOfTheWeekSelected, "info");
              updatebtn.removeAttr("disabled");
              return false;
            }
          }
         else if (backupCtrl === 'weekly') {
            var dayOfWeekObj = control.find('#dayOfWeek').val();
            if (dayOfWeekObj == undefined || dayOfWeekObj == null || dayOfWeekObj.length == 0) {
                showMsg("", SanerMsg.reports.daysOfWeekSelectedForWeekly, "info");
                updatebtn.removeAttr("disabled");
                return false;
            }
            dayOfWeek = control.find('#dayOfWeek').val().toString();
            monthOfYear = "1,2,3,4,5,6,7,8,9,10,11,12";
            weekOfMonth = "1,2,3,4,5";
        } else if (backupCtrl === 'daily') {
            dayOfWeek = "1,2,3,4,5,6,7";
            monthOfYear = "1,2,3,4,5,6,7,8,9,10,11,12";
            weekOfMonth = "1,2,3,4,5";
        } else if (backupCtrl === 'never') {
            noOfRecordsToSave = 0;
            dayOfWeek = "0";
            monthOfYear = "0";
            weekOfMonth = "0";
        }
    
        if (backupMail.indexOf(" ,") >= 0 || backupMail.indexOf(", ") >= 0) {
            showMsg("", SanerMsg.reports.emailShouldNotHaveSpace, "info");
            updatebtn.removeAttr("disabled");
            return false;
        }
    
        if (!validateEmailReports(backupMail)) {
            if (backupCtrl === 'weekly' || backupCtrl === 'daily' || backupCtrl === 'monthly') {
                showMsg("", SanerMsg.validation.emailProper, "info");
                updatebtn.removeAttr("disabled");
                return false;
            }
    
            if (backupCtrl === 'never' && backupMail > 0) {
                showMsg("", SanerMsg.validation.emailProper, "info");
                updatebtn.removeAttr("disabled");
                return false;
            }
    
        }
    
    } else {
        backupCtrl = 'never';
        noOfRecordsToSave = '0';
        dayOfWeek = '0';
        monthOfYear = '0';
        weekOfMonth='0';
    }
    
    // Getting report data in json format
    var idList = getListIdsInOrder();
    var json = convertCustomReportsToJson(idList);
    json = json.replace(/\\/g, "\\\\");
    
    var applyToOtherAccounts = false;
    var accountNames = [];
    var targetsToCheck = [];
    
    accountNames = $S('#accountsList').val();
    if (accountNames && accountNames.length > 0) {
        applyToOtherAccounts = true;
        targetsToCheck = accountNames;
    } else {
        applyToOtherAccounts = false;
    }

    // Get current account ID to exclude from deletion
    var currentAccountId = "";
    if(reportType == "organizationReports") {
        currentAccountId = $S('#searchAccInp').attr('data-acc-id');
    } else {
        currentAccountId = $S('.acc-sub-acc-sel-selected').attr('data-acc-id');
    }

    var deleteTargetAccountIds = [];
    
    if(selectedTargetAccountNamesForTheReport && selectedTargetAccountNamesForTheReport.length > 0) {        
        for (var i = 0; i < selectedTargetAccountNamesForTheReport.length; i++) {
            var accountName = selectedTargetAccountNamesForTheReport[i];
            
            // Only delete accounts that are not currently selected
            var isCurrentlySelected = accountNames && accountNames.indexOf(accountName) >= 0;
            if (!isCurrentlySelected) {
                // Convert account name to ID and exclude current account
                var accountId = accountNameToIdMapping[accountName];
                if (accountId && accountId !== currentAccountId) {
                    deleteTargetAccountIds.push(accountId);
                }
            }
        }
    }

    var organizationList = [];
    var isDefaultReport = false;
    var isInputDisabled = $S("#reportName").attr("disabled");
    if(isInputDisabled != undefined) {
        isDefaultReport = true;
    }
    
    var url = "CRcontrol.jsp?command=updateCustomReport";
    if(reportType == "organizationReports") {
        url = "CRcontrol.jsp?command=updateOrgCustomReport";
        organizationList = $S("#organizationList").val();
        targetsToCheck = organizationList;
    }
    
    var args = {};
    args['json'] = json;
    args['reportName'] = reportName;
    args['oldReportName'] = oldReportName;
    args['filter'] = filter;
    // backup settings
    args['backupEnabled'] = backupEnabled;
    args['backupCtrl'] = backupCtrl;
    args['noOfRecordsToSave'] = noOfRecordsToSave;
    args['backupMail'] = backupMail;
    args['timeToSave'] = timeToSave;
    args['dayOfWeek'] = dayOfWeek;
    args['monthOfYear'] = monthOfYear;
    args['weekOfMonth'] = weekOfMonth;
    args['applyToOtherAccounts'] = applyToOtherAccounts;
    args['accountGroupName'] = JSON.stringify(accountNames);
    args['organizationList'] = JSON.stringify(organizationList);
    args['isDefaultReport'] = isDefaultReport;
    args['deleteTargetAccounts'] = deleteTargetAccountIds.toString();
    
    checkIfReportAlreadyExistsForTargets(targetsToCheck, reportType, reportName, url, args, updateReportCallback, updatebtn);

});

$S(document).on('click', '.saveCustomReportBtn', function() {
    var savebtn = $S('#reportSettingsModal').find('.modal-footer').find('.btn-success');
    savebtn.attr("disabled", true);
    
    var control = $S('.modal-body');
    
    var reportName = control.find('#reportName').val().trim();
    
    if (reportName.length == 0) {
        showMsg("", SanerMsg.reports.reportNameNotEmpty, "info");
        savebtn.removeAttr("disabled");
        return false;
    }
    if (reportName.length > 50) {
        showMsg("", SanerMsg.reports.reportNameLessThan50Characters, "info");
        savebtn.removeAttr("disabled");
        return false;
    }
    if (!validateAlphanumericField(reportName)) {
        showMsg("", SanerMsg.validation.onlyAlphanumericCharacters);
        savebtn.removeAttr("disabled");
        return false;
    }
    
    var filter = "";
    if (control.find('#considerFilter').is(':checked')) {
        filter = "true";
    } else {
        filter = "false";
    }
    
    var backupEnabled = control.find('#report-backup-control').hasClass('active');
    var backupCtrl = '';
    var noOfRecordsToSave = '';
    var backupMail = '';
    var timeToSave = '';
    var dayOfWeek = '';
    var monthOfYear = '';
    var weekOfMonth = '';
    
    // Backup Settings
    if (backupEnabled) {
    
        backupCtrl = control.find('.btn-toggle-backup').find('.active').data('val');
        noOfRecordsToSave = control.find('#noOfRecordsToSave').val();
        backupMail = control.find('#backupMail').val();
        
        if (control.find('#timehours').val() === "HH" || control.find('#timeminutes').val() === "MM") {
            showMsg("", SanerMsg.reports.backupTimeSelected, "info");
            savebtn.removeAttr("disabled");
            return false;
        }else{
            timeToSave = control.find('#timehours').val() + ":" + control.find('#timeminutes').val() + " " + control.find('#timeampm').val();
        }
        
        if (backupCtrl === "monthly") {
          var monthsOfYearObj = control.find("#monthOfYear").val();
          var weekofMonthObj = control.find("#weekOfMonth").val();
          if (
            monthsOfYearObj == undefined ||
            monthsOfYearObj == null ||
            monthsOfYearObj.length == 0
          ) {
            showMsg("", SanerMsg.reports.monthsOfYearSelected, "info");
            savebtn.removeAttr("disabled");
            return false;
          }

          if(weekofMonthObj == undefined || weekofMonthObj == null || weekofMonthObj.length == 0){
            showMsg("", SanerMsg.reports.weeksOfMonthSelected, "info");
            savebtn.removeAttr("disabled");
            return false;
            }


          monthOfYear = $S("#monthOfYear").val().toString();
          weekOfMonth = $S("#weekOfMonth").val().toString();
          if (monthOfYear == undefined || monthOfYear.length == 0) {
            showMsg("", SanerMsg.reports.monthsOfYearSelected, "info");
            savebtn.removeAttr("disabled");
            return false;
          }

          if(weekOfMonth == undefined || weekOfMonth.length == 0){
            showMsg("", SanerMsg.reports.weeksOfMonthSelected, "info");
            savebtn.removeAttr("disabled");
            return false;
            }

          var dayOfWeekObj = control.find("#dayOfWeek").val();
          if (
            dayOfWeekObj == undefined ||
            dayOfWeekObj == null ||
            dayOfWeekObj == "null"
          ) {
            showMsg("", SanerMsg.reports.daysOfTheWeekSelected, "info");
            savebtn.removeAttr("disabled");
            return false;
          }
            dayOfWeek = dayOfWeekObj.toString();
          
          if (dayOfWeek == undefined || dayOfWeek.length == 0) {
            showMsg("", SanerMsg.reports.daysOfTheWeekSelected, "info");
            savebtn.removeAttr("disabled");
            return false;
          }
        } else if (backupCtrl === "weekly") {
          var dayOfWeekObj = $S("#dayOfWeek").val();
            
          if (
            dayOfWeekObj == undefined ||
            dayOfWeekObj == null ||
            dayOfWeekObj == "null"
          ) {
            showMsg("", SanerMsg.reports.daysOfTheWeekSelected, "info");
            savebtn.removeAttr("disabled");
            return false;
          } else {
            dayOfWeek = dayOfWeekObj.toString();
          }

          if (dayOfWeek == undefined || dayOfWeek.length == 0) {
            showMsg("", SanerMsg.reports.daysOfTheWeekSelected, "info");
            savebtn.removeAttr("disabled");
            return false;
          }
          monthOfYear = "1,2,3,4,5,6,7,8,9,10,11,12";
          weekOfMonth = "1,2,3,4,5";
        } else if (backupCtrl === "daily") {
          dayOfWeek = "1,2,3,4,5,6,7";
          monthOfYear = "1,2,3,4,5,6,7,8,9,10,11,12";
          weekOfMonth = "1,2,3,4,5";
        } else if (backupCtrl === "never") {
          noOfRecordsToSave = 0;
          dayOfWeek = "0";
          monthOfYear = "0";
          weekOfMonth = "0";
        }
    
        if (backupMail.indexOf(" ,") >= 0 || backupMail.indexOf(", ") >= 0) {
            alert(SanerMsg.reports.emailShouldNotHaveSpace);
            savebtn.removeAttr("disabled");
            return false;
        }
    
        if (!validateEmailReports(backupMail)) {
            if (backupCtrl === 'weekly' || backupCtrl === 'daily' || backupCtrl === 'monthly') {
                alert(SanerMsg.validation.emailProper);
                savebtn.removeAttr("disabled");
                return false;
            }
    
            if (backupCtrl === 'never' && backupMail > 0) {
                alert(SanerMsg.validation.emailProper);
                savebtn.removeAttr("disabled");
                return false;
            }
    
        }
    
    } else {
        backupCtrl = 'never';
        noOfRecordsToSave = '0';
        dayOfWeek = '0';
        monthOfYear = '0';
        weekOfMonth = '0';
    }
    
    // Getting report data in json format
    var idList = getListIdsInOrder();
    var json = convertCustomReportsToJson(idList);
    json = json.replace(/\\/g, "\\\\");
    
    var applyToOtherAccounts = false;
    var accountNames = [];
    var organizationList = [];
    var targetsToCheck = [];
    
    accountNames = $S('#accountsList').val();
    if (accountNames && accountNames.length > 0) {
        applyToOtherAccounts = true;
        targetsToCheck = accountNames;
    } else {
        applyToOtherAccounts = false;
    }
    
    var url = "CRcontrol.jsp?command=saveCustomReport";
    if(reportType == "organizationReports") {
        url = "CRcontrol.jsp?command=saveOrgCustomReport";
        organizationList = $S("#organizationList").val();
        targetsToCheck = organizationList;
    }

    var args = {};
    args['json'] = json; 
    args['reportName'] = reportName;
    args['filter'] = filter;
    
    // backup settings
    args['backupEnabled'] = backupEnabled;
    args['backupCtrl'] = backupCtrl;
    args['noOfRecordsToSave'] = noOfRecordsToSave;
    args['backupMail'] = backupMail;
    args['timeToSave'] = timeToSave;
    args['dayOfWeek'] = dayOfWeek;
    args['monthOfYear'] = monthOfYear;
    args['weekOfMonth'] = weekOfMonth;
    args['applyToOtherAccounts'] = applyToOtherAccounts;
    args['organizationList'] = JSON.stringify(organizationList);
    args['accountGroupName'] = JSON.stringify(accountNames);
    
    checkIfReportAlreadyExistsForTargets(targetsToCheck, reportType, reportName, url, args, saveReportCallback, savebtn);

});

var readyMadeReport = () => {

    // Background color and border
    $S('.reportContentDivWithoutMenu > .bigform-content').css({
        "margin": 0,
        "padding-bottom": "10px",
        "background": "#efeeee",
        "border": "solid 1px #c7c9cc"
    });

    // Background space
    $S('#grid-parent').removeClass('col-md-12');
    $S('#grid-parent').addClass('col-md-8  offset-2');
    $S('#grid-parent').css({
        "padding": 0,
        "margin-top": "25px",
        "background": "white"
    });

    $S('.reportAPIMenu').attr('title', 'Not Allowed').toggleClass('reportAPIMenu reportAPIMenuReadyMade');
    $S('.ui.input > input').attr('title', 'Not Allowed').attr('disabled','disabled');
    $S('.overallFilterModal,.clearReportLists').hide();

    $S('#grid').removeClass('grid');
    $S('#grid').addClass('col-md-12 readyMadeReportGrid');


}

var editableReport = () => {
    $S('.reportContentDivWithoutMenu > .bigform-content').css({
        "margin": "",
        "padding-bottom": "",
        "background": "",
        "border": ""
    });

    $S('#grid-parent').removeClass('col-md-8  offset-2');
    $S('#grid-parent').addClass('col-md-12');
    $S('#grid-parent').css({
        "padding": 0,
        "margin-top": "10px",
        "background": ""
    });

    $S('.reportAPIMenuReadyMade').removeAttr('title', 'Not Allowed').toggleClass('reportAPIMenuReadyMade reportAPIMenu');
    $S('.ui.input > input').removeAttr('title', 'Not Allowed').removeAttr('disabled','disabled');

    $S('#grid').addClass('grid');
    $S('#grid').removeClass('col-md-12 readyMadeReportGrid');
}

var loadSavedCustomReport = (reportName) => {
    // Reset the flag when loading a new report
    isReportRecentlyUpdated = false;
    
    // Showing Report Name
    $S('#reportDisplayName').html(htmlEscape(reportName));

    

    // Display Action Menu's
    $S('.overallFilterModal').show();
    $S('.clearReportLists').show();
    $S('.reloadReportSections').show();
    $S('.currentReportsEmail').show();
    $S('.currentReportsPDFDownload').show();
    $S('.currentReportsPDFDownload').attr('data-reportName', reportName);
    $S('.currentReportsPDFDownload').attr('data-reportType', "savedCustomReport");
    $S('.updateCustomReportModal').show();
    if (canned_reports.includes(reportName)) {
        $S('.revertChangesToDefault').show();
    } else {
        $S('.revertChangesToDefault').hide();
    }

    $S('.saveCustomReportModal').hide();
    $S('.updateCustomReportModal').show();
    $S('.updateCustomReportModal').attr('data-name', reportName);
    // END default actions

    $S('.cr-event-saved-report').click();

    getDataAndLoadReport(reportName);

}

var getDataAndLoadReport = (reportName) => {
    // For readymade report
    if(readymade_report_names.indexOf($S('#reportDisplayName').html().trim()) >= 0) {  
        readyMadeReport();
    } else {
        editableReport();
    }

    

    var url = "CRcontrol.jsp?command=getSavedCustomReport";
    if(reportType == "organizationReports") {
        url = "CRcontrol.jsp?command=getSavedOrgCustomReport";
    }

    var args = {};
    args['reportName'] = reportName;

    gridOptions.location = {};
    $S('#grid').html("");
    $S('#grid').html(_spin.replace("__custom-margin-top__", "margin: 38vh 0"));
   
    // Get data from server
    server.getData(function(data) {
        let json = JSON.parse(data);
        var value = 0;
        $S(".spin").remove();
        renderingSavedCustomReportInUI(json[Object.keys(json)[0]], value);
    }, url, args);
}

var invalue;
var jsData;

var applyStoredFiltersToReportItem = (item, reportType) => {
    if(reportType === "organizationReports") {
        var storedAccountsFilter = $S(".overallFilterModal").attr('data-accountsfilter');
        if(storedAccountsFilter) {
            item['accountsfilter'] = storedAccountsFilter;
        }
    } else {
        var filterStr = item['filters'];
        var storedDeviceFilter = $S(".overallFilterModal").attr('data-devicefilter');
        var storedTagFilter = $S(".overallFilterModal").attr('data-tagfilter');
        var storedAssetFilter = $S(".overallFilterModal").attr('data-assetfilter');
        var storedAssetFilterFlag = $S(".overallFilterModal").attr('data-assetfilterflag');
        var storedPatchFilter = $S(".overallFilterModal").attr('data-patchfilter');
        var storedFamilyFilter = $S(".overallFilterModal").attr('data-familyfilter');
        var storedStartDateFilter = $S(".overallFilterModal").attr('data-startdatefilter');
        var storedEndDateFilter = $S(".overallFilterModal").attr('data-enddatefilter');
        var storedInstalledStartDateFilter = $S(".overallFilterModal").attr('data-installedstartdatefilter');
        var storedInstalledEndDateFilter = $S(".overallFilterModal").attr('data-installedenddatefilter');
        var storedReleasedStartDateFilter = $S(".overallFilterModal").attr('data-releasedstartdatefilter');
        var storedReleasedEndDateFilter = $S(".overallFilterModal").attr('data-releasedenddatefilter');
        var storedCreatedByFilter = $S(".overallFilterModal").attr('data-createdbyfilter');
        var storedCreatedByFilterFlag = $S(".overallFilterModal").attr('data-createdbyfilterflag');
        var storedCreatedByExcludeFilter = $S(".overallFilterModal").attr('data-createdbyexcludefilter');
        var storedAssetExcludeFilter = $S(".overallFilterModal").attr('data-assetexcludefilter');

        if (filterStr != undefined && filterStr.indexOf('asset') >= 0) {
            if(storedAssetFilterFlag) item['assetfilterflag'] = storedAssetFilterFlag;
            if(storedAssetFilter) item['assetfilter'] = storedAssetFilter;
        }
        if (filterStr != undefined && filterStr.indexOf('patch') >= 0) {
            if(storedPatchFilter) item['patchfilter'] = storedPatchFilter;
        }
        if (filterStr != undefined && filterStr.indexOf('device') >= 0) {
            if(storedDeviceFilter) item['devicefilter'] = storedDeviceFilter;
            if(storedTagFilter) item['tagfilter'] = storedTagFilter;
        }
        if (filterStr != undefined && filterStr.indexOf('family') >= 0) {
            if(storedFamilyFilter) item['familyfilter'] = storedFamilyFilter;
        }
        
        if(storedStartDateFilter) item['startdatefilter'] = storedStartDateFilter;
        if(storedEndDateFilter) item['enddatefilter'] = storedEndDateFilter;
        if(storedInstalledStartDateFilter) item['installedstartdatefilter'] = storedInstalledStartDateFilter;
        if(storedInstalledEndDateFilter) item['installedenddatefilter'] = storedInstalledEndDateFilter;
        if(storedReleasedStartDateFilter) item['releasedstartdatefilter'] = storedReleasedStartDateFilter;
        if(storedReleasedEndDateFilter) item['releasedenddatefilter'] = storedReleasedEndDateFilter;
        
        if(storedCreatedByFilter) item['createdbyfilter'] = storedCreatedByFilter;
        if(storedCreatedByFilterFlag) item['createdbyfilterflag'] = storedCreatedByFilterFlag;
        if(storedCreatedByExcludeFilter) item['createdbyexcludefilter'] = storedCreatedByExcludeFilter;
        if(storedAssetExcludeFilter) item['assetExcludefilter'] = storedAssetExcludeFilter;
    }
};

var renderingSavedCustomReportInUI = (jsonData, value) => {
    var max = Math.min(value + callNumberOfAPIsCount, jsonData.length);
    var i;
    for (i = value; i < max; ++i, ++value) {
        var each = jsonData[i];

        var chartxaxis = each['chartxaxis'];
        if (chartxaxis == undefined) {
            chartxaxis = "";
        }

        var chartyaxis = each['chartyaxis'];
        if (chartyaxis == undefined) {
            chartyaxis = "";
        }

        var emqueries = false;
        if (each['fname'] == 'getQueryTable') {
            emqueries = true;
        }
        var accountsfilter = each['accountsfilter'];
        if(accountsfilter == undefined || accountsfilter == "undefined"){
            accountsfilter = "";
        }

        applyStoredFiltersToReportItem(each, reportType);

        let grid = Object.assign({}, gridListElements);
        grid.create(
            each['installedstartdatefilter'],
            each['installedenddatefilter'],
            each['releasedstartdatefilter'],
            each['releasedenddatefilter'],
            each['tagfilter'],
            each['startdatefilter'],
            each['enddatefilter'],
            each['charttooltip'],
            each['title'],
            each['type'],
            each['fname'],
            each['w'],
            each['h'],
            '0',
            '0',
            '',
            '',
            each['columns'],
            each['columnstodisplay'],
            chartxaxis,
            chartyaxis,
            each['description'],
            each['filters'],
            accountsfilter,
            each['devicefilter'],
            each['assetfilterflag'],
            each['createdbyfilterflag'],
            each['assetfilter'],
            each['createdbyfilter'],
            each['patchfilter'],
            each['assetExcludefilter'],
            each['createdbyexcludefilter'],
            each['familyfilter'],
            each['columnnames'],
            each['columncolors'],
            each['chartlabel'],
            each['module'],
            emqueries,
            each['ogtitle'],
            each['columntosort'],
            each['sortorder'],
            each['rowlimit'],
            each['datatype'],
            each['mergetype'],
            each['mergekey'],
            each['sortkeys'],
            each['ascendingorder'],
            each['limit'],
            each['operations'],
            each['sortcolumnformat'],
            each['PA_ID']
        );
    }
    invalue=value;
    jsData = jsonData;
    $S(".loadingReports").remove();
    $S(document).scroll(function() {
        if((document.documentElement.scrollTop+document.documentElement.clientHeight)>= (document.documentElement.scrollHeight - 10 )) {
            $S(".readyMadeReportGrid").after("<div class='loadingReports' style='text-align:center; font-size: 20px; padding-bottom: 20px;'><i style='margin-righ:6px;' class='fa fa-refresh fa-spin'></i> Loading</div>");
            renderingSavedCustomReportInUI(jsData,invalue);       
        }
    });
        
}


var exportCurrentReportInPDF = () => {

    showMsg("", SanerMsg.common.preparingReport, "info");

    var idList = getListIdsInOrder();
    var json = convertCustomReportsToJson(idList);

    
    var url = "CRcontrol.jsp?command=exportCurrentReportInPDF";

    var args = {};
    json = json.replace(/\\/g, "\\\\");

    args['json'] = json;
    if(reportType == "organizationReports") {
        args["reportsType"] = reportType;
    }

    //var filter = "false";

    //if($S('#filterincludeinpdf').is(':checked')) {
    //	filter = "true";
    //	}

    var dateTime = moment().format('YYYY-MM-DD HH:mm:ss');

    var filename = $S('#reportDisplayName').html().trim() + "-" + dateTime + ".pdf";

    var xhr = new XMLHttpRequest();
    xhr.open('POST', url, true);
    xhr.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
    xhr.responseType = 'arraybuffer';
    xhr.onload = function(e) {

        if (this.status == 200) {

            var enc = new TextDecoder("utf-8");
            var arr = new Uint8Array(this.response);
            let msg = enc.decode(arr);

            if (msg == "User logged out.") {
                window.location = "/Platform/CVEM/control.jsp?command=logout";
            } else if (msg.indexOf("Login to Viser") >= 0 && msg.indexOf(">This is Login Page<") >= 0) {
                window.location = "/Platform/CVEM/control.jsp?command=logout";
            } else {

                if (typeof window.chrome !== 'undefined') {
                    // Chrome version
                    var blob = new Blob([this.response], { type: "application/pdf" });
                    var link = document.createElement('a');
                    link.href = window.URL.createObjectURL(blob);
                    link.download = filename;
                    link.click();

                } else if (typeof window.navigator.msSaveBlob !== 'undefined') {
                    // IE version
                    var blob = new Blob([this.response], { type: 'application/pdf' });
                    window.navigator.msSaveBlob(blob, filename);
                } else {
                    // Firefox version
                    var file = new File([this.response], filename, { type: 'application/force-download' });
                    window.open(URL.createObjectURL(file));
                }

            }
            showMsg("", SanerMsg.common.doenloadSucess, "success");

        } else {

            showMsg("", SanerMsg.reports.unableExportPdf, "error");

        }
    };
    xhr.send('json=' + encodeURIComponent(json) + "&reportName=" + $S('#reportDisplayName').html().trim());

}

var savedReportsPDFDownload = (reportName) => {
    showMsg("", SanerMsg.common.preparingReport, "info");

    var url = "CRcontrol.jsp?command=exportCurrentReportInPDF";
    var args = {};
     if(reportType == "organizationReports") {
        args["reportsType"] = reportType;
    }

    var today = new Date();
    var date = today.getFullYear() + '-' + (today.getMonth() + 1) + '-' + today.getDate();
    var time = today.getHours() + ":" + today.getMinutes() + ":" + today.getSeconds();
    var dateTime = date + ' ' + time;

    var filename = reportName + "-" + dateTime + ".pdf";

    var xhr = new XMLHttpRequest();
    xhr.open('POST', url, true);
    xhr.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
    xhr.responseType = 'arraybuffer';
    xhr.onload = function(e) {

        if (this.status == 200) {

            if (typeof window.chrome !== 'undefined') {

                // Chrome version
                var blob = new Blob([this.response], { type: "application/pdf" });
                var link = document.createElement('a');
                link.href = window.URL.createObjectURL(blob);
                link.download = filename;
                link.click();

            } else if (typeof window.navigator.msSaveBlob !== 'undefined') {
                // IE version
                var blob = new Blob([this.response], { type: 'application/pdf' });
                window.navigator.msSaveBlob(blob, filename);
            } else {
                // Firefox version
                var file = new File([this.response], filename, { type: 'application/force-download' });
                window.open(URL.createObjectURL(file));
            }
            showMsg("", SanerMsg.common.doenloadSucess, "success");

        } else {

            showMsg("", SanerMsg.reports.unableExportPdf, "error");

        }
    };
    xhr.send('reportName=' + reportName);



}

var savedReportsEmailModal = (reportName) => {
    /*
     * For Report Email
     */

    var modal_body = "";
    var modal_footer = "";

    modal_body = $S('#email-pdf-template').text();

    var button = $S('#success-button-template').text();
    button = button.replace('%%onclickSelector%%', 'emailPDFReportFromNameBtn');
    button = button.replace('%%ReportName%%', reportName);
    button = button.replace('%%innerHTML%%', 'Send');
    modal_footer = button;

    var modal_template = modal.createNew(
        "emailReportsModal", "modal-md", "Email Report (" + reportName + ")", modal_body, modal_footer
    );

    $S('#emailReportsModal').remove();
    $S('body').append(modal_template);
    // $S("#emailReportsModal").modal();

    var myModal = new bootstrap.Modal("#emailReportsModal");
    myModal.show();

}

var savedReportsSettingsModal = (reportName) => {
    /*
     * For Report Settings
     */

    var modal_body = "";
    var modal_footer = "";

    modal_body = $S('#report-settings-template').text();

    var button = $S('#success-button-template').text();
    button = button.replace('%%onclickSelector%%', 'updateCustomReportBtn');
    button = button.replace('%%ReportName%%', htmlEscape(reportName));
    button = button.replace('%%innerHTML%%', 'Save');
    modal_footer = button;

    var modal_template = modal.createNew(
        "reportSettingsModal", "modal-md", "Report Settings (" + htmlEscape(reportName) + ")", modal_body, modal_footer
    );

    $S('#reportSettingsModal').remove();
    $S('body').append(modal_template);
   // $S("#reportSettingsModal").modal();

    var myModal = new bootstrap.Modal("#reportSettingsModal");
    myModal.show();

    $S('#timepicker').mdtimepicker();

    $S('.DaysOfWeekSelect').multiselect({
        maxHeight: 180,
        enableCaseInsensitiveFiltering: true,
        includeSelectAllOption: true,
        buttonWidth: '100%',
        nonSelectedText: 'Select days',
        templates: {
            button: '<button type="button" class="multiselect dropdown-toggle" data-bs-toggle="dropdown"><span class="multiselect-selected-text"></span></button>',
        },
    });

    $S('.MonthsOfYearSelect').multiselect({
        maxHeight: 180,
        enableCaseInsensitiveFiltering: true,
        includeSelectAllOption: true,
        buttonWidth: '100%',
        nonSelectedText: 'Select months',
        templates: {
            button: '<button type="button" class="multiselect dropdown-toggle" data-bs-toggle="dropdown"><span class="multiselect-selected-text"></span></button>',
        },
    });

    $S('.WeeksOfMonthSelect').multiselect({
        maxHeight: 180,
        enableCaseInsensitiveFiltering: true,
        includeSelectAllOption: true,
        buttonWidth: '100%',
        nonSelectedText: 'Select weeks',
        templates: {
            button: '<button type="button" class="multiselect dropdown-toggle" data-bs-toggle="dropdown"><span class="multiselect-selected-text"></span></button>',
        },
    });

    // Setting values
    settingStoredReportValues(reportName);


}

var updateCustomReportModal = (reportName) => {
    /*
     * For Report Update
     */

    var modal_body = "";
    var modal_footer = "";

    modal_body = $S('#report-settings-template').text();

    var button = $S('#success-button-template').text();
    button = button.replace('%%onclickSelector%%', 'updateCustomReportBtn');
    button = button.replace('%%ReportName%%', htmlEscape(reportName));
    button = button.replace('%%innerHTML%%', 'Update');
    modal_footer = button;

    var modal_template = modal.createNew(
        "reportSettingsModal", "modal-md", "Update Report", modal_body, modal_footer
    );

    $S('#reportSettingsModal').remove();
    $S('body').append(modal_template);
    var myModal = new bootstrap.Modal("#reportSettingsModal");
    // $S("#reportSettingsModal").modal();
    myModal.show();



    $S('#timepicker').mdtimepicker();

    $S('.DaysOfWeekSelect').multiselect({
        maxHeight: 180,
        enableCaseInsensitiveFiltering: true,
        includeSelectAllOption: true,
        buttonWidth: '100%',
        nonSelectedText: 'Select days',
        templates: {
            button: '<button type="button" class="multiselect dropdown-toggle" data-bs-toggle="dropdown"><span class="multiselect-selected-text"></span></button>',
        },
    });

    $S('.MonthsOfYearSelect').multiselect({
        maxHeight: 180,
        enableCaseInsensitiveFiltering: true,
        includeSelectAllOption: true,
        buttonWidth: '100%',
        nonSelectedText: 'Select months',
        templates: {
            button: '<button type="button" class="multiselect dropdown-toggle" data-bs-toggle="dropdown"><span class="multiselect-selected-text"></span></button>',
        },
    });

    $S('.WeeksOfMonthSelect').multiselect({
        maxHeight: 180,
        enableCaseInsensitiveFiltering: true,
        includeSelectAllOption: true,
        buttonWidth: '100%',
        nonSelectedText: 'Select weeks',
        templates: {
            button: '<button type="button" class="multiselect dropdown-toggle" data-bs-toggle="dropdown"><span class="multiselect-selected-text"></span></button>',
        },
    });
    // $S('.backedUpReportsDiv').remove();

    // Setting values
    settingStoredReportValues(reportName);
    //multiselect js 


}

var settingStoredReportValues = (reportName) => {
	
    // Setting values
    var control = $S('.modal-body');
    control.find('#reportName').val(reportName);
    
    // setting EDR report name from the map
    reportName = EDRreportmap(reportName);
    
    if (canned_reports.includes(reportName) || readymade_report_names.includes(reportName)) {
        control.find('#reportName').attr('disabled', true);

        if(readymade_report_names.includes(reportName)) {
            $S('#accountsListDiv').hide();
        }
    } else {
        control.find('#reportName').removeAttr('disabled');
    }

    selecttargetaccounts(reportName);

    var url = "CRcontrol.jsp?command=getBackupDetailsNew&reportName=" + reportName;
    if(reportType == "organizationReports") {
        url = "CRcontrol.jsp?command=getSavedOrgCustomReportDetails&reportName=" + reportName;
    }

    var args = {};

    // Get data from server
    server.getData(function(data) {
        if (data == "") {

            control.find('#report-backup-control').removeClass('active');
            if (!control.find('.backup-report').hasClass('backup-report-disabled')) {
                control.find('.backup-report').addClass('backup-report-disabled');
            }

        } else {

            var backupData = JSON.parse(data);

            var savedNoOdRecords = _.get(backupData, "savedNoOdRecords", -1);

            if (savedNoOdRecords == -1 || savedNoOdRecords == 0) {

                control.find('#report-backup-control').removeClass('active');
                if (!control.find('.backup-report').hasClass('backup-report-disabled')) {
                    control.find('.backup-report').addClass('backup-report-disabled');
                }

                // Setting default values:
                control.find('#noOfRecordsToSave').val('10');

            } else {

                control.find('#report-backup-control').addClass('active');
                control.find('.backup-report').removeClass('backup-report-disabled');

                control.find('#backupMail').val(backupData['savedEmail']);
                control.find('#noOfRecordsToSave').val(backupData['savedNoOdRecords']);

                var time = time24To12Convert(backupData['savedTimeToSave']);
                time = time.replace("AM", " AM");
                time = time.replace("PM", " PM");
                let timearr = time.split(" ");
                let sethourmin = timearr[0].split(":");
                if(parseInt(sethourmin[0]) < 10) sethourmin[0] = "0" + sethourmin[0];
                if(parseInt(sethourmin[1]) != 0 && parseInt(sethourmin[1]) != 30) {
                    var minutesSelectEl = document.getElementById("timeminutes");
                    var option = document.createElement("option");
                    option.text = sethourmin[1];
                    option.value = sethourmin[1];
                    minutesSelectEl.add(option);
                };

                control.find('#timehours').val(sethourmin[0]);
                control.find('#timeminutes').val(sethourmin[1]);
                $S("#timeminutes").click(function() {
                    $S('#timeminutes option').each(function() {
                        if ($S(this).val() != "00" && $S(this).val() != "30" && $S(this).val() != "MM") {
                            $S(this).remove();
                        }
                    });
                });
                control.find('#timeampm').val(timearr[1]);

                var days = backupData['savedDaysOfWeek'];
                var months = backupData['monthOfYear'];
                var weeks = backupData['weekOfMonth'];

                if (months === "1,2,3,4,5,6,7,8,9,10,11,12" && weeks === "1,2,3,4,5" && days === "1,2,3,4,5,6,7") {
                    control.find('.btn-toggle-backup').find('div[data-val="daily"]').addClass('active btn-primary');
                } else if (months === "1,2,3,4,5,6,7,8,9,10,11,12" && weeks === "1,2,3,4,5" && days !== "1,2,3,4,5,6,7") {
                    control.find('.btn-toggle-backup').find('div[data-val="weekly"]').addClass('active btn-primary');
                    control.find('.btn-toggle-backup').find('div[data-val="daily"]').removeClass('active btn-primary');
                    control.find('.btn-toggle-backup').find('div[data-val="monthly"]').removeClass('active btn-primary');
                    control.find('.dayOfWeek-div').show();
                    var valArr = days.split(',');
                    $S('#dayOfWeek').val(valArr);
                    $S("#dayOfWeek").multiselect("refresh");
                } else {
                    control.find('.btn-toggle-backup').find('div[data-val="monthly"]').addClass('active btn-primary');
                    control.find('.btn-toggle-backup').find('div[data-val="daily"]').removeClass('active btn-primary');
                    control.find('.btn-toggle-backup').find('div[data-val="weekly"]').removeClass('active btn-primary');
                    control.find('.dayOfWeek-div').show();
                    control.find('.monthOfYear-div').show();
                    control.find('.weekOfMonth-div').show();
                    var valArr = "";
                    if(months && months !== "") {
                        valArr = months.split(',');
                        $S('#monthOfYear').val(valArr);
                        $S("#monthOfYear").multiselect("refresh");
                    }

                    if (weeks && weeks !== "") {
                        valArr = weeks.split(',');
                        $S('#weekOfMonth').val(valArr);
                        $S("#weekOfMonth").multiselect("refresh");
                    }

                    if (days && days !== "") {
                        valArr = days.split(',');
                        $S('#dayOfWeek').val(valArr);
                        $S("#dayOfWeek").multiselect("refresh");
                    }
                }
            }

            var filter = backupData['filter'];
            if (filter == "true") {
                control.find('#considerFilter').prop("checked", true);
            } else {
                control.find('#considerFilter').attr('checked', false);
            }

            // For saved reports
            var savedReports = backupData['savedReports'];

            if (savedReports != undefined && savedReports !== "") {
                var savedReportsHtml = "";
                var arr = new Array();
                arr = savedReports.split(',');

                for (var i = 0; i < arr.length; i++) {
                    savedReportsHtml += '<li><a tabindex="-1" href="/Platform/CVEM/modules/CR/CRcontrol.jsp?exportBackupReport=exportBackupReport&reportName=' + getNewReportName(reportName) + '&time=' + arr[i] + '">' + arr[i] + '</a></li>';
                }

                control.find('.backedUpReportsDiv').find('ul').html(savedReportsHtml);

            }


            var targetOrgs = backupData['targetOrgs'];
            if(reportType == "organizationReports") {
                loadAssignToOrganizationsDropdown(targetOrgs);
            }

        }

    }, url, args);

}

var loadAssignToOrganizationsDropdown = (targetOrgs) => {

    var $orgSelection = $S('#organizationList');
    $orgSelection.multiselect('destroy');
    $orgSelection.empty();

    let nameArr = $S("#orgNames").text().split(",");
    $S.each(nameArr, function(index, value) {

        if (value != "") {
            if (targetOrgs && targetOrgs.includes(value)) {
                $orgSelection.append("<option value='" + value + "' selected='selected'>" + value + "</option>");
            } else {
                $orgSelection.append("<option value='" + value + "'>" + value + "</option>");
            }
        }
    });

    $orgSelection.multiselect({
        maxHeight: 180,
        maxWidth: 300,
        enableCaseInsensitiveFiltering: true,
        includeSelectAllOption: true,
        buttonWidth: '100%',
        nonSelectedText: 'Select Organizations',
        templates: {
            filter: '<li class="multiselect-item multiselect-filter"><div class="input-group" style="flex-wrap:nowrap !important; padding-right: 18px !important;"><span class="input-group-text" style="background-color: #fff !important"><i class="fas fa-search"></i></span><input class="multiselect-search" type="text" style = "width: 140px; border: 1px solid #ced4da !important"/></div></li>',
            filterClearBtn: '<span class="input-group-text" style="padding : 0 !important ; background-color: #fff !important"><button class="btn multiselect-clear-filter" type="button"><i class="fas fa-xmark"></i></button></span>',
            button: '<button type="button" class="multiselect dropdown-toggle" data-bs-toggle="dropdown"><span class="multiselect-selected-text"></span></button>',
        },
    });
}


var getNewReportName = (reportName) => {
    var reportsObj = {
        "Endpoint Query Response Report": "Posture Anomaly Report",
        "Patch Impact Report" : "Patching Impact Report",
        "Organization Patch Impact Report": "Organization Patching Impact Report"
    }
    
    if(reportsObj[reportName] !== undefined) {
        return reportsObj[reportName];
    }

    return reportName;
}


var selecttargetaccounts = (reportName) => {
	
	// setting EDR report name from the map
	reportName = EDRreportmap(reportName);
	
    var targetaccountsstring = "";
    
    if (canned_reports.includes(reportName)) {
    	var childNodes = document.getElementById("accountsListDiv").getElementsByTagName('*');
        for (var node of childNodes) {
            node.disabled = true;
        }
    }

    selectedTargetAccountsForTheReport = [];
    selectedTargetAccountNamesForTheReport = [];
    
    var request = $S.ajax({
        url: "CRcontrol.jsp?command=getReportTargetAccounts&reportName=" + reportName,
        cache: false,
        type: "GET",
        dataType: "text",
    });
    request.done(function(msg) {

        try {

            let obj = JSON.parse(msg);

            loadOrgAccounts(obj.orgs, obj.accounts);
            selectedTargetAccountsForTheReport = obj.accountIds ? obj.accountIds.split(",") : [];
            selectedTargetAccountNamesForTheReport = obj.accounts ? obj.accounts.split(",") : [];
            
            // Create mapping from account names to account IDs
            accountNameToIdMapping = {};
            if (obj.accounts && obj.accountIds) {
                var accountNames = obj.accounts.split(",");
                var accountIds = obj.accountIds.split(",");
                for (var i = 0; i < accountNames.length; i++) {
                    if (accountNames[i] && accountIds[i]) {
                        accountNameToIdMapping[accountNames[i]] = accountIds[i];
                    }
                }
            }
        } catch (err) {
            console.log(err);
        }

        /*targetaccountsstring = msg;
        var targetaccounts = targetaccountsstring.split(",");
        $S.each(targetaccounts,function(index, targetaccount){
        	//$S('#accountsList option[value='+targetaccount+']').attr('selected','selected');
        	$S('#accountsList option[value="'+targetaccount+'"]').attr('selected','selected');
        });
		
        $S('#accountsList').multiselect({
        	maxHeight: 180,
        	maxWidth: 300,
        	enableCaseInsensitiveFiltering: true,
        	includeSelectAllOption: true,
        	buttonWidth: '100%',
        	nonSelectedText: 'Select Accounts'
        });*/
    });
    request.fail(function() {
        //console.log(SanerMsg.common.failed);

        $S('#accountsList').multiselect({
            maxHeight: 180,
            maxWidth: 300,
            enableCaseInsensitiveFiltering: true,
            includeSelectAllOption: true,
            buttonWidth: '100%',
            nonSelectedText: 'Select Accounts',
            templates: {
                filter: '<li class="multiselect-item multiselect-filter"><div class="input-group" style="flex-wrap:nowrap !important; padding-right: 18px !important;"><span class="input-group-text" style="background-color: #fff !important"><i class="fas fa-search"></i></span><input class="multiselect-search" type="text" style = "width: 140px; border: 1px solid #ced4da !important"/></div></li>',
                filterClearBtn: '<span class="input-group-text" style="padding : 0 !important ; background-color: #fff !important"><button class="btn multiselect-clear-filter" type="button"><i class="fas fa-xmark"></i></button></span>',
                button: '<button type="button" class="multiselect dropdown-toggle" data-bs-toggle="dropdown"><span class="multiselect-selected-text"></span></button>',
            },
        });
        
        $S('#organizationList').multiselect({
            maxHeight: 180,
            maxWidth: 300,
            enableCaseInsensitiveFiltering: true,
            includeSelectAllOption: true,
            buttonWidth: '100%',
            nonSelectedText: 'Select Organizations',
            templates: {
                filter: '<li class="multiselect-item multiselect-filter"><div class="input-group" style="flex-wrap:nowrap !important; padding-right: 18px !important;"><span class="input-group-text" style="background-color: #fff !important"><i class="fas fa-search"></i></span><input class="multiselect-search" type="text" style = "width: 140px; border: 1px solid #ced4da !important"/></div></li>',
                filterClearBtn: '<span class="input-group-text" style="padding : 0 !important ; background-color: #fff !important"><button class="btn multiselect-clear-filter" type="button"><i class="fas fa-xmark"></i></button></span>',
                button: '<button type="button" class="multiselect dropdown-toggle" data-bs-toggle="dropdown"><span class="multiselect-selected-text"></span></button>',
            },
        });

    });


}

var exportCurrentReportModal = () => {
    /*
     * For Report Export
     */

    var modal_body = "";
    var modal_footer = "";

    modal_body = $S('#report-export-template').text();

    modal_body = modal_body.replace('%%ReportName%%', $S('#reportDisplayName').html().trim());

    var modal_template = modal.createNew(
        "reportExportModal", "modal-md", "Export Report", modal_body, modal_footer
    );

    $S('#reportExportModal').remove();
    $S('body').append(modal_template);
    $S("#reportExportModal").modal();

    $S('.modal-footer').remove();

}

var saveCustomReportModal = () => {
    /*
     * For Report Save
     */

    var modal_body = "";
    var modal_footer = "";

    modal_body = $S('#report-settings-template').text();

    var button = $S('#success-button-template').text();
    button = button.replace('%%onclickSelector%%', 'saveCustomReportBtn');
    button = button.replace('%%innerHTML%%', 'Save');
    modal_footer = button;

    var modal_template = modal.createNew(
        "reportSettingsModal", "modal-md", "Save Report", modal_body, modal_footer
    );

    $S('#reportSettingsModal').remove();
    $S('body').append(modal_template);

    var myModal = new bootstrap.Modal("#reportSettingsModal");
    myModal.show();
    // $S("#reportSettingsModal").modal();

    $S('#timepicker').mdtimepicker();

    $S('.DaysOfWeekSelect').multiselect({
        maxHeight: 180,
        enableCaseInsensitiveFiltering: true,
        includeSelectAllOption: true,
        buttonWidth: '100%',
        nonSelectedText: 'Select days',
        templates: {
            button: '<button type="button" class="multiselect dropdown-toggle" data-bs-toggle="dropdown"><span class="multiselect-selected-text"></span></button>',
        },
    });

    $S('.MonthsOfYearSelect').multiselect({
        maxHeight: 180,
        enableCaseInsensitiveFiltering: true,
        includeSelectAllOption: true,
        buttonWidth: '100%',
        nonSelectedText: 'Select months',
        templates: {
            button: '<button type="button" class="multiselect dropdown-toggle" data-bs-toggle="dropdown"><span class="multiselect-selected-text"></span></button>',
        },
    });

    $S('.WeeksOfMonthSelect').multiselect({
        maxHeight: 180,
        enableCaseInsensitiveFiltering: true,
        includeSelectAllOption: true,
        buttonWidth: '100%',
        nonSelectedText: 'Select weeks',
        templates: {
            button: '<button type="button" class="multiselect dropdown-toggle" data-bs-toggle="dropdown"><span class="multiselect-selected-text"></span></button>',
        },
    });

    $S('.backedUpReportsDiv').remove();

    //multiselect js 
    $S('#accountsList').multiselect({
        maxHeight: 180,
        maxWidth: 300,
        enableCaseInsensitiveFiltering: true,
        includeSelectAllOption: true,
        buttonWidth: '100%',
        nonSelectedText: 'Select Accounts',
        templates: {
            filter: '<li class="multiselect-item multiselect-filter"><div class="input-group" style="flex-wrap:nowrap !important; padding-right: 18px !important;"><span class="input-group-text" style="background-color: #fff !important"><i class="fas fa-search"></i></span><input class="multiselect-search" type="text" style = "width: 140px; border: 1px solid #ced4da !important"/></div></li>',
            filterClearBtn: '<span class="input-group-text" style="padding : 0 !important ; background-color: #fff !important"><button class="btn multiselect-clear-filter" type="button"><i class="fas fa-xmark"></i></button></span>',
            button: '<button type="button" class="multiselect dropdown-toggle" data-bs-toggle="dropdown"><span class="multiselect-selected-text"></span></button>',
        },
    });

    $S('#organizationList').multiselect({
        maxHeight: 180,
        maxWidth: 300,
        enableCaseInsensitiveFiltering: true,
        includeSelectAllOption: true,
        buttonWidth: '100%',
        nonSelectedText: 'Select Organizations',
        templates: {
            filter: '<li class="multiselect-item multiselect-filter"><div class="input-group" style="flex-wrap:nowrap !important; padding-right: 18px !important;"><span class="input-group-text" style="background-color: #fff !important"><i class="fas fa-search"></i></span><input class="multiselect-search" type="text" style = "width: 140px; border: 1px solid #ced4da !important"/></div></li>',
            filterClearBtn: '<span class="input-group-text" style="padding : 0 !important ; background-color: #fff !important"><button class="btn multiselect-clear-filter" type="button"><i class="fas fa-xmark"></i></button></span>',
            button: '<button type="button" class="multiselect dropdown-toggle" data-bs-toggle="dropdown"><span class="multiselect-selected-text"></span></button>',
        },
    });

}

var loadPublisherAssetFilterTree = (selectedassets, assetfilterflag) => {
    $S('.assetincludefilter').html(assetlistforselection);
    if (assetfilterflag == "include") {
        $S(".btn-toggle-log").click();
    }

    if (selectedassets != undefined && selectedassets != "") {
        $S.each(selectedassets.split(","), function(i, e) {
            if($S(".assetincludefilter option[value='" + e + "']").length){
                $S(".assetincludefilter option[value='" + e + "']").prop("selected", true);
            }else{
                var markupAppend = `<option value="${e}">${e}</option>`;
                $S(".assetincludefilter").append(markupAppend)
                $S(".assetincludefilter option[value='" + e + "']").prop("selected", true);
            }
        });
    }

    $S('.assetincludefilter').tokenize2({
        dataSource: 'select',
        searchFromStart: false,
        searchMinLength: 1,
        tokensAllowCustom: true,
        dropdownMaxItems: 100
    });
}

var loadPublisherCreatedByFilterTree = (selectedcreatedby,createdbyfilterflag) => {
    $S('.createdbyincludefilter').html(createdbylistforselection);
    if (createdbyfilterflag == "include") {
        $S(".btn-toggle-log-createby").click();
    }
    if (selectedcreatedby != undefined && selectedcreatedby != "") {
        $S.each(selectedcreatedby.split(","), function(i, e) {
            if($S(".createdbyincludefilter option[value='" + e + "']").length){
                $S(".createdbyincludefilter option[value='" + e + "']").prop("selected", true);
            }else{
                var markupAppend = `<option value="${e}">${e}</option>`;
                $S(".createdbyincludefilter").append(markupAppend)
                $S(".createdbyincludefilter option[value='" + e + "']").prop("selected", true);
            }
        });
    } 
    $S('.createdbyincludefilter').tokenize2({
        dataSource: 'select',
        searchFromStart: false,
        searchMinLength: 1,
        tokensAllowCustom: true,
        dropdownMaxItems: 100
    });
}




function loadPatchFilterTree(selectedPatches) {
    $S('.patchincludefilter').html(patcheslistforselection);
    
    if (selectedPatches != undefined && selectedPatches != "") {
        $S.each(selectedPatches.split(","), function(i, e) {
            if($S(".patchincludefilter option[value='" + e + "']").length){
                $S(".patchincludefilter option[value='" + e + "']").prop("selected", true);
            }else{
                var markupAppend = `<option value="${e}">${e}</option>`;
                $S(".patchincludefilter").append(markupAppend)
                $S(".patchincludefilter option[value='" + e + "']").prop("selected", true);
            }
        });
    }

    $S('.patchincludefilter').tokenize2({
        dataSource: 'select',
        searchFromStart: false,
        searchMinLength: 1,
        tokensAllowCustom: true,
        dropdownMaxItems: 100
    });
}

var loadVendorFilterTree = (tool, selectedvendors) => {
    if (tool == "PM") {
        $S('.vendorincludefilter').html(pmVendorlistforselection);
    } else {
        $S('.vendorincludefilter').html(cmVendorlistforselection);
    }

    if (selectedvendors != undefined) {
        $S.each(selectedvendors.split(","), function(i, e) {
            $S(".vendorincludefilter option[value='" + e + "']").prop("selected", true);
        });
    }

    $S('.vendorincludefilter').tokenize2({
        dataSource: 'select',
        searchFromStart: false,
        searchMinLength: 1,
        tokensAllowCustom: true
    });
    
}

var loadGroupDeviceFilterTree = (tool, selectedDevice, familyType) => {

    $S('#groupDeviceFilterTree').html(_spin);

    var url = "/Platform/CVEM/utils.jsp?getGroupDeviceHTMLtags=getGroupDeviceHTMLtags";
    var args = {};
    args['tool'] = tool;
    args['familyType'] = familyType;


    server.getData(function(data) {

        $S('#groupDeviceFilterTree').html(data);
        $S(".noDevicesDiv").hide()
        $S(".reportsDeviceFilterTree_selectall").prop( "checked", false ) 
        $S('#groupDeviceFilterInside').show();
        $S(":ui-fancytree").fancytree("destroy");
        initializingTheDevicesTree(selectedDevice, familyType);

    }, url, args);

}

function selectNodes(nodeList, id) {

    var tree = $S("#" + id).fancytree("getTree");

    var nodes = nodeList.split(",");
    if (nodes.length) {
        for (var i = 0; i < nodes.length; i++) {
            var node = tree.getNodeByKey(nodes[i]);

            if (node != null && !node.selected) {
                node.setSelected(true);
            }
        }
    }

}

function createToggleContainer(msgArr, msgType) {
	var titleContent = msgType == "error" ? 'A report with the same name is already present for '+msgArr.length+ ' accounts'
			: 'Reports Successfully saved for ' +msgArr.length+ ' accounts';
	var titleClassName = msgType == "error" ? "error-title" : "success-title";
	var collapseDivClassName = msgType == "error" ? "collapse-error" : "collapse-success"; 
	
	var title = '<br><h4 class="' + titleClassName + '"><i class="fa fa-angle-down"></i> ' +titleContent+ '</h4>';
    var collapseDiv = '<div class="' + collapseDivClassName + ' scroll-style" style="display:none;">';
    var mainDiv = "";
    msgArr.forEach(item => {
    	var itemIndex = msgArr.indexOf(item);
    	var deviceName = item.split(":")[0];
    	if (itemIndex < msgArr.length - 1) {
    		collapseDiv += deviceName + ", ";
    	} else {
    		collapseDiv += deviceName + ".";
    	}
    });
    collapseDiv += "</div>";
    mainDiv += title + collapseDiv;
    
    return mainDiv;
}

var reportMenuItemsCSVDownload = (parent) => {

    var fileName = parent.data('title');

    if ($S('#' + parent.find('.grid-body').attr('id') + "Table").length > 0) {
        exportTabletoCSV(parent.find('.grid-body').attr('id') + "Table", fileName, "CR_REPORTS");
    } else {
        var fname = parent.attr('data-fname');
        var columnstodisplay = parent.attr('data-columnstodisplay');

        var args = {};
        var deviceFilter = parent.attr('data-devicefilter');

        if (deviceFilter != "") {
            args['deviceList'] = deviceFilter;
        }

        var tagFilter = parent.attr('data-tagfilter');

        if (tagFilter != "") {
            args['tagFilter'] = tagFilter;
        }

        var accountFilter = parent.attr('data-accountsfilter');

        if (accountFilter != undefined && accountFilter != "undefined") {
            args['accountNamesList'] = accountFilter;
        }

        var installedstartdatefilter = parent.attr('data-installedstartdatefilter');
        if (installedstartdatefilter != "") {
            args['installedstartdatefilter'] = installedstartdatefilter;
        }

        var installedenddatefilter = parent.attr('data-installedenddatefilter');
        if (installedenddatefilter != "") {
            args['installedenddatefilter'] = installedenddatefilter;
        }

        var releasedstartdatefilter = parent.attr('data-releasedstartdatefilter');
        if (releasedstartdatefilter != "") {
            args['releasedstartdatefilter'] = releasedstartdatefilter;
        }

        var releasedenddatefilter = parent.attr('data-releasedenddatefilter');
        if (releasedenddatefilter != "") {
            args['releasedenddatefilter'] = releasedenddatefilter;
        }

        var startdatefilter = parent.attr('data-startdatefilter');
        if (startdatefilter != "") {
            args['startdatefilter'] = startdatefilter;
        }

        var enddatefilter = parent.attr('data-enddatefilter');
        if (enddatefilter != "") {
            args['enddatefilter'] = enddatefilter;
        }

        var assetFilterFlag = parent.attr('data-assetfilterflag');

        if (assetFilterFlag != "") {
            args['assetFilterFlag'] = assetFilterFlag;
        }
        var assetFilter = parent.attr('data-assetfilter');
        if (assetFilter != "") {
            args['assetList'] = assetFilter;
        }

        var createdbyFilterFlag = parent.attr('data-createdbyfilterflag');
        if(createdbyFilterFlag != "") {
            args['createdbyFilterFlag'] = createdbyFilterFlag;
        }

        var createdbyFilter = parent.attr('data-createdbyfilter');
        if(createdbyFilter != "") {
            args['createdbyList'] = createdbyFilter;
        }
        

        var patchFilter = parent.attr('data-patchfilter');
        if (patchFilter != "") {
            args['patchList'] = patchFilter;
        }

        var familyFilter = parent.attr('data-familyfilter');
        if (familyFilter != "") {
            args['familyList'] = familyFilter;
        }

        var columnstodisplay = parent.attr('data-columnstodisplay');
        var columntosort = parent.attr('data-columntosort');
        var sortorder = parent.attr('data-sortorder');
        var rowlimit = parent.attr('data-rowlimit');
        var data_operations = parent.attr('data-operations');

        var datatype = parent.attr('data-datatype');
        var mergetype = parent.attr('data-mergetype');
        var mergekey = parent.attr('data-mergekey');
        var sortkeys = parent.attr('data-sortkeys');
        var ascendingorder = parent.attr('data-ascendingorder');
        var limit = parent.attr('data-limit');

        if (datatype != undefined && datatype != null && datatype.length)
            args['datatype'] = datatype;

        if (mergetype != undefined && mergetype != null && mergetype.length)
            args['mergetype'] = mergetype;

        if (mergekey != undefined && mergekey != null && mergekey.length)
            args['mergekey'] = mergekey;
            
        if (sortkeys != undefined && sortkeys != null && sortkeys.length)
            args['sortkeys'] = sortkeys;
        
        if (ascendingorder != undefined && ascendingorder != null && ascendingorder.length)
            args['ascendingorder'] = ascendingorder;
            
        if (limit != undefined && limit != null && limit.length)
            args['limit'] = limit;

        if (rowlimit != undefined)
            args['rowLimit'] = rowlimit;

        if (columntosort != undefined)
            args['columnToSort'] = columntosort;

        if (sortorder != undefined)
            args['sortOrder'] = sortorder;

        if (data_operations != undefined)
            args['data_operations'] = data_operations;

        var url = "CRcontrol.jsp?command=getApiDataInJson&fname=" + fname

        if (fname === 'getQueryTable') {
            args['queryName'] = $S("#" + id).closest('li').data('title');
        }

        // Get data from server
        server.getData(function(data) {

            if(data == "") {
                data = "{}";
            }

            let innerMap = {};
            let json = JSON.parse(data);

            var title = columnstodisplay + '\n';
            var rows = [];

            if(json && Object.keys(json).length) {
                for (var i = 0, len = json[Object.keys(json)[0]].length; i < len; ++i) {
                    var each = json[Object.keys(json)[0]][i];
                    var data = [];
    
                    var columnsArr = columnstodisplay.split(",");
                    columnsArr.forEach(element => {
                        data.push('"' + each[element] + '"');
                    });
    
                    data = data.join(",");
                    rows.push(data);
                }
            } else {
                rows.push("No data available in table");
            }

            rows = rows.join("\n");

            var csv = title + rows;
            var uri = 'data:text/csv;charset=utf-8,' + encodeURIComponent(csv);
            var download_link = document.createElement('a');
            download_link.href = uri;
            var ts = fileName;
            download_link.download = ts + ".csv";
            document.body.appendChild(download_link);
            download_link.click();
            document.body.removeChild(download_link);

        }, url, args);

    }


};

var validateEmailReports = (email) => {
    var valid = false;
    if (email) {
        var arr = email.split(',');
        for (var n = 0; n < arr.length; n++) {
            var eachEmail = arr[n].trim();
            var re = /^([\w-]+(?:\.[\w-]+)*)@((?:[\w-]+\.)*\w[\w-]{0,66})\.([a-z]{2,6}(?:\.[a-z]{2})?)$/i;
            if (re.test(eachEmail))
                valid = true;
            else
                valid = false;
        }
    }
    return valid;
}

$S(document).on('click', '.emailPDFReportFromNameBtn', function() {
    var reportName = $S(this).attr("data-reportname");
    
    var emailAddr = $S('#emailCurrentReportInput').val();
    // setting EDR report name from the map
    reportName = EDRreportmap(reportName);
    
    emailAddr = emailAddr.replace(" ,", ",");
    emailAddr = emailAddr.replace(", ", ",");
    
    if (!validateEmailReports(emailAddr)) {
        alert(SanerMsg.validation.emailProper);
        return false;
    }
    $S('.btnsend').prop("disabled", true);
        $S('.btnsend').html(
                '<i class="fa fa-circle-o-notch fa-spin"></i> Sending...'
    );
    sendEmail(emailAddr, reportName);
});

var sendEmail = (emailAddr, reportName) => {
	
    var url = "CRcontrol.jsp?command=emailCurrentReport";
    var args = {};
    args['reportsType'] = reportType;
    args['reportName'] = reportName;
    args['emailAddr'] = emailAddr;

if(readymade_report_names.indexOf($S('#reportDisplayName').html().trim()) >= 0) {  
        readyMadeReport();
    }

    if (reportName == 'Custom Report' || ($S('#reportDisplayName').html() == reportName && 
                readymade_report_names.indexOf(reportName) < 0)) {
        var idList = getListIdsInOrder();
        var json = convertCustomReportsToJson(idList);
        json = json.replace(/\\/g, "\\\\");
        args['json'] = json;
    }

    var filter = "false";

    if ($S('#filterincludeinpdf').is(':checked')) {
        filter = "true";
    }

    args['filter'] = filter;

    // Get data from server
    server.getData(function(data) {
        
        if (data.indexOf("Error") >= 0 || data == "fail" || data == "Mail settings not configured.") {
            showMsg("", data, "error");
            $S('.btnsend').prop("disabled", false);
            $S('.btnsend').html('Send');
            return false;
        } else {
            $S('#emailReportsModal').modal('hide');
            showMsg("", SanerMsg.reports.mailSent, "success");
            return true;
        }

    }, url, args);

}

var defaultReportCtrl = (reportName, ctrl) => {
    var url = "CRcontrol.jsp?command=defaultReportCtrl";
    if(reportType == "organizationReports") {
        url = "CRcontrol.jsp?command=defaultOrgReportCtrl";
    }
    var previousDefaultReportName = $S(".defaultReportCtrl[title='Default Report']").attr("data-name");
    var args = {};
    args['reportName'] = reportName;
    args['previousDefaultReportName'] = previousDefaultReportName;

    // Get data from server
    server.getData(function(data) {

        if (data.indexOf("Success!") >= 0) {

            $S('.fa-bookmark').parent('span').attr('title', 'Set this as Default Report')
            $S('.fa-bookmark').addClass('fa-regular').removeClass('fa-solid');

            $S(ctrl).find('i').addClass('fa-solid').removeClass('fa-regular');
            $S(ctrl).attr('title', 'Default Report')

        } else {
            showMsg("", SanerMsg.reports.unableToSetDefault, "error");
        }

    }, url, args);
}

var removedefaultReportCtrl = (reportName, ctrl) => {
    var url = "CRcontrol.jsp?command=removedefaultReportCtrl";
    if(reportType == "organizationReports") {
        url = "CRcontrol.jsp?command=removedefaultOrgReportCtrl";
    }
    
    var args = {};
    args['reportName'] = reportName;

    // Get data from server
    server.getData(function(data) {

        if (data.indexOf("Success!") >= 0) {

            $S(ctrl).find('i').addClass('fa-regular').removeClass('fa-solid');
            $S(ctrl).attr('title', 'Set this as Default Report')

        } else {
            showMsg("", SanerMsg.reports.unableToSetDefault, "error");
        }

    }, url, args);
}

var deleteSavedCustomReport = (reportName, ctrl) => {

    var action = confirm("Are you sure to delete the custom report?");

    if (action) {
        var url = "CRcontrol.jsp?command=deleteSavedCustomReport";
        if(reportType == "organizationReports") {
            url = "CRcontrol.jsp?command=deleteSavedOrgCustomReport";
        }
        
        var args = {};
        args['reportName'] = reportName;

        // Get data from server
        server.getData(function(data) {

            if (data.indexOf("Success!") >= 0) {
                showMsg("", SanerMsg.reports.reportDeletedSuccessfully, "success");

                $S(ctrl).closest('.savedReportContList').remove();

                if ($S('#reportDisplayName').html() === reportName) {
                    $S('.newLayout').click();
                }

            } else {
                showMsg("", SanerMsg.reports.reportDeletingFailed, "error");

            }

        }, url, args);
    }

}

var revertChangesToDefault = (reportName, ctrl) => {

    var action = confirm("Any changes made to the report will be reverted to default, Do you want to proceed?");

    if (action) {
        var url = "CRcontrol.jsp?command=revertChangesToDefault";
        var args = {};
        args['reportName'] = reportName;

        // Get data from server
        server.getData(function(data) {

            if (data.indexOf("Success!") >= 0) {
                showMsg("", SanerMsg.reports.reportRevertedSuccessfully, "success");

                $S("a[data-name='" + reportName + "']").click();

                // clearing oveall filter
                $S('.overallFilterModal').attr('data-devicefilter', '');
                $S('.overallFilterModal').attr('data-tagfilter', '');
                $S('.overallFilterModal').attr('data-accountsfilter', '');
                $S('.overallFilterModal').attr('data-installedstartdatefilter', '');
                $S('.overallFilterModal').attr('data-installedenddatefilter', '');
                $S('.overallFilterModal').attr('data-releasedstartdatefilter', '');
                $S('.overallFilterModal').attr('data-releasedenddatefilter', '');
                $S('.overallFilterModal').attr('data-startdatefilter', '');
                $S('.overallFilterModal').attr('data-enddatefilter', '');
                $S('.overallFilterModal').attr('data-assetfilter', '');
                $S('.overallFilterModal').attr('data-createdbyfilter', '');
                $S('.overallFilterModal').attr('data-patchfilter', '');
                $S('.overallFilterModal').attr('data-assetexcludefilter', '');
                $S('.overallFilterModal').attr('data-createdbyfilterflag', '');
                $S('.overallFilterModal').attr('data-createdbyexcludefilter', '');
                $S('.overallFilterModal').attr('data-assetfilterflag', '');
                $S('.overallFilterModal').attr('data-familyfilter', '');

            } else {
                showMsg("", SanerMsg.reports.failedRevert, "error");

            }

        }, url, args);
    }

}

var reportMenuItemsNameEditModal = (parent) => {

    var title = $S('#' + parent).closest('li').attr('data-title');
    var description = $S('#' + parent).closest('li').attr('data-description');

    if(description && description.length) {
        description = description.replaceAll("\\n", "<br>");
    }

    var modal_body = "";
    var modal_footer = "";

    modal_body = $S('#report-title-desc-template').text();
    modal_body = modal_body.replace('%%title%%', title);
    modal_body = modal_body.replace('%%description%%', description);

    var button = $S('#success-button-template').text();
    button = button.replace('%%onclickSelector%%', 'updateNameAndDescriptionBtn');
    button = button.replace('%%parentId%%', parent);
    button = button.replace('%%innerHTML%%', 'Update');
    modal_footer = button;

    var modal_template = modal.createNew(
        "nameAndDescUpdateModal", "modal-md", "Edit Title and Description", modal_body, modal_footer
    );

    $S('#nameAndDescUpdateModal').remove();
    $S('body').append(modal_template);
    //$S("#nameAndDescUpdateModal").modal();
    var myModal = new bootstrap.Modal("#nameAndDescUpdateModal");
    myModal.show();

}

$S(document).on('click', '.updateNameAndDescriptionBtn', function() {
    var parent = $S(this).attr("data-parentid");
    var title = $S('#reportTitle').val();
    var description = $S('#reportDescription').text();
    
    if (title.length == 0) {
        showMsg("", SanerMsg.reports.titleNotEmpty, "info");
        return false;
    }
    if (title.length < 4) {
        showMsg("", SanerMsg.reports.titleContainsAtleast4Characters, "info");
        return false;
    }
    title = htmlEscape(title);
    description = htmlEscape(description);
    
    $S('#' + parent).closest('li').attr('data-title', title);
    $S('#' + parent).closest('li').attr('data-description', description);
    
    $S('#' + parent).closest('.inner').find('h4').find('span').html(title);
    $S('#' + parent).closest('.inner').find('h4').find('.fa-pen-to-square').html("");
    
    $S("#nameAndDescUpdateModal").modal('hide');
});

var createNewGridItem = (item) => {
    // Shallow Copy
    let grid = Object.assign({}, gridListElements);
    grid.create(
        item.data('installedstartdatefilter'),
        item.data('installedenddatefilter'),
        item.data('releasedstartdatefilter'),
        item.data('releasedenddatefilter'),
        item.data('tagfilter'),
        item.data('startdatefilter'),
        item.data('enddatefilter'),
        item.data('charttooltip'),
        item.data('title'),
        item.data('type'),
        item.data('function'),
        item.data('width'),
        item.data('height'),
        item.data('xaxis'),
        item.data('yaxis'),
        item.data('id'),
        item.data('class'),
        item.data('columns'),
        item.data('columnstodisplay'),
        item.data('chartxaxis'),
        item.data('chartyaxis'),
        item.data('description'),
        item.data('filters'),
        item.data('accountsfilter'),
        item.data('devicefilter'),
        item.data('assetfilterflag'),
        item.data('createdbyfilterflag'),
        item.data('assetfilter'),
        item.data('createdbyfilter'),
        item.data('patchfilter'),
        item.data('assetexcludefilter'),
        item.data('createdbyexcludefilter'),
        item.data('familyfilter'),
        item.data('columnnames'),
        item.data('columncolors'),
        item.data('chartlabel'),
        item.data('module'),
        item.data('emqueries'),
        item.data('ogtitle'),
        item.data('columntosort'),
        item.data('sortorder'),
        item.data('rowlimit'),
        item.data('datatype'),
        item.data('mergetype'),
        item.data('mergekey'),
        item.data('sortkeys'),
        item.data('ascendingorder'),
        item.data('limit'),
        item.data('operations'),
        item.data('sortcolumnformat')
    );

    // Deep Copy
    //let grid = {...gridListElements};
    //grid.create(item.html(), item.data('type'), item.data('function'), item.data('width'), item.data('height'), item.data('xaxis'), item.data('yaxis'));

    // Hide and Show Action Btn's
    $S('.clearReportLists').show();
    $S('.overallFilterModal').show();
    $S('.reloadReportSections').show();
    $S('.currentReportsEmail').show();
    $S('.currentReportsPDFDownload').show();
    if ($S('#reportDisplayName').html() === 'Custom Report') {
        $S('.saveCustomReportModal').show();
    } else {
        $S('.updateCustomReportModal').show();
    }

}

var createNewGridItemJson = (each) => {
    var chartxaxis = each['chartxaxis'];
    if (chartxaxis == undefined)
        chartxaxis = "";

    var chartyaxis = each['chartyaxis'];
    if (chartyaxis == undefined)
        chartyaxis = "";
    
    var accountsfilter = each['accountsfilter'];
    if(accountsfilter == undefined || accountsfilter == "undefined"){
        accountsfilter = "";
    }

    let grid = Object.assign({}, gridListElements);
    grid.create(
        each['installedstartdatefilter'],
        each['installedenddatefilter'],
        each['releasedstartdatefilter'],
        each['releasedenddatefilter'],
        each['tagfilter'],
        each['startdatefilter'],
        each['enddatefilter'],
        each['charttooltip'],
        each['title'],
        each['type'],
        each['fname'],
        each['w'],
        each['h'],
        '0',
        '0',
        '',
        '',
        each['columns'],
        each['columnstodisplay'],
        chartxaxis,
        chartyaxis,
        each['description'],
        each['filters'],
        accountsfilter,
        each['devicefilter'],
        each['assetfilterflag'],
        each['createdbyfilterflag'],
        each['assetfilter'],
        each['createdbyfilter'],
        each['patchfilter'],
        each['assetExcludefilter'],
        each['createdbyexcludefilter'],
        each['familyfilter'],
        each['columnnames'],
        each['columncolors'],
        each['chartlabel'],
        each['module'],
        each['emqueries'],
        each['ogtitle'],
        each['columntosort'],
        each['sortorder'],
        each['rowlimit'],
        each['datatype'],
        each['mergetype'],
        each['mergekey'],
        each['sortkeys'],
        each['ascendingorder'],
        each['limit'],
        each['operations']
    );

    // Hide and Show Action Btn's
    $S('.clearReportLists').show();
    $S('.overallFilterModal').show();
    $S('.reloadReportSections').show();
    $S('.currentReportsEmail').show();
    $S('.currentReportsPDFDownload').show();
    if ($S('#reportDisplayName').html() === 'Custom Report') {
        $S('.saveCustomReportModal').show();
    } else {
        $S('.updateCustomReportModal').show();
    }

    // For readymade report
    if(readymade_report_names.indexOf($S('#reportDisplayName').html().trim()) >= 0) {  
        readyMadeReport();
    } else {
        editableReport();
    }

}

var clearOverallFilterValues = () => {
    // Reset the flag when clearing overall filter values
    isReportRecentlyUpdated = false;
    
    // Clear all filter modal values
    $S('.overallFilterModal').attr('data-devicefilter', '');
    $S('.overallFilterModal').attr('data-tagfilter', '');
    $S('.overallFilterModal').attr('data-accountsfilter', '');
    $S('.overallFilterModal').attr('data-installedstartdatefilter', '');
    $S('.overallFilterModal').attr('data-installedenddatefilter', '');
    $S('.overallFilterModal').attr('data-releasedstartdatefilter', '');
    $S('.overallFilterModal').attr('data-releasedenddatefilter', '');
    $S('.overallFilterModal').attr('data-startdatefilter', '');
    $S('.overallFilterModal').attr('data-enddatefilter', '');
    $S('.overallFilterModal').attr('data-assetfilter', '');
    $S('.overallFilterModal').attr('data-createdbyfilter', '');
    $S('.overallFilterModal').attr('data-patchfilter', '');
    $S('.overallFilterModal').attr('data-assetexcludefilter', '');
    $S('.overallFilterModal').attr('data-createdbyexcludefilter', '');
    $S('.overallFilterModal').attr('data-createdbyfilterflag', '');
    $S('.overallFilterModal').attr('data-assetfilterflag', '');
    $S('.overallFilterModal').attr('data-familyfilter', '');
}

var clearReportLists = (control) => {
    // Reset the flag when clearing report lists
    isReportRecentlyUpdated = false;

    $S('#grid').html("");

    gridOptions.containerHeight = 0;
    gridOptions.location = {};

    // clearing oveall filter
    clearOverallFilterValues();
    
    // Hiding action btn's
    $S('.updateCustomReportModal').hide();
    $S('.saveCustomReportModal').hide();
    $S('.currentReportsEmail').hide();
    $S('.currentReportsPDFDownload').hide();
    $S('.clearReportLists').hide();
    $S('.overallFilterModal').hide();
    $S('.reloadReportSections').hide();

}

var reloadReportSections = (control) => {
    jsData = "";
    if(readymade_report_names.indexOf($S('#reportDisplayName').html().trim()) >= 0) {
        getDataAndLoadReport($S('#reportDisplayName').html().trim());
    } else {
    // Getting report data in json format
        var idList = getListIdsInOrder();
        
            var data = convertCustomReportsToJson(idList);

        // Clearing Existing one
        $S('#grid').html("");
        gridOptions.containerHeight = 0;
        gridOptions.location = {};
        if(data != '{}' && data != undefined && data != null){
        let json = JSON.parse(data);
        let value = 0;
        renderReloadReportInUI(json[Object.keys(json)[0]], value);
        }   
    }

    
}

var stopTimeOutMethod = () => {
    $S(".loadingReports").remove();
    clearTimeout(timeOutMethod);
}


var renderReloadReportInUI = (jsonData, value) => {
    var max = Math.min(value + callNumberOfAPIsCount, jsonData.length);
    var i;
    for (i = value; i < max; ++i, ++value) {
        var each = jsonData[Object.keys(jsonData)[i]];

        if (each['fname'] === 'getQueryTable')
            each['emqueries'] = true;

        createNewGridItemJson(each);
    }

    if (i < jsonData.length) {
        timeOutMethod = setTimeout(renderReloadReportInUI, 10000, jsonData, value);
    }
}

$S(document).on('click', '.applyOverallFilterBtn', function() {
    // Reset the flag when overall filters are applied
    isReportRecentlyUpdated = false;
    
    var deviceList = selectedDeviceForAction;
    var accountNamesList = selectedAccountForAction;

    var assetList  = $S('.assetincludefilter').next('.tokenize').find('ul li.token').map(function () {
        return $S(this).attr('data-value') || null;
    }).get();
    var patchList =  $S('.patchincludefilter').next('.tokenize').find('ul li.token').map(function () {
        return $S(this).attr('data-value') || null;
    }).get();
    var assetfilterflag = $S('#assetfilter_include_exclude_div').find('.active').attr("data-val");
    var familyList = [];
    var windows = $S('#windowsauto').is(":checked");
    var linux = $S('#linuxauto').is(":checked");
    var macos = $S('#macauto').is(":checked");
    var others = $S('#othersauto').is(":checked");
    
    if (windows) familyList.push("windows");
    if (linux) familyList.push("unix");
    if (macos) familyList.push("macos");
    if (others) familyList.push("others");
    
    var startdatefilter = $S("#startDateFilter").val();
    var enddatefilter = $S("#endDateFilter").val();

    var installedstartdatefilter = $S("#installedStartDateFilter").val();
    var installedenddatefilter = $S("#installedEndDateFilter").val();    
    var releasedstartdatefilter = $S("#releasedStartDateFilter").val();
    var releasedstartdatefilter = $S("#releasedEndDateFilter").val();

    var tagList = prepareAndGetTagsFilterJsonObj();

    if (familyList.length == 4) familyList = [];
    
    if (assetList == null || assetList == undefined)
        assetList = [];

    if (patchList == null || patchList == undefined)
        patchList = [];
    
    $S(".overallFilterModal").attr('data-devicefilter', deviceList);
    $S(".overallFilterModal").attr('data-accountsfilter', accountNamesList);
    $S(".overallFilterModal").attr('data-tagfilter', tagList);
   
    $S(".overallFilterModal").attr('data-installedstartdatefilter', installedstartdatefilter);
    $S(".overallFilterModal").attr('data-installedenddatefilter', installedenddatefilter);
    $S(".overallFilterModal").attr('data-releasedstartdatefilter', releasedstartdatefilter);
    $S(".overallFilterModal").attr('data-releasedenddatefilter', releasedstartdatefilter);

    $S(".overallFilterModal").attr('data-startdatefilter', startdatefilter);
    $S(".overallFilterModal").attr('data-enddatefilter', enddatefilter);
    $S(".overallFilterModal").attr('data-assetfilter', assetList.join(","));
    $S(".overallFilterModal").attr('data-patchfilter', patchList.join(","));
    $S(".overallFilterModal").attr('data-assetfilterflag', assetfilterflag);
    $S(".overallFilterModal").attr('data-familyfilter', familyList.join(","));
    
    // Getting report data in json format
    var idList = getListIdsInOrder();
    //idList.reverse();
    var data = convertCustomReportsToJson(idList);
    
    // Clearing Existing one
    $S('#grid').html("");
    gridOptions.containerHeight = 0;
    gridOptions.location = {};
    
    let json = JSON.parse(data);
    
    for (var i = 0, len = json[Object.keys(json)[0]].length; i < len; ++i) {
        var each = json[Object.keys(json)[0]][i];
    
        if (each['fname'] === 'getQueryTable')
            each['emqueries'] = true;
    
            if(reportType === "organizationReports") {
                each['accountsfilter'] = accountNamesList;
            }else{
        var filterStr = each['filters'];
    
        if (filterStr != undefined && filterStr.indexOf('asset') >= 0) {
            each['assetfilterflag'] = assetfilterflag;
            each['assetfilter'] = assetList.join(",");
        }
        if (filterStr != undefined && filterStr.indexOf('patch') >= 0) {
            each['patchfilter'] = patchList.join(",");
        }
        if (filterStr != undefined && filterStr.indexOf('device') >= 0)
            each['devicefilter'] = deviceList;
            each['tagfilter'] = tagList;
        if (filterStr != undefined && filterStr.indexOf('family') >= 0)
            each['familyfilter'] = familyList.join(",");
    }
        createNewGridItemJson(each);
    }

    let $modal = $S(".overallFilterModal"); // Select once and store in a variable
    let hasValue = 
        $modal.attr('data-devicefilter') || 
        $modal.attr('data-accountsfilter') || 
        $modal.attr('data-tagfilter') ||
        $modal.attr('data-installedstartdatefilter') ||
        $modal.attr('data-installedenddatefilter') ||
        $modal.attr('data-releasedstartdatefilter') ||
        $modal.attr('data-releasedenddatefilter') ||
        $modal.attr('data-startdatefilter') ||
        $modal.attr('data-enddatefilter') ||
        $modal.attr('data-assetfilter') ||
        $modal.attr('data-createdbyfilter') ||
        $modal.attr('data-patchfilter') ||
        $modal.attr('data-familyfilter');

if (hasValue) {
    $S(".reportOverallActions.overallFilterModal.nav-item a").css('color', 'red');
} else {
    $S(".reportOverallActions.overallFilterModal.nav-item a").removeAttr('style');

}

    
    $S('#filterModal').modal('hide');
});

$S(document).on('keyup','.reportMenuDiv-search-input', function () {
    var value = $S(this).val();
    $S(".reportMenuDiv li").each(function() {
        var reportText = $S(this).text().trim();
        if (reportText != undefined && reportText != "" && reportText.toLowerCase().includes(value.toLowerCase())) {
            $S(this).show();
            $S(this).prevAll('.dropdown-header').first().show();
            $S('.toolHeaderClickToExpand').find('i').removeClass('fa-chevron-down').addClass('fa-chevron-up');
        } else {
            $S(this).hide();
        }
        $S('.reportMenuDiv-search-li').show();
    });
    hidingTheEmptyDataToolHeaderInSearchMenuAPIs();
    if (value === "") {
        $S('.toolHeaderClickToExpand:not([data-module="Device"])').click();
    }
});

$S(document).on('keyup','.savedReport-search-input', function () {
    var value = $S(this).val();
    $S(".savedReportsCont li").each(function() {
        if ($S(this).text().toLowerCase().search(value.toLowerCase()) > -1) {
            $S(this).show();
            $S(this).prevAll('.dropdown-header-li').first().show();
        } else {
            $S(this).hide();
        }
        $S('.savedReport-search-li').show();
    });
});

var newLayoutHelpText = () => {
    var data = "";

    data = $S('#newLayoutHelpText-template').text();

    return data;
}

function softwareNameLazyLoad() {
    // for autocomplete software name
    var softwareData = [];
    var softwareNames = $S("#softwareNames").val();
    softwareNames = softwareNames.slice(1, -1);
    var softwareNamesArray = softwareNames.split(',');
    for (var eachSoftwareNames in softwareNamesArray) {
        var each = {};
        each.name = softwareNamesArray[eachSoftwareNames];
        softwareData.push(each);
    }

    var options = {
        data: JSON.parse(JSON.stringify(softwareData)),
        getValue: "name",
        list: {
            match: {
                enabled: true
            }
        }
    };

    $S("#softwareInstallerName").easyAutocomplete(options);
    $S('.easy-autocomplete').css("width", "100%");
}

function toggleField(hideObj, showObj) {
    hideObj.disabled = true;
    hideObj.style.display = 'none';
    showObj.disabled = false;
    showObj.style.display = 'inline';
    showObj.focus();
}

var loadOrgAccounts = (orgIds, selectAccIds) => {


    if(selectAccIds && selectAccIds.length) {
        orgIds = orgIds.split(",");
        var currentOrgId = $S('#searchAccInp').attr("data-currentorgid");
        orgIds = orgIds.filter(function(orgId) {
            return orgId !== currentOrgId;
        })[0];
    }

    $S('#other-org-for-move').val(orgIds);

    var $accountChoice = $S("#accountsList");

    var req = $S.ajax({
        url: '/Platform/CVEM/utils.jsp?command=getAccountsOfAnOrganization',
        type: 'POST',
        dataType: 'text',
        data: { "orgId": orgIds },
        beforeSend: function() {
            $accountChoice.multiselect('destroy');
            $accountChoice.empty();
        }
    });
    req.done(function(msg) {
        msg = msg.trim();
        if (msg == _timeout) {
            window.location = "/Platform/CVEM/control.jsp?command=logout";
        } else if (msg.indexOf("Login to Viser") >= 0 && msg.indexOf(">This is Login Page<") >= 0) {
            window.location = "/Platform/CVEM/control.jsp?command=logout";
        } else {

            // For Account selection
            var selectAccList = [];
            if (selectAccIds != undefined && selectAccIds != null && selectAccIds != "") {
                selectAccList = selectAccIds.split(",");
            }

            let nameArr = msg.split(",");
            $S.each(nameArr, function(index, value) {

                if (value != "") {
                    let val = value.split("||");

                    if (selectAccList.includes(val[1])) {
                        $accountChoice.append("<option value='" + val[1] + "' selected='selected'>" + val[1] + "</option>");
                    } else {
                        $accountChoice.append("<option value='" + val[1] + "'>" + val[1] + "</option>");
                    }
                } else {
                    $accountChoice.append("<option value='' disabled='disabled'>No accounts available</option>");
                }
            });

            //multiselect js 
            $S('#accountsList').multiselect({
                maxHeight: 180,
                templates: {
                    filter: '<li class="multiselect-item multiselect-filter"><div class="input-group" style="flex-wrap:nowrap !important; padding-right: 18px !important;"><span class="input-group-text" style="background-color: #fff !important"><i class="fas fa-search"></i></span><input class="multiselect-search" type="text" style = "width: 140px; border: 1px solid #ced4da !important"/></div></li>',
                    filterClearBtn: '<span class="input-group-text" style="padding : 0 !important ; background-color: #fff !important"><button class="btn multiselect-clear-filter" type="button"><i class="fas fa-xmark"></i></button></span>',
                    button: '<button type="button" class="multiselect dropdown-toggle" data-bs-toggle="dropdown"><span class="multiselect-selected-text"></span></button>',
                },
                enableCaseInsensitiveFiltering: true,
                includeSelectAllOption: true,
                buttonWidth: '100%',
                nonSelectedText: 'Select Accounts'
            });
        }
    });
    req.fail(function(textStatus) {
        showMsg("", "Unable to get the sites of " + this.options[this.selectedIndex].text, "error");
    });

}

var getTheDevicesBasedOnTheTags = function(selectedDevice, familyType) {
    var familySelectObj = {
        'windowsauto':'windows',
        'linuxauto':'unix',
        'macauto':'macos',
        'othersauto':'others'
    }

    var selectedFamilies = [];
    $S("input[name=missingpatchfamily]:checked").each(function(index, item) {
        var value = $S(item).attr("id");
        selectedFamilies.push(familySelectObj[value]);
    });

    let url = "/Platform/CVEM/deviceTagging/deviceTagging.jsp?command=getGroupAndDeviceNamesWithConditions";
    let args = {};
    args['families'] = selectedFamilies.toString();
    args['deviceTags'] = prepareAndGetTagsFilterJsonObj();
    args['useNetworkDevices'] = true;
    if(!$S(".othersauto").is(":visible")){
        args['useNetworkDevices'] = false;
    }
    utils.getDataFromServer(function(msg) {
       if(msg != null) {
        var resultObj = JSON.parse(msg);
        var data = "";
        data += '<ul id="grouptreetest">';

        if(Object.keys(resultObj).length) {
            for(var key in resultObj) {
                data +=  '<li id="'+key+'">'+key+'<ul>';
                _.forEach(resultObj[key], function(deviceObj) {
                    data += '<li id="'+deviceObj['host-name']+'">'+deviceObj['host-name']+'</li>';
                });

                data += '</ul>';
            }
            data += '</li></ul>';
            $S('#groupDeviceFilterTree').html(data);
            $S(".noDevicesDiv").hide()
            $S(".reportsDeviceFilterTree_selectall").prop( "checked", false ) 
            $S('#groupDeviceFilterInside').show();
            $S(":ui-fancytree").fancytree("destroy");
            initializingTheDevicesTree(selectedDevice, familyType);
        } else {
            $S(".noDevicesDiv").show()
            $S('#groupDeviceFilterInside').hide();
        }

       }
    }, url, args);
}


var initializingTheDevicesTree = function(selectedDevice, familyType) {
    $S("#groupDeviceFilterTree").fancytree({
        extensions: ["filter"],
        quicksearch: true,
        checkbox: true,
        selectMode: 3,

        select: function(event, data) {
            var node = data.node;
            if (node.isSelected()) {
                if (node.isUndefined()) {
                    // Load and select all child nodes
                    node.load().done(function() {
                        node.visit(function(childNode) {
                            childNode.setSelected(true);
                        });
                    });
                } else {
                    // Select all child nodes
                    node.visit(function(childNode) {
                        childNode.setSelected(true);
                    });
                }
            }
            var selKeys = $S.map(data.tree.getSelectedNodes(), function(node) {
                return node.key;
            });
            grpDevArray = $S.map(selKeys, function(item) {
                var tempnode = data.tree.getNodeByKey(item);
                var tempstructure = [];
                if (tempnode.data.subsid != null)
                    tempstructure.push(tempnode.title + ',' + tempnode.data.subsid);
                else
                    tempstructure.push(tempnode.title);
                while (tempnode.getParent().getParent()) {
                    tempstructure.push(tempnode.getParent().title);
                    tempnode = tempnode.getParent();
                }
                tempstructure.reverse();
                return tempstructure.join('/');
            });
            var selRootNodes = data.tree.getSelectedNodes(true);
            var selRootKeys = $S.map(selRootNodes, function(node) {
                return node.title;
            });

            // test selectedDeviceForAction
            if (node.isSelected()) {
                if (node.isUndefined()) {
                    // Load and select all child nodes
                    node.load().done(function() {
                        node.visit(function(childNode) {
                            childNode.setSelected(true);
                        });
                    });
                } else {
                    // 	Select all child nodes
                    node.visit(function(childNode) {
                        childNode.setSelected(true);
                    });
                }
            }

            // Get a list of all selected nodes, and convert to a key array:
            var selKeysDev = $S.map(data.tree.getSelectedNodes(), function(node) {
                if (node.getParent().title != "root") {
                    if (node.title != "No devices found") {
                        return node.title;
                    }
                }
            });

            selectedDeviceForAction = selKeysDev.join(",");
            populateAssetsForSelection(selKeysDev.toString(),familyType);

            // test selectedDeviceForAction

        },
        filter: {
            autoApply: true, // Re-apply last filter if lazy data is loaded
            counter: true, // Show a badge with number of matching child nodes near parent icons
            fuzzy: false, // Match single characters in order, e.g. 'fb' will match 'FooBar'
            hideExpandedCounter: true, // Hide counter badge, when parent is expanded
            highlight: true, // Highlight matches by wrapping inside <mark> tags
            mode: "hide" // Grayout unmatched nodes (pass "hide" to remove unmatched node instead or "dimm" to disable)
        }
    });
    var tree = $S("#groupDeviceFilterTree").fancytree("getTree");
    $S("input[name=deviceFilterTreeSearch]").keyup(function(e) {
        var n,
            opts = {
                autoExpand: 'true',
                leavesOnly: $S("#leavesOnly").is(":checked")
            },
            match = $S(this).val();

        if (e && e.which === $S.ui.keyCode.ESCAPE || $S.trim(match) === "") {
            $S("#btnResetSearch").click();
            return;
        }
        n = tree.filterNodes(match, opts);
    }).focus();

    $S("#btnResetSearch").click(function(e) {
        $S("input[name=deviceFilterTreeSearch]").val("");
        tree.clearFilter();
    });

    if($S('#groupDeviceFilterTree #grouptreetest li').length == 0){
        $S(".noDevicesDiv").show()
        $S('#groupDeviceFilterInside').hide();
    }

    var node = $S("#groupDeviceFilterTree").fancytree("getRootNode");
    node.sortChildren(null, true);

    if (selectedDevice != undefined && selectedDevice !== "") {
        selectNodes(selectedDevice, "groupDeviceFilterTree");
    }else{
        selectedDeviceForAction = "";
    }

    $S(".fancytree-node").not(".fancytree-has-children").remove();
}
$S(document).on("click", ".reportsDeviceFilterTree_selectall", function(e) {
    var state = $S(this).prop("checked");
    $S("#groupDeviceFilterTree").fancytree("getTree").visit(function(node){
        node.setSelected(state);
    });
});
$S(document).on("click", ".removeAllFilters", function(e) {
    if(reportType === "organizationReports") {
        selectedAccountForAction = []
        populateOrgLevelAccountFilter();
    }else{
        $S('#windowsauto').prop("checked", true);
        $S('#linuxauto').prop("checked", true);
        $S('#macauto').prop("checked", true);
        $S('#othersauto').prop("checked", true);
        resettingTheTagFilterModal();
        getTheDevicesBasedOnTheTags();
        $S("input[name=deviceFilterTreeSearch]").val("");
    }
    $S(".token").remove();
    $S(".assetincludefilter").val("");
    $S(".vendorincludefilter").val("");
    $S("#startDateFilter").val("");
    $S("#endDateFilter").val("");
    $S("#installedStartDateFilter").val("");
    $S("#installedEndDateFilter").val("");
    $S("#releasedStartDateFilter").val("");
    $S("#releasedEndDateFilter").val("");
    
});

$S(document).on("click", ".clearInputFiled", function(e) {
    e.stopImmediatePropagation();
    $S(this).siblings("input").val("");
})
