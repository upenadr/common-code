"use strict"
var $S = jQuery.noConflict();

var dataConstruction = {
    tableData: function(id, columns, columnsNmaeMap) {
        var table = document.createElement('table');
		table.setAttribute("id", id + "Table");
		table.classList.add("table");
		table.classList.add("table");
		table.classList.add("table-bordered");
		//table.classList.add("table-striped");
		//table.style.width = '98% !important';
		//table.style.tableLayout = 'fixed';

		var tr = document.createElement('tr');
		
		var aoColumns = [];

		var columnsArr = columns.split(",");
		columnsArr.forEach(element => {

			let td = document.createElement('td');
			td.title = columnsNmaeMap[element];
			td.appendChild(document.createTextNode(columnsNmaeMap[element]));
			tr.appendChild(td);

			var aoColumnsValue = {};
			aoColumnsValue["mDataProp"] = element;
			aoColumns.push(aoColumnsValue);
		});

		var thead = document.createElement('thead');
		thead.appendChild(tr);

		var tbody = document.createElement('tbody');

		table.appendChild(thead);
        table.appendChild(tbody);
        
        return [table.outerHTML, aoColumns];
    },

	pieData: function (data, columns, xaxis_column, yaxis_column, columnsNmaeMap) {
		let outer = [];
		let inner = [];
        let innerMap = {};

        try{

            if(columns == 'onlychart') {
                
            }
            
            if(xaxis_column[0] == 'key' && yaxis_column[0] == 'value') {

                // Adding Column Name
                inner.push(xaxis_column[0]);
                inner.push(yaxis_column[0]);
                outer.push(inner);
                inner = [];
                
                let json = JSON.parse(data);

                for (var i = 0, len = json[Object.keys(json)[0]].length; i < len; ++i) {
                    var each = json[Object.keys(json)[0]][i];

                    Object.keys(each).forEach((key)=> {
                        innerMap[key] = parseInt(each[key]);
                    });

                }
                
            } else {

                if(xaxis_column.length == 1 && yaxis_column.length == 1) {

                    // Adding Column Name
                    inner.push(xaxis_column[0]);
                    inner.push(yaxis_column[0]);
                    outer.push(inner);
                    inner = [];
        
                    let json = JSON.parse(data);
                    for (var i = 0, len = json[Object.keys(json)[0]].length; i < len; ++i) {
                        var each = json[Object.keys(json)[0]][i];
        
                        xaxis_column.forEach((x)=>yaxis_column.forEach((y)=> {
                            let x_data = each[x];
                            let y_data = each[y];

                            if(/^\d+$/.test(y_data) || /^\d+\.\d+$/.test(y_data)) {
                                // For String & Integer
                                if(x_data in innerMap) {
                                    innerMap[x_data] = innerMap[x_data] + parseInt(y_data);
                                } else {
                                    innerMap[x_data] = parseInt(y_data);
                                }
        
                            }
                            else {
                                // For String & String
                                if(x_data in innerMap) {
                                    innerMap[x_data] = innerMap[x_data] + 1;
                                } else {
                                    innerMap[x_data] = 1;
                                }
                            }
        
                        }));
        
                    }
        
                }

                else if(xaxis_column.length > 1 || yaxis_column.length > 1) {

                    var column = [];
                    if(xaxis_column.length > 0) {
                        column = column.concat(xaxis_column);
            }

                    if(yaxis_column.length > 0) {
                        column = column.concat(yaxis_column);
                    }

                    // Adding Column Name
                    inner.push('Data');
                    inner.push('Value');
                    outer.push(inner);
                    inner = [];
        
                    let json = JSON.parse(data);
                    for (var i = 0, len = json[Object.keys(json)[0]].length; i < len; ++i) {
                        var each = json[Object.keys(json)[0]][i];

                        column.forEach((x)=> {

                            let data = each[x];

                            if(/^\d+$/.test(data) || /^\d+\.\d+$/.test(data)) {

                                // For String & Integer
                                if(x in innerMap) {
                                    innerMap[x] = innerMap[x] + parseInt(data);
                                } else {
                                    innerMap[x] = parseInt(data);
                                }
        
                            }
                            else {

                                // For String & String
                                if(data in innerMap) {
                                    innerMap[data] = innerMap[data] + 1;
                                } else {
                                    innerMap[data] = 1;
                                }

                            }

                        });
        
                    }

                }

            }

            // Update Outer[]
            if(Object.keys(innerMap).length > 0) {

                for (var key in innerMap) {

                    var keyToDisplay = key;
                    if(columnsNmaeMap[key] != undefined) {
                        keyToDisplay = columnsNmaeMap[key];
                    }

                    inner.push(keyToDisplay);

                    inner.push(parseInt(innerMap[key]));

                    if(parseInt(innerMap[key]) > 0) {
                    outer.push(inner);
                    }

                    inner = [];
                }

            } else {
                outer = [];
            }

        } catch(err) {
            outer = [];
        }
        
		return outer;
    },
    
    barData: function (data, columns, xaxis_column, yaxis_column, columnsNmaeMap, charttooltip) {
        let outer = [];
		let inner = [];
        let innerMap = {};
        let tooltipMap = {};

        if(columns == 'onlychart') {
            
        }

        if(xaxis_column[0] == 'key' && yaxis_column[0] == 'value') {

            //Adding Column Name
            if(columnsNmaeMap[xaxis_column[0]] && columnsNmaeMap[yaxis_column[0]]) {
                inner.push(columnsNmaeMap[xaxis_column[0]]);
                inner.push(columnsNmaeMap[yaxis_column[0]]);
            } else {
                inner.push(xaxis_column[0]);
                inner.push(yaxis_column[0]);
            }

			
			outer.push(inner);
			inner = [];

            let json = JSON.parse(data);

            for (var i = 0, len = json[Object.keys(json)[0]].length; i < len; ++i) {
				var each = json[Object.keys(json)[0]][i];

                Object.keys(each).forEach((key)=> {
                    innerMap[key] = parseFloat(each[key]).toFixed(2);
                });

            }
           
        } else {
            
            if(xaxis_column.length == 1 && yaxis_column.length == 1) {

                // Adding Column Name
                if(columnsNmaeMap[xaxis_column[0]] && columnsNmaeMap[yaxis_column[0]]) {
                    inner.push(columnsNmaeMap[xaxis_column[0]]);
                    inner.push(columnsNmaeMap[yaxis_column[0]]);
                } else {
                    inner.push(xaxis_column[0]);
                    inner.push(yaxis_column[0]);
                }
                
                if (charttooltip) inner.push(charttooltip);
                outer.push(inner);
                inner = [];
    
                var json = JSON.parse(data);
                for (var i = 0, len = json[Object.keys(json)[0]].length; i < len; ++i) {
                    var each = json[Object.keys(json)[0]][i];
    
                    xaxis_column.forEach((x)=>yaxis_column.forEach((y)=> {
                        let x_data = each[x];
                        let y_data = each[y];
                        let z_data = each[charttooltip];

                        if(/^\d+$/.test(y_data) || /^\d+\.\d+$/.test(y_data)) {
                            // For String & Integer
                            if(x_data in innerMap) {
                                innerMap[x_data] = innerMap[x_data] + parseFloat(y_data);
                            } else {
                                innerMap[x_data] = parseFloat(y_data);
                            }
    
                        } else {
                            // For String & String
                            if(x_data in innerMap) {
                                innerMap[x_data] = innerMap[x_data] + 1;
                            } else {
                                innerMap[x_data] = 1;
                            }
                        }

                        if (z_data) tooltipMap[x_data] = z_data;
    
                    }));
    
                }
        
            } else if((xaxis_column.length == 1 && yaxis_column.length > 1) || (xaxis_column.length > 1 && yaxis_column.length == 1)) {

                var xaxis = [];
                var yaxis = [];

                if(xaxis_column.length == 1 && yaxis_column.length > 1) {
                    xaxis = xaxis_column;
                    yaxis = yaxis_column;
                } else if(xaxis_column.length > 1 && yaxis_column.length == 1) {
                    xaxis = yaxis_column;
                    yaxis = xaxis_column;
                }

                // Adding Column Name
                if(columnsNmaeMap[xaxis[0]]) {
                    inner.push(columnsNmaeMap[xaxis[0]]);
                } else {
                    inner.push(xaxis[0]);
                }

                
                yaxis.forEach((y)=> {
                    if(columnsNmaeMap[y]) {
                        inner.push(columnsNmaeMap[y]);
                    } else {
                        inner.push(y);
                    }
                    
                });
                outer.push(inner);
                inner = [];
    
                var json = JSON.parse(data);
                for (var i = 0, len = json[Object.keys(json)[0]].length; i < len; ++i) {
                    var each = json[Object.keys(json)[0]][i];
    
                    var y_data_arr = [];
                    yaxis.forEach((y)=> {
                        y_data_arr.push(each[y]);
                    });

                    innerMap[each[xaxis[0]]] = y_data_arr.toString();
    
                }

            }

        }

        // Update Outer[]
        if(Object.keys(innerMap).length > 0) {

            for (var key in innerMap) {

                var keyToDisplay = !/[-/]/.test(key) && !isNaN(parseFloat(key)) && isFinite(key) ? parseFloat(key) : key;
                if(columnsNmaeMap[key] != undefined) {
                    keyToDisplay = columnsNmaeMap[key];
                }

                inner.push(keyToDisplay);

                try {
                    
                    if(innerMap[key].indexOf(',') >= 0) {

                        innerMap[key].split(',').forEach((each)=> {
                            inner.push(parseFloat(each));
                        });
    
                    } else {
                        inner.push(parseFloat(innerMap[key]));
                    }

                }

                catch(err) {

                    try {
                        inner.push(parseFloat(innerMap[key]));
                    } 

                    catch(ierr) {
                        inner.push(innerMap[key]);
                    }
                    
                }

                if(Object.keys(tooltipMap).length > 0) inner.push(tooltipMap[key]);
                outer.push(inner);
                inner = [];
            }

        } else {
            outer = [];
        }

        return outer;
    }
};
